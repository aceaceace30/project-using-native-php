<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li> 
          </form>
        </ul>
     </li>
        <li><a class="drop" href="#">User Tables</a>    
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Transaction</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

 <form action="manage_reservation.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Manage Reservations</h1>
        <hr>
      </div>
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
      <div style="float: right; margin: 3px 20px 0 0;">
    <i class="fa fa-search fa-2x" aria-hidden="true" style="position: absolute;  margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" name="search_text" id="search_text"  style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="Search"> 
        </div>

      </div> <br><br>   
       
      <div id="result">
        
      </div> 
    </div>
  </div>
</form>


<div id="confirm" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('confirm').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to confirm this reservation?</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_confirm"></span><br>
    <input type="password" size="40" id="secpass_confirm" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="confirm_btn" class="btn btn-default">CONFIRM</button></center>
    </div>
  </form>
</div>

<div id="cancel" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('cancel').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to cancel this reservation?</h2></center>
    </div>
    <center style="color: red;"><span id="pass_err"></span><br>
    <input type="password" size="40" id="secpass" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="yes_btn" class="btn btn-default">SUBMIT</button></center>
    </div>
  </form>
</div>

<script>
$(document).ready(function() {
  load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetchreservation.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
  });
});
</script>

</body>

</html>