$('select').on('change', function() {
    $('html, body').animate({
        scrollTop: $('#' + $(this).val()).position().top
    }, 1000);
});

var fixmeTop = $('#fixednav').offset().top;      

$(window).scroll(function() {                 

    var currentScroll = $(window).scrollTop();

    if (currentScroll >= fixmeTop) {          
        $('#fixednav').css({                      
            position: 'fixed',
            top: '0',
            left: '0'
        });
    } else {                                  
        $('#fixednav').css({              
            position: 'static'
        });
    }

});