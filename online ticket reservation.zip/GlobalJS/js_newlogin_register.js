$(document).ready(function(){

  $("#email_reg").click(function(e){
    $('#erroremail').text(""); 
  });

  $("#password_reg").click(function(e){
    $('#errorpassword').text(""); 
  });

  $("#confirmpass").click(function(e){
    $('#errorconfirmpass').text(""); 
  });

  $("#fname").click(function(e){
    $('#errorfname').text(""); 
  });

  $("#lname").click(function(e){
    $('#errorlname').text(""); 
  });

  $("#phonenumber").click(function(e){
    $('#errorphonenumber').text(""); 
  });


  $("#login_btn").click(function(e){
   e.preventDefault();
    var email=$('#email').val();
    var password=$('#password').val();

    if(email=="")
    {
      $('#error_login').text("Email can not be empty");
      return;
    }
    else if(password=="")
    {
      $('#error_login').text("Password can not be empty");
      return;
    }
    $.ajax({
      type:"POST",
      url:"Client/login.php",
      data:{'email':email,  
            'password':password},     
      success:function(data){
        if(data=="no")
        {
          $('#error_login').text("EMAIL OR PASSWORD IS INCORRECT"); 
        }
        else
        {
          //alert("Successfully log-in!");
          location.reload();
        }
      }
    });
  });

$("#reg_btn").click(function(e){
   e.preventDefault();

    var email=$('#email_reg').val();
    var password=$('#password_reg').val();
    var confirmpass=$('#confirmpass').val();
    var fname=$('#fname').val();
    var lname=$('#lname').val();
    var phonenumber=$('#phonenumber').val();

    if(email=="")
    {
      $('#erroremail').text("Email can not be empty");
      return;   
    }
    if(password=="")
    {
      $('#errorpassword').text("Password can not be empty");
      return;  
    }
    if(confirmpass=="")
    {
      $('#errorconfirmpass').text("Confirm password can not be empty");
      return;   
    }
    if(fname=="")
    {
      $('#errorfname').text("Firstname can not be empty");
      return;
    }
    if(lname=="")
    {
      $('#errorlname').text("Lastname can not be empty");
      return;    
    }
    if(phonenumber=="")
    {
      $('#errorphonenumber').text("Phone number can not be empty");
      return;
    }
    if(email.length<6)
    {
      $('#erroremail').text("Email could not less than 6 characters");
      return;
    }
    if(password.length<6)
    {
      $('#errorpassword').text("Password could not less than 6 characters");
      return;
    }
    if(phonenumber.length<12)
    {
      $('#errorphonenumber').text("Phone number is not valid");
      return;
    }

    $.ajax({
      type:"POST",
      url:"Client/register.php",
      data:{'email':email,  
            'password':password,
            'confirmpass':confirmpass,
            'fname':fname,
            'lname':lname,
            'phonenumber':phonenumber},     
      success:function(data){
        if(data=="emailtaken")
        {
          $('#erroremail').text("Email already taken");
        }
        else if(data=="notequalpass")
        {
          $('#errorpassword').text("Password should be the same");
          $('#errorconfirmpass').text("Password should be the same");

        }
        else if(data=="samephone")
        {
          $('#errorphonenumber').text("Number already registered");
        }
        else
        {
          alert("Register Successful");
          location.reload();
        }
      }
    });
  });
});

