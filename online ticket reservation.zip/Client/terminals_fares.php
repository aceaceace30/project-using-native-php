<?php
session_start();
require('dbconnect.php');
require('check.php');
require('select.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="../index.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/Travel-Lokal-839843849505011/" target="blank"><i class="fa fa-facebook"></i></a></li>
      </ul>
    </div>
</header>
</div>

<div class="wrapper row2">
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true" ></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-road icon" aria-hidden="true" style="color:#33bbff"<></i>
      <li class="active"><a href="#">Terminals & Fares</a></li>
      <i class="fa fa-phone icon" aria-hidden="true"></i>
      <li><a href="contact_us.php">Contact Us</a></li>
      <div style="margin-left: 550px; display: inline-block">
       <?php
      if(isset($_SESSION["email"]))
      {
      ?>
       <li><a class="drop" href="#"><span style="text-transform: capitalize;">Hi,</span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
        <form id="customer_frm">
          <li><a onclick="document.getElementById('editaccount').style.display = 'block'" id='<?php echo $_SESSION["userid"];?>' name="editacc"  href="#editaccount"><i class="fa fa-user" aria-hidden="true" style="color: lime;"></i> My Account</a></li>
          <li><a href="myreservation_page.php" id="myreservation_link"><i class="fa fa-book" aria-hidden="true" style="color: #00e6e6;"></i> My Reservation</a></li>
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </form>
        </ul>
     </li>
      <?php
      }
      else
      {
      ?>
      <?php
      }
      ?>
      </div>
    </ul>
  </nav>
</div>

 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto; margin-top: 20px;">
     <div class="col-lg-12">
        <h1 class="page-header">TERMINALS AND FARES</h1>
        <hr>
      </div>
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
      <div style="float: right; margin: 3px 20px 0 0;">
         <i class="fa fa-compass fa-2x" aria-hidden="true" style="position: absolute;  margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="CUBAO" disabled> 
        <i class="fa fa-arrow-right" aria-hidden="true"></i>
       <i class="fa fa-map-marker fa-2x" aria-hidden="true" style="position: absolute;  margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" name="search_text" id="search_text" autofocus="autofocus" style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="DESTINATION"> 
        </div>
      </div><br> 
      <div id="result"></div>
        </div>
    </div>
</form>

</body>
<script>
$(document).ready(function() {
  load_data();  

 function load_data(query)
 {
  $.ajax({
   url:"fetchscheds.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
  });
});
</script>
</html>