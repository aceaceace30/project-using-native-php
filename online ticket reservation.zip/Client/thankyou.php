<?php
session_start();
use PayPal\Api\Payment;
use PayPal\Api\PaymentExecution;
require('sessioncheck.php');    
require('dbconnect.php');
require('first.php');
include ( "./src/NexmoMessage.php" );

if(!isset($_GET['success'], $_GET['paymentId'], $_GET['PayerID'])){
    die();
    header('location:timeout.php');
}

if((bool)$_GET['success']===false)
{
    header('location:timeout.php');
    die();
}

date_default_timezone_set('Asia/Manila');
$t=time();
$mydate1=date("m/d/Y",$t);

$myid=$_SESSION['userid'];
$mydate=$_SESSION['datepick'];
$route_id=$_SESSION['routeid'];

$random=rand(10000000,99999999);

$myseats_arr= array();
$myseats_arr= $_SESSION['myseats_arr'];

        $query = "INSERT INTO reservations(userID, routeID,reserve_date,fare_total,payment_type,booking_source,code,payment_status,status,transaction_date) VALUES('$myid','$route_id','$mydate','".$_SESSION['totalfare']."','PayPaL','online','$random','PAID','reserve','$mydate1')";

        if($DBcon->query($query)){ 
    
            $query2="SELECT MAX(reserveID) as myid FROM reservations where userid='$myid'";
            $result=$DBcon->query($query2);

            if ($result->num_rows > 0) {

            while($row = $result->fetch_assoc()) {

                $resID=$row["myid"];
                $_SESSION['reserveID']=$resID;

                }
            }

        }

        $get_seatno = "SELECT reserve_seats.seat_no FROM reserve_seats INNER JOIN reservations ON reservations.reserveID=reserve_seats.reserveID WHERE reserve_date='$mydate' AND routeID='$route_id' AND reserve_seats.reserveID!='$resID'";

        $result8=$DBcon->query($get_seatno);

                $store = array();   
                $store2= array();
                $c=0;
                while($row = $result8->fetch_row()) {
                    $store = array($row[0]);
                    $store2[$c]=$store[0];
                    $c++;
                }

$myseats=$_SESSION['allseats2'];

if (count(array_intersect($myseats_arr, $store2)) === 0) {

//$reserveid=$_SESSION['reserveID'];
$myseats=$_SESSION['allseats2'];
$total=$_SESSION['totalfare'];
$lname=$_SESSION['lastname'];
$fname=$_SESSION['firstname'];
$fullname=$fname . ' ' . $lname;

date_default_timezone_set('Asia/Manila');
$t=time();
$mydate1=date("m/d/Y",$t);

            for($b=0;$b<sizeof($myseats_arr);$b++)
            {
                $query3="INSERT INTO reserve_seats(reserveID,seat_no) values('$resID','$myseats_arr[$b]')";
                $DBcon->query($query3);
            }

           $get_message = "SELECT * FROM sms_message WHERE id='2'";
            $result4=$DBcon->query($get_message);
            if ($result4->num_rows > 0) {
                  while($row3 = $result4->fetch_assoc()) {
                    $message=$row3["message"];
                  }
            }
            
            //Email Send
    
            $send_to=$_SESSION['email'];
            
            $to      = $send_to;
            $subject = 'Travel Lokal Reservation';
            $message_send = $message;
            $headers = 'From:thesis.travel.lokal@gmail.com' . "\r\n" .
                'Reply-To:thesis.travel.lokal@gmail.com' . "\r\n" .
                'X-Mailer: PHP/' . phpversion();
            
            mail($to, $subject, $message_send, $headers);

            $number=$_SESSION['phonenumber'];
            $nexmo_sms = new NexmoMessage('40562a26', 'fa58cd0cd011856f');
            // Step 2: Use sendText( $to, $from, $message ) method to send a message. 
            $info = $nexmo_sms->sendText( '+'.$number, 'MyApp', $message.$random );
            // Step 3: Display an overview of the message

            $getroute="SELECT r.reserveID, rs.routeID,  rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.payment_status, rs.fare FROM routes_schedules as rs INNER JOIN reservations as r ON rs.routeID=r.routeID WHERE r.status='reserve' AND r.reserveID='$resID'";
        
        $result=$DBcon->query($getroute);

        if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) {

            $buscompany=$row['company'];
            $bustype=$row['type'];
            $from=$row['from_location'];
            $destination=$row['destination'];
            $sched=$row['time_sched'];
            $fare=$row['fare'];
            $reservedate=$row['reserve_date'];

            }
        }

        $paymentId=$_GET['paymentId'];
        $payerId=$_GET['PayerID'];

        $payment=Payment::get($paymentId, $apiContext);

        $execute = new PaymentExecution();
        $execute->setPayerId($payerId);

            try{

                $result = $payment->execute($execute, $apiContext);

            }catch (Exception $e)
            {
                header('location:timeout.php');
                die($e);
            }

} else {

    $delete_this = "DELETE FROM reservations WHERE reserveID='$resID'";
    $DBcon->query($delete_this);
    
    header('location:seat_inform.php');
} 




?>

<!DOCTYPE html>
<html>
<head>
    <title>Travel Lokal-Thank You!</title>
    <link rel="icon" href="../GlobalImages/profile1.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<center><div style="text-align: center; border-radius: 5px; width: 400px;">
<i style="color: #1aff1a;" class="fa fa-2x fa-check-circle" aria-hidden="true"></i><h1 style="display: inline-block; margin-left: 10px; color: #404040;"><i>Payment Successful!</i></h1><br>

<a href="../index.php" style="color: #0099e6;">Return to home</a><br>
<h4>If you didn't receive any text message or email...</h4>
<a href="contact_us.php" style="color: #0099e6;"><h4>Contact us</h4></a>
<button onclick="myFunction()" style="background-color: #33bbff; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px;">Print Voucher</button>
</div></center>
<br>
</div></center>
<center>
    <div id="specific_page" style="color: #666666; border: 1px solid gray; padding: 10px; border-radius: 5px; width: 500px;"">
        <img src="../GlobalImages/profile1.png" height="50"> <center><h3 style="display: inline-block;">Travel Lokal</h3><p>451, Ortigas Avenue, Pasig,<br> Metro Manila<br>
        +639123456789<br>
        infotravellokal@gmail.com</p><hr><br>

        <div style="text-align: left;">
        <label style="margin-right: 38px;">DATE OF TRANSACTION:</label><?php echo $mydate1; ?><br><br>
        <label style="margin-right: 38px;">TIME OF TRANSACTION:</label><?php $time=date("h:i:sa"); echo $time; ?><br><br>
        <label style="margin-right: 55px;">NAME OF PASSENGER:</label><?php echo $fullname; ?><br><br>
        <label style="margin-right: 105px;">BUS COMPANY:</label><?php echo $buscompany; ?><br><br>
        <label style="margin-right: 140px;">BUS TYPE:</label><?php echo $bustype; ?><br><br>
        <label style="margin-right: 170px;">FROM:</label><?php echo $from; ?><br><br>
        <label style="margin-right: 195px;">TO:</label><?php echo $destination; ?><br><br>
        <label style="margin-right: 100px;">BOOKED DATE:</label><?php echo $reservedate; ?><br><br>
        <label style="margin-right: 180px;">TIME:</label><?php echo $sched; ?><br><br>
        <label style="margin-right: 150px;">SEAT NO.:</label><?php echo $myseats;?><br><br>
        <label style="margin-right: 170px;">CODE:</label><?php echo $random;?><br><br>
        <label style="margin-right: 175px;">FARE:</label><?php echo $fare; ?><br><br>
        <label style="margin-right: 165px;">TOTAL:</label><?php echo $total; ?><br><br>
        </div><br>
             <p>* Tickets must be claimed before the departure time otherwise the reservation will be forfeited.

To avoid forfeiture, please cancel your reservation an hour before the screening time:

ONLINE. Log on to Travel Lokal with your username and password. On the Transaction History page, you can view your current and past transactions. Each active reservation has a CANCEL button to cancel any particular reservation if the transaction has not already paid. Please cancel any reservation/s you do not intend to claim.

NOTE: We only accept deposit and mobile banking trasfer on paying through our BPI and BDO bank account.
</p><br><br>
<h4 style="color: #404040;"><i>Thank you for booking with Travel Lokal!</i></h4>
    </div>

    </div>
</center>
<script>
function myFunction() {
var prtContent = document.getElementById("specific_page");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.focus();
WinPrint.print();
WinPrint.close();
}
</script>
</body>

</html>