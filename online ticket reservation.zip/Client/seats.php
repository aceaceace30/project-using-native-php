<?php
session_start();
require('dbconnect.php');
require('check2.php');
require('sessioncheck.php');
require('select.php');


if(isset($_GET["id"]))
{

$reservecount=0;

  $reserve_count="SELECT * FROM reservations WHERE payment_status='UNPAID' AND status='reserve' AND userID='".$_SESSION['userid']."'";
  $result=$DBcon->query($reserve_count);

  if($result->num_rows>0)
  {
    while($rows=$result->fetch_assoc())
    {
      $reservecount++;
    }
  }

$_SESSION['routeid']=$_GET["id"];
$route_id=$_SESSION['routeid'];
$i=0;
$thedate=$_SESSION['datepick'];


header("Refresh: 12;url='http://travel-lokal-ph.com/Client/seats.php?id=$route_id'");  

$get_routeID = "SELECT * FROM routes_schedules WHERE routeID='$route_id'";
$result_routeID = $DBcon->query($get_routeID);


if ($result_routeID->num_rows > 0) {

    while($row_result = $result_routeID->fetch_assoc()) {

    	$available_seats=$row_result["available_seats"];
   		$fare=$row_result["fare"];
      $company=$row_result["company"];

?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>TRAVEL LOKAL - Pick your seats</title>
<meta charset="utf-8"/>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<script>
    function restriction()
    {
      var counter_restric=<?php echo $reservecount; ?>;
      if(counter_restric>0)
      {
        alert("Sorry, but you are only limited to make 1 reservation if your previous reservation is not yet paid...");
        window.location.replace("http://travel-lokal-ph.com/index.php");;
      }
    }
  </script> 

</head>
<body onload="restriction(); myFunction();">
  <div class="wrapper row1">
    <header id="header" class="clear"> 
      <div id="logo">
        <h1><a href="../index.php"><img src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
          <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
      </div>
    </header>
  </div>

    <div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
    </ul>
  </nav>
</div>

 <div id="dashboard">
       <ul id="progress">
        <li class="active" onClick="document.location.href='datatable.php'" ><i class="fa fa-check check" aria-hidden="true"></i> 1. Schedule</li>
        <li class="active">2. Pick Seats</li>
        <li>3. Payment</li>
    </ul>
    <hr><br>

<center><h6 style="color:red; font-size: 15px;">* Note: This page keeps reloading every 12 seconds to avoid seat conflicts. Thank you for your understanding. *</h6></center>

<div id="pickseats">
<?php
      echo "Date Selected: ".$_SESSION["datepick"];
   ?>
  <hr><br>
  <div id="pickinstruc">
    <i class="fa fa-square gray" aria-hidden="true"></i><span>Available</span><br>
    <i class="fa fa-square blue" aria-hidden="true"></i><span>Selected</span><br>
    <i class="fa fa-square red" aria-hidden="true"></i><span>Reserved</span>
  </div>
    <div id="seats">
    <span style="margin: 0 30px 0 10px; color: gray">Driver</span><span style="color: gray;">Conductor</span><br><br>
       <?php

      $seat_count=0;

    $getseatcount="SELECT * FROM seats";
      $res = $DBcon->query($getseatcount);

      if ($res->num_rows > 0) {

        while($row = $res->fetch_assoc()) {
            $seat_count++;
        }
      }

    for($i=1;$i<=$seat_count;$i++)
    {
      $get_seatID="SELECT * FROM seats where seatID='$i'";
      $result_seatID = $DBcon->query($get_seatID);

      if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {

          $seat_no=$row["seat_no"];
        }
    }
      ?>


<form id="tosearch" action="searchmod.php" method="POST">
<div style="display: inline-block;">
    <input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
    <label id="<?php echo $seat_no; ?>" for="<?php echo $seat_no; ?>" title="Seat #<?php echo $seat_no; ?>"></label>
    <span id="<?php echo $seat_no; ?>-checked" style="display:none;"></span>
    <span id="<?php echo $seat_no; ?>-unchecked"></span>
</div>

     <?php 
    }
    if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {
          $avail=$row['available_seats'];
            }
    }
    ?>
    </div>

</div>

<div id="rightseats" style="margin-top: 40px;">
<label><strong>Information</strong></label>
  <hr>
      <span style="color: red" id=noseat></span><br><br>
      <input type="hidden" name="id" value="<?php echo $route_id;?>">
            <label class="bold" for="Bus_Company"><span style="margin-right: 60px;">Bus Company:</span><?php echo $row_result["company"]; ?></label><br>
            <label class="bold" for="Type"><span style="margin-right: 125px;">Type:</span><?php echo $row_result["type"]; ?></label><br>
            <label class="bold" for="From"><span style="margin-right: 80px;">Destination:</span><?php echo $row_result["destination"]; ?></label><br>
            <label class="bold" for="Schedule"><span style="margin-right: 95px;">Schedule:</span><?php echo $row_result["time_sched"]; ?></label><br>
            <label class="bold" for="seats" id="seatsno"><span style="margin-right: 70px;">No. of Seat/s:</span><span style="color: red; font-weight: bold;" id="numberofseats"></span></label><br>
  
            <label class="bold" for=total><span style="margin-right: 125px;">Total:</span><span style="color: red; font-weight: bold;" id="total"></span></label> 
            <input type="hidden" name="mytotal" id="mytotal">
            <label class="bold" for="selectedseats" id="selecseats"><span>Selected Seats:</span><span><input readonly type="text" size="30" name="customerseats" style="margin-left: 35px; color: red; background: #FFFFFF; font-weight: bold; border-style: none;" class="field_results"></span> </label>
            <?php      
            $getpolicy="SELECT c.id,c.company_name,cp.baggage_limit FROM companies as c INNER JOIN company_policy as cp ON c.id=cp.com_id WHERE c.company_name='$company'";
              $res = $DBcon->query($getpolicy);

              if ($res->num_rows > 0) {

                while($row = $res->fetch_assoc()) {
                    $policy=$row['baggage_limit'];
                }
              }
            ?>
           <label class="bold" for=baggage><span style="margin-right: 58px;">Baggage Limit:</span><span style="color: red; font-weight: bold;"><?php echo $policy; ?>(for each passenger)</span></label> 
            <input type="submit" name="payment_btn" value="Proceed to Payment">
 </div>
</form>

<?php
    }
}
}

$get_seatno = "SELECT reserve_seats.seat_no FROM reserve_seats INNER JOIN reservations ON reservations.reserveID=reserve_seats.reserveID WHERE reserve_date='$thedate' AND routeID='$route_id'";
$result=$DBcon->query($get_seatno);

$store = array();
$store2= array();
$c=0;
while($row = $result->fetch_row()) {
    $store = array($row[0]);
    $store2[$c]=$store[0];
    $c++;
}
?>


<script type="text/javascript">

function myFunction() {
<?php
for($k=0;$k<sizeof($store2);$k++)
{
?>
	document.getElementById('<?php echo $store2[$k]; ?>').disabled = true;
<?php 
}
?>
}

      var counter=0;
      var busfare=<?php echo $fare;?>;
      var total=0;

function ChangeCheckboxLabel(ckbx)
{
        $('input[type=checkbox]').on('change', function (e) {
        if ($('input[type=checkbox]:checked').length > 10) {
            $(this).prop('checked', false);
            alert("You could only select maximum of 10 seats");
             total=counter*busfare;
             document.getElementById(d+"-checked").style.display = "none";
             document.getElementById(d+"-unchecked").style.display = "inline";
             counter-=1;
             total-=busfare;
             document.getElementById("numberofseats").innerHTML= counter;
             document.getElementById("total").innerHTML= total;
             document.getElementById("mytotal").value= total;
          }
        });

      var d = ckbx.id;

       if(ckbx.checked)
       {
          document.getElementById(d+"-checked").style.display = "inline";
          document.getElementById(d+"-unchecked").style.display = "none";
          counter+=1;
          document.getElementById("numberofseats").innerHTML= counter;
       }
       else
       {
          document.getElementById(d+"-checked").style.display = "none";
          document.getElementById(d+"-unchecked").style.display = "inline";
          counter-=1;
          document.getElementById("numberofseats").innerHTML= counter;
       }

    $checks = $(":checkbox");
    $checks.on('change', function() {
        var string = $checks.filter(":checked").map(function(i,v){
            return this.value;
        }).get().join(" ");
        $('.field_results').val(string);
    });

    total=counter*busfare;
   	document.getElementById("total").innerHTML= total;
    document.getElementById("mytotal").value= total;
}

$(document).ready(function () {
    var $form = $('#tosearch');
    var $checkbox = $('.myseats');
    
    $form.on('submit', function(e) {
        if(!$checkbox.is(':checked')) {
            $('#noseat').text('No seat/s selected');
            e.preventDefault();
        }
    });
}); 



</script>

</body>
</html>