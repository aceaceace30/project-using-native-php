<?php
session_start();
require('dbconnect.php');
require('select.php');
if(isset($_SESSION['email']))
{
  header('location:../index.php');
}
require('check2.php');
require('redirect_login.php');
  
?>

<!DOCTYPE html>
<html lang="en">
<head>

<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
    <div class="wrapper row1">
        <header id="header" class="clear"> 
          <div id="logo">
            <h1><a href="../index.php"><img src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
          </div>
        </header>
    </div>
      <div style="border-style: solid; border-color: white; height: auto; background: white;">
      <a href="../index.php">Go back to homepage</a>
   <div class="col-lg-12">
        <h1 class="page-header">Welcome to Travel Lokal</h1>
        <hr><br>
      </div>

 		<form class="modal-content" action="loginpage.php" method="POST" style="margin-top: -15px;">
	        <div class="imgcontainer">  
	      <img src="../../GlobalImages/lock.png" class="avatar">
	    </div>
	    <div class="logcontainer">
	      <hr>
        <center><span id="message">Please log-in to continue</span></center>
        <span><?php if(isset($error_message)){ echo $error_message; } ?></span>
	      <input type="text" placeholder="Email" name="email" id="email" size="37" style="padding-left: 30px;" required>
	      <i class="fa fa-envelope errspan" aria-hidden="true"></i>
	      <input type="password" placeholder="Password" name="password" id="password" size="37" style="padding-left: 30px;" required>
        Dont have an account yet?<a onclick="document.getElementById('id02').style.display='block'" href="#id01"> REGISTER HERE!</a>
	      <i class="fa fa-key errspan" aria-hidden="true"></i>
	      <input style="background-color:#00aaff; height: 43px; width:100%; border-style: none; color:white; border-radius: 5px; margin: 30px 0 10px 0" type="submit" name="login_btn" id="admin_btn"></input>
	    </div>

      </div>
     </form>

     <div id="id02" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h4>User Registration</h4></center>
      <hr>
     <center><span id="erroremail"></span><br></center>
      <label style="margin-left: 87px;">Email:</label>
      <input type="text" placeholder="Enter Email" id="email_reg" size="45" required><br>
      <center><span id="errorpassword"></span><br></center>
      <label style="margin-left: 60px;">Password:</label>
      <input type="password" placeholder="Enter Password" id="password_reg" size="45" required><br>
      <center><span id="errorconfirmpass"></span><br></center>
      <label>Confirm Password:</label>
      <input type="password" placeholder="Confirm Password" id="confirmpass" size="45" required><br>
      <center><span id="errorfname"></span><br></center>
      <label style="margin-left: 50px;">First Name:</label>
      <input type="text" placeholder="Enter First Name" id="fname" size="45" required><br>
      <center><span id="errorlname"></span><br></center>
      <label style="margin-left: 50px;">Last Name:</label>
      <input type="text" placeholder="Enter Last Name" id="lname" size="45" required><br>
      <center><span id="errorphonenumber"></span><br></center>
      <label style="margin-left: 20px;">Phone Number:</label>
      <input type="text" placeholder="Ex. 639123456789" id="phonenumber" size="45" maxlength="14" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required>
    </div>
      <p id="success"></p>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <button style="background-color:#00aaff; border-radius: 5px; margin-left: 27%; color:white; height: 50px; border-style: none; width: 280px;" type="button" id="reg_btn" title="Create Account">SUBMIT</button>
    </div>
  </form>
</div>

<script>

$(document).ready(function(){

  $("#email_reg").click(function(e){
    $('#erroremail').text(""); 
  });

  $("#password_reg").click(function(e){
    $('#errorpassword').text(""); 
  });

  $("#confirmpass").click(function(e){
    $('#errorconfirmpass').text(""); 
  });

  $("#fname").click(function(e){
    $('#errorfname').text(""); 
  });

  $("#lname").click(function(e){
    $('#errorlname').text(""); 
  });

  $("#phonenumber").click(function(e){
    $('#errorphonenumber').text(""); 
  });
  
  $("#reg_btn").click(function(e){
   e.preventDefault();

    var email=$('#email_reg').val();
    var password=$('#password_reg').val();
    var confirmpass=$('#confirmpass').val();
    var fname=$('#fname').val();
    var lname=$('#lname').val();
    var phonenumber=$('#phonenumber').val();

    if(email=="")
    {
      $('#erroremail').text("Email can not be empty");
      return;   
    }
    if(password=="")
    {
      $('#errorpassword').text("Password can not be empty");
      return;  
    }
    if(confirmpass=="")
    {
      $('#errorconfirmpass').text("Confirm password can not be empty");
      return;   
    }
    if(fname=="")
    {
      $('#errorfname').text("Firstname can not be empty");
      return;
    }
    if(lname=="")
    {
      $('#errorlname').text("Lastname can not be empty");
      return;    
    }
    if(phonenumber=="")
    {
      $('#errorphonenumber').text("Phone number can not be empty");
      return;
    }
    if(email.length<6)
    {
      $('#erroremail').text("Email could not less than 6 characters");
      return;
    }
    if(password.length<6)
    {
      $('#errorpassword').text("Password could not less than 6 characters");
      return;
    }
    if(phonenumber.length<12)
    {
      $('#errorphonenumber').text("Phone number is not valid");
      return;
    }
    $.ajax({
      type:"POST",
      url:"register.php",
      data:{'email':email,  
            'password':password,
            'confirmpass':confirmpass,
            'fname':fname,
            'lname':lname,
            'phonenumber':phonenumber},     
      success:function(data){
        if(data=="emailtaken")
        {
          $('#erroremail').text("Email already taken");
        }
        else if(data=="notequalpass")
        {
          $('#errorpassword').text("Password should be the same");
          $('#errorconfirmpass').text("Password should be the same");

        }
        else if(data=="samephone")
        {
          $('#errorphonenumber').text("Number already registered");
        }
        else
        {
          alert("Register Successful");
          location.reload();
        }
      }
    });
  });

});

</script>
  </body>

</html>