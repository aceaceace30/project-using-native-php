<?php
include("./src/NexmoMessage.php");
require('dbconnect.php');
session_start();

$myid=$_SESSION['userid'];
$mydate=$_SESSION['datepick'];


if(!isset($_GET['reserve_btn']))
{
    header('location:timeout.php');
}

if (isset($_GET['reserve_btn'])) 
{

    date_default_timezone_set('Asia/Manila');
    $t=time();
    $mydate1=date("m/d/Y",$t);

    $resID=0;
    $random=rand(10000000,99999999);
    $_SESSION['combination']=$random;

    $seats_array=unserialize($_GET['seats_array']);
    $_SESSION['myseats_arr']=$seats_array;

    $route_id=$_SESSION['routeid'];

    $query = "INSERT INTO reservations(userID, routeID,reserve_date,fare_total,payment_type,booking_source,code,payment_status,status,transaction_date) VALUES('$myid','".$_SESSION['routeid']."','$mydate','".$_SESSION['totalfare']."','walk-in','online','$random','UNPAID','reserve','$mydate1')";

    if($DBcon->query($query)){ 
    
        $query2="SELECT MAX(reserveID) as myid FROM reservations where userid='$myid'";

        $result=$DBcon->query($query2);

        if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) {

            $resID=$row["myid"];
            $_SESSION['reserveID']=$resID;

            }
        }

        $get_seatno = "SELECT reserve_seats.seat_no FROM reserve_seats INNER JOIN reservations ON reservations.reserveID=reserve_seats.reserveID WHERE reserve_date='$mydate' AND routeID='$route_id' AND reserve_seats.reserveID!='$resID'";

        $result8=$DBcon->query($get_seatno);

                $store = array();   
                $store2= array();
                $c=0;
                while($row = $result8->fetch_row()) {
                    $store = array($row[0]);
                    $store2[$c]=$store[0];
                    $c++;
                } 

if (count(array_intersect($seats_array, $store2)) === 0) {
  
    for($b=0;$b<sizeof($seats_array);$b++)
    {
        $query3="INSERT INTO reserve_seats(reserveID,seat_no) values('$resID','$seats_array[$b]')";
        $DBcon->query($query3);
    }
    
    $get_message = "SELECT * FROM sms_message WHERE id='2'";
        $result4=$DBcon->query($get_message);
        if ($result4->num_rows > 0) {
              while($row3 = $result4->fetch_assoc()) {
                $message=$row3["message"];
              }
            }
            
    //Email Send
    
    $send_to=$_SESSION['email'];
    
    $to      = $send_to;
    $subject = 'Travel Lokal Reservation';
    $message_send = $message;
    $headers = 'From:thesis.travel.lokal@gmail.com' . "\r\n" .
        'Reply-To:thesis.travel.lokal@gmail.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    
    mail($to, $subject, $message_send, $headers);

    $number=$_SESSION['phonenumber'];
    $nexmo_sms = new NexmoMessage('40562a26', 'fa58cd0cd011856f');
    // Step 2: Use sendText( $to, $from, $message ) method to send a message. 
    $info = $nexmo_sms->sendText( '+'.$number, 'MyApp', $message.$random );
    // Step 3: Display an overview of the message
    echo $nexmo_sms->displayOverview($info);
    // Done!
    
    header('location:thankyou_walkin.php');
}else {

    $delete_this = "DELETE FROM reservations WHERE reserveID='$resID'";
    $DBcon->query($delete_this);
    
    header('location:seat_inform.php');
} 

}

}

?>