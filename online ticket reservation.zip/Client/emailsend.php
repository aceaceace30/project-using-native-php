<?php

if (isset($_POST['submit'])) {
    
$to      = 'alvinnpaguio@gmail.com';
$subject = 'the subject';
$message = 'BOSS KARL EAT';
$headers = 'From: infotravellokal@gmail.com' . "\r\n" .
    'Reply-To: infotravellokal@gmail.com' . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

mail($to, $subject, $message, $headers);
echo 'done';
}

?> 