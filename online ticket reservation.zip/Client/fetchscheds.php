<?php
require('dbconnect.php');

$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($DBcon, $_POST["query"]);
 $query = "
  SELECT * FROM routes_schedules 
  WHERE destination LIKE '%".$search."%'
 ";
}
else
{
 $query = "SELECT * FROM routes_schedules";
}
$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
	echo "<div class='table-responsive:'>
					<table class='table table bordered'>
						<tr>
							<th>Bus Company</th>
							<th>Type</th>
							<th>From</th>
							<th>Destination</th>
							<th>Schedule</th>
                                                        <th>Date</th>
              <th>Fare</th>
						</tr>";
	while ($row = mysqli_fetch_array($result)) {
	    
	       $fare=$row["fare"];
           $fare=number_format($fare,2);
			echo "<tr>
					<td>".$row["company"]."</td>
					<td>".$row["type"]."</td>
					<td>".$row["from_location"]."</td>
          <td>".$row["destination"]."</td>
          <td>".$row["time_sched"]."</td>
          <td>".$row["date_set"]."</td>
          <td>"."PHP ".$fare."</td>
					"?>

              	<?php

	}
		echo "</table>";
}
else
{
	echo '<center style="color: red;">Data Not Found</center>';
}

?>