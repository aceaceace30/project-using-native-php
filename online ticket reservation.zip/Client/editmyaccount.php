<?php
require('dbconnect.php');

$mypass = strip_tags($_POST['mypass']);
$mypass = $DBcon->real_escape_string($mypass);
$myphone = strip_tags($_POST['myphone']);
$myphone = $DBcon->real_escape_string($myphone);
$userid = $_POST['userid'];
$secpass=$_POST['securitypass'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$updateacc = "UPDATE users SET password='$mypass', phonenumber='$myphone' WHERE userid='$userid'";
    if ($DBcon->query($updateacc))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on updating account";
    }

?>