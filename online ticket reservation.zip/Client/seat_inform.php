<?php
session_start();
$routeid=$_SESSION['routeid'];

?>

<!DOCTYPE html>
<html>
<head>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div style="text-align: center; margin-top: 30px;">
<i class="fa fa-frown-o fa-3x" aria-hidden="true" style="color: #ff1a1a"></i></i></i><h2 style="color: #404040; margin-left: 10px;">SORRY BUT THE SEATS YOU CHOOSE HAS ALREADY TAKEN.</h2>
<br>
<a href="http://travel-lokal-ph.com/Client/seats.php?id=<?php echo $routeid;?>">Choose another seat?</a>
<br><br>
<a href="../index.php">Back to home</a>
</div>
</body>
</html>
