<?php
session_start();
require('dbconnect.php');

$usertype="";

$email = strip_tags($_POST['email']);
$password = strip_tags($_POST['password']);	
 
$email = $DBcon->real_escape_string($email);
$password = $DBcon->real_escape_string($password);
 
 $query = $DBcon->query("SELECT email, password FROM users WHERE email='$email' and password='$password'");
 $row=$query->fetch_array();
 $count = $query->num_rows;

 $getdetails=$DBcon->query("SELECT * FROM users WHERE email='$email'");

 if($getdetails->num_rows>0)
 {
 	while($row2=$getdetails->fetch_assoc())
 	{
 		$usertype=$row2["usertype"];
 		$firstname=$row2["firstname"];
 		$userid=$row2["userid"];
 		$phonenumber=$row2['phonenumber'];		
 	}
 }

if($usertype!="member")
	{
		echo "no";
		return;
	}	
if($count==0){	
  		echo "no";
}
else{	
		$_SESSION['email']=$email;
		$_SESSION['firstname']=$firstname;
		$_SESSION['lastname']=$lastname;
		$_SESSION['userid']=$userid;
		$_SESSION['phonenumber']=$phonenumber;
		echo "yes";
}

$DBcon->close();

 ?>