<?php

if(isset($_SESSION['userid']))
{
	$userid=$_SESSION['userid'];
	$getactive=$DBcon->query("SELECT * FROM users WHERE userid='$userid'");

 if($getactive->num_rows>0)
 {
 	while($row2=$getactive->fetch_assoc())
 	{
 		$active=$row2["activated"];		
 	}
 }

if($active=="no")
{
	header('location:activation.php');
}
}
?>