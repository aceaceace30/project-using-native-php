<?php
require('dbconnect.php');
require('select.php');      
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>

<title>TRAVEL LOKAL - Schedules</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="wrapper row1">
        <header id="header" class="clear"> 
          <div id="logo">
            <h1><a href="../index.php"><img src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
            <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
          </div>
        </header>
    </div>

    <div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
    </ul>
  </nav>
</div>
  <div id="dashboard">
       <ul id="progress">
        <li class="active">1. Schedule</li>
        <li>2. Pick Seats</li>
        <li>3. Payment</li>
    </ul>

  		<div class="transac">
          <div id="myTable">
          <hr><br>
          <?php
          if (isset($_GET['search_btn'])) 
          {

          $from = strip_tags($_GET['from']);
          $destination = strip_tags($_GET['destination']);
          $datepicker = strip_tags($_GET['datepicker']);
           
          $from = $DBcon->real_escape_string($from);
          $destination = $DBcon->real_escape_string($destination);
          $datepicker = $DBcon->real_escape_string($datepicker);

          date_default_timezone_set('Asia/Manila');
          $server_date=date('m/d/Y');
          $check_date=date('m/d/Y',time()+1209600);
          $pick_date=new DateTime($datepicker);
          $new_server_date=new DateTime($server_date);

          $new_check_date=new DateTime($check_date);

          if($pick_date<$new_server_date)
          {
              header('location:../index.php');
          }
          if($pick_date>$new_check_date)
          {
              header('location:../index.php');
          } 


          //query to get the route selected and display
          $sql = "SELECT * FROM routes_schedules where from_location='$from' and destination='$destination' and date_set='$datepicker'";

          $result = $DBcon->query($sql);

          $_SESSION["datepick"]=$datepicker;
          ?>
          <center><b><?php echo "DATE: ".$datepicker;?></center></b> 
          <?php
          if ($result->num_rows > 0) {
            echo "<table><tr><th>Bus Company</th><th>Type</th><th>From</th><th>Destination</th><th>Schedule</th><th>Fare</th><th>Action</th></tr>";
          }

              while($row = $result->fetch_assoc()) {
                  
                  $fare=$row["fare"];
                  $fare=number_format($fare,2);
          	
                  echo "<tr><td>" . $row["company"]. "</td><td>" . $row["type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["time_sched"]. "</td><td>" ."PHP ". $fare. "</td>"?>
                <td><a style="" href="seats.php?id=<?php $_SESSION['routeid']=$row['routeID']; echo $row["routeID"];?>"><i class="fa fa-bus" aria-hidden="true"></i> BOOK</a></td><br>
            		
                  
            	<?php
              }		
              echo "</table>";
          } else {
              echo "<br>NO SCHEDULE RESULT";	
          }
          ?>
            </div>
  		</div>
      </div>
    
  </body>
</html>