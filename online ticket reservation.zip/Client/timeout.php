<?php

echo "THERES WAS AN ERROR USING TRAVEL LOKAL!<br>";
echo "<a href='../index.php'>Go back to home page</a>";
?>