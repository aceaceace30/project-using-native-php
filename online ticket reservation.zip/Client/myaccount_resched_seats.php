<?php
session_start();
require('sessioncheck.php');
require('dbconnect.php');
require('select.php');
//require('sessioncheck.php');  
$route_id=$_GET["id"];
$reserve_id=$_GET["resid"];
$rdate=$_GET["rdate"];
$i=0;
$thedate="";
$seat_count=0;

$get_routeID = "SELECT rs.routeID, b.BusName, b.Bus_Company, b.Type, rs.from_location, rs.destination, rs.time_sched, rs.available_seats, rs.fare FROM routes_schedules as rs INNER JOIN bus as b ON rs.BusID=b.BusID WHERE rs.routeID='$route_id'";

$result_routeID = $DBcon->query($get_routeID);

if ($result_routeID->num_rows > 0) {

    while($row_result = $result_routeID->fetch_assoc()) {

    	$available_seats=$row_result["available_seats"];
   		//$bus_id=$row_result["BusID"];
   		$fare=$row_result["fare"];
      $buscomp=$row_result["Bus_Company"];

$number_ofseats="SELECT * FROM reserve_seats WHERE reserveID='$reserve_id'";
$result_number=$DBcon->query($number_ofseats);

if($result_number->num_rows>0){
  while($row=$result_number->fetch_assoc()){
      $seat_count++;
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</head>
<body onload="myFunction()">
  <div class="wrapper row1">
        <header id="header" class="clear"> 
          <div id="logo" class="fl_left">
            <h1><a href="index.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
            <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
          </div>
        </header>
    </div>
<div class="wrapper row2">
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="index.php">Home</a></li>
      <i class="fa fa-road icon" aria-hidden="true"></i>
      <li><a href="terminals_fares.php">Terminals & Fares</a></li>
      <i class="fa fa-phone icon" aria-hidden="true"></i>
      <li><a href="contact_us.php">Contact Us</a></li>
      <div style="margin-left: 550px; display: inline-block">
       <?php
      if(isset($_SESSION["email"]))
      {
      ?>
       <li class="active"><a class="drop" href="#"><span style="text-transform: capitalize;">Hi,</span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
        <form id="customer_frm">
          <li><a onclick="document.getElementById('editaccount').style.display = 'block'" id='<?php echo $_SESSION["userid"];?>' name="editacc"  href="#editaccount"><i class="fa fa-user" aria-hidden="true" style="color: lime;"></i> My Account</a></li>
          <li class="active"><a href="myreservation_page.php" id="myreservation_link"><i class="fa fa-book" aria-hidden="true" style="color: #00e6e6;"></i> My Reservation</a></li>
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </form>
        </ul>
     </li>
      <?php
      }
      else
      {
      ?>
      <li><a onclick="document.getElementById('id01').style.display='block'" href="#id01">LOGIN</a></li>
      <li style="margin-left: -30px;">/</li>
      <li style="margin-left: -30px;"><a onclick="document.getElementById('id02').style.display='block'" href="#id01">REGISTER</a></li>
      <?php
      }
      ?>
      </div>
    </ul>
  </nav>
</div>

 <div id="dashboard"><hr><br>
<center>   
<div id="pickseats">
  <h3>Re-schedule Form</h3><hr><br>
  <div id="pickinstruc">
    <i class="fa fa-square gray" aria-hidden="true"></i><span>Available</span><br>
    <i class="fa fa-square blue" aria-hidden="true"></i><span>Selected</span><br>
    <i class="fa fa-square red" aria-hidden="true"></i><span>Reserved</span>
  </div>
    <div id="seats" style="margin-left: -200px;">
    <span style="margin: 0 30px 0 10px; color: gray">Driver</span><span style="color: gray;">Conductor</span><br><br>
      <?php

      $seat_count=0;

    $getseatcount="SELECT * FROM seats";
    $res = $DBcon->query($getseatcount);

      if ($res->num_rows > 0) {

        while($row = $res->fetch_assoc()) {
            $seat_count++;
        }
      }

    for($i=1;$i<=$seat_count;$i++)
    {
      $get_seatID="SELECT * FROM seats where seatID='$i'";
      $result_seatID = $DBcon->query($get_seatID);

      if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {

          $seat_no=$row["seat_no"];
        }
    }
      ?>
<form id="tosearch" action="myaccount_reschedmod.php" method="GET">
<div style="display: inline-block;">
    <input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
   <label id="<?php echo $seat_no; ?>" for="<?php echo $seat_no; ?>" title="Seat #<?php echo $seat_no; ?>"></label>
    <span id="<?php echo $seat_no; ?>-checked" style="display:none;"></span>
    <span id="<?php echo $seat_no; ?>-unchecked"></span>
</div>
     <?php 
    }
    if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {
          $avail=$row['available_seats'];
            }
    }
    ?>
    </div><br>
        <input type="hidden" name="reserveID" value="<?php echo $reserve_id;?>">
        <input type="hidden" name="routeID" value="<?php echo $route_id;?>">
        <input type="submit" name="sendseats" style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; width: 120px; height: 40px;">

</div>
</form>
</center>




<?php
    }
}

//$thedate=$_SESSION['datepick'];

$get_seatno = "SELECT reserve_seats.seat_no FROM reserve_seats INNER JOIN reservations ON reservations.reserveID=reserve_seats.reserveID WHERE reserve_date='$rdate' AND routeID='$route_id'";
$result=$DBcon->query($get_seatno);

$store = array();
$store2= array();
$c=0;
while($row = $result->fetch_row()) {
    $store = array($row[0]);
    $store2[$c]=$store[0];
    $c++;
}
?>

<script type="text/javascript">

var limit = 2;
$('input.myseats').on('change', function(evt) {
   if($(this).siblings(':checked').length >= limit) {
       this.checked = false;
   }
});


function myFunction() {
<?php
for($k=0;$k<sizeof($store2);$k++)
{
?>
	document.getElementById('<?php echo $store2[$k]; ?>').disabled = true;
   
<?php 
}
?>
}
 	var counter=0;
 	var busfare=<?php echo $fare;?>;
 	var total=0;
 	var baggage=0;

function ChangeCheckboxLabel(ckbx)
{
   var d = ckbx.id;

   if( ckbx.checked )
   {
      document.getElementById(d+"-checked").style.display = "inline";
      document.getElementById(d+"-unchecked").style.display = "none";
      counter+=1;
      document.getElementById("numberofseats").innerHTML= counter;
   }
   else
   {
      document.getElementById(d+"-checked").style.display = "none";
      document.getElementById(d+"-unchecked").style.display = "inline";
      counter-=1;
      document.getElementById("numberofseats").innerHTML= counter;
   }
   	baggage=counter*2;
    total=counter*busfare;
   	document.getElementById("total").innerHTML= total;
    document.getElementById("mytotal").value= total;
}

var counter=0;
var busfare=<?php echo $fare;?>;
var total=0;

$(document).ready(function(){
    $checks = $(":checkbox");
    $checks.on('change', function() {
        var string = $checks.filter(":checked").map(function(i,v){
            return this.value;
        }).get().join(" ");
        $('.field_results').val(string);
    });
});

$(document).ready(function () {
    var $form = $('#tosearch');
    var $checkbox = $('.myseats');
    
    $form.on('submit', function(e) {
        if(!$checkbox.is(':checked')) {
            $('#noseat').text('No seat/s selected');
            e.preventDefault();
        }
    });
}); 
</script>

</body>
</html>