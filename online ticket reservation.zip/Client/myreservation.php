<?php
session_start();
require('dbconnect.php');
require('check.php');
require('sessioncheck.php');

if(!isset($_POST['reserveid']))
{
    header('location:timeout.php');
}
$reserveID=$_POST['reserveid'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$update_reservation = "UPDATE reservations SET status='cancelled' WHERE reserveID='$reserveID'";
    if ($DBcon->query($update_reservation))
    {
      $remove_seats="DELETE FROM reserve_seats WHERE reserveID='$reserveID'";
      $DBcon->query($remove_seats);
        echo "yes";
    }
    else 
    {
        echo "Error on cancelling reservation";
    }
?>