<html>
<head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>


<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
<input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">

<script>

var limit = 4;
$('input.myseats').on('change', function(evt) {
   if($(this).siblings(':checked').length >= limit) {
       this.checked = false;
       alert("You only booked "+limit+" seats");
   }
});
</script>

</body>

</html>