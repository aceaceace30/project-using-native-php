<?php
session_start();
require('dbconnect.php');
require('check2.php');
require('sessioncheck.php');
require('select.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {

if(isset($_POST['payment_btn']))
{
$holder=array();
$holder=$_POST['seats'];
$route_id=$_SESSION['routeid'];
$mytotal=$_POST["mytotal"];
$_SESSION['totalfare']=$mytotal;
$seats_sel=$_POST["customerseats"];
$_SESSION['allseats']=$seats_sel;
$avail=0;

$reservecount=0;

  $reserve_count="SELECT * FROM reservations WHERE status='reserve' AND userID='".$_SESSION['userid']."'";
  $result=$DBcon->query($reserve_count);

  if($result->num_rows>0)
  {
    while($rows=$result->fetch_assoc())
    {
      $reservecount++;
    }
  }

$sql = "SELECT * FROM routes_schedules WHERE routeID='$route_id'";
$result = $DBcon->query($sql);

if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
    	$avail=$row['available_seats'];
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL - Check out</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://www.paypalobjects.com/api/checkout.js"></script>
<script>
    function restriction()
    {
      var counter_restric=<?php echo $reservecount; ?>;
      if(counter_restric>0)
      {
        alert("Sorry, but you are only limited to make 1 reservation...");
        window.location.replace("http://travel-lokal-ph.com/index.php");;
      }
    }
  </script> 
</head>
</body>

<div class="wrapper row1">
        <header id="header" class="clear"> 
          <div id="logo">
            <h1><a href="../index.php"><img src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
          </div>
        </header>
    </div>

    <div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
    </ul>
  </nav>
</div>
  <div id="dashboard">
       <ul id="progress">
        <li class="active" onClick="document.location.href='datatable.php'"><i class="fa fa-check check" aria-hidden="true"></i> 1. Schedule</li>
        <li class="active" onClick="document.location.href='seats.php'"><i class="fa fa-check check" aria-hidden="true"></i> 2. Pick Seats</li>
        <li class="active">3. Payment</li>
    </ul><hr><br><br>
    		<div id="pickseats">
    		  <strong><label>Summary</label></strong>
    		  <hr><br>
	          <label class="bold" for="date"><span style="margin-right: 125px;">Date:</span><?php echo $_SESSION["datepick"]; ?></label><br>
	          <label class="bold"  for="Schedule"><span style="margin-right: 95px;">Schedule:</span><?php echo $row["time_sched"]; ?><br><br>
	          <label class="bold"  for="From"><span style="margin-right: 125px;">From:</span><?php echo $row["from_location"]; ?><br><br>
	          <label class="bold"  for="Destination"><span style="margin-right: 80px;">Destination:</span><?php echo $row["destination"]; ?><br><br>
	          <label class="bold"  for="Bus_Company"><span style="margin-right: 60px;">Bus Company:</span><?php echo $row["company"]; ?></label><br>
	          <label class="bold"  for="Type"><span style="margin-right: 125px;">Type:</span><?php echo $row["type"]; ?></label><br>
	          <label class="bold"  for="Fare" id="fare"><span style="margin-right: 130px;">Fare:</span><?php echo $row["fare"];?><br><br>
	     
	          <?php
	      }
	  }
	           ?>
	          <form action="reservations.php" method="GET">
	          <input type="hidden" name="mytotal" value="<?php echo $mytotal; ?>">
	          <input type="hidden" name="idroute" value="<?php echo $route_id;?>">
 	          <input type="hidden" name="seats_array" value='<?php echo htmlentities(serialize($holder)); ?>'>	               
	          <label for="seatselected"><span style="margin-right: 60px;">Selected Seats:</span><?php echo $seats_sel;?></label><br>      
	          <label for="Total"><span style="margin-right: 90px;">Total Price:</span><?php echo $mytotal; }}
            else
            { header('location:../index.php');
              }?></label><br><br><br><br><br><br>

	       </div>
	          <div id="rightseats" style="height: 460px;">
	          <strong><label style="color: black;">Payment Options</label></strong>
	          <hr><br><br>
            <center><input type="checkbox" id="license" name="license" style="display: inline-block;"> I accept the <a onclick="document.getElementById('licensemod').style.display='block'" style="text-decoration: underline;" href="#license">Licence and Agreement</a></center>
	          <input style="background: gray" type="submit" id="walkin" name="reserve_btn" onclick="reserve_success();" value="BANK DEPOSIT/TRANS" disabled>
	          <br><br><br><center><label>OR</label></center>
	          </form>
	          <form action="user_checkout.php" method="post" autocomplete="off">
                  <input type="hidden" name="mytotal" value="<?php echo $mytotal; ?>">
                  <input type="hidden" name="idroute" value="<?php echo $route_id;?>">
                  <input type="hidden" name="seats_array" value='<?php echo htmlentities(serialize($holder)); ?>'>  
                  <input type="hidden" name="product" value="Travel Lokal Bus Ticket">
                  <input type="hidden" name="price" value="<?php echo $mytotal; ?>">
                  <input style="background: gray;" type="submit" id="paypal" value="PAYPAL PAYMENT" disabled>
            </form>
	         </div>
			  </div>	

<div id="licensemod" class="instrucmodal">
  <form class="instruc-content animate" method="post" action="index.php" enctype="multipart/form-data">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('licensemod').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="instrucontainer" style="text-align: left;"><br>  
    <center><h1>Terms and Conditions</h1></center>
     <hr><br>
    <p>1. Please present the voucher or the text you will received to our terminal teller to redeem your ticket. <br><br>
       2. If you choose to pay bank deposit/transfer. You should pay approximately 12 hrs before your trip schedule or else it will be cancelled unless we were informed for the cause of delayed payment. <br><br>
       3. Should there be changes to your plans and you wish to reschule your trip, please email/contact the Administrator at info@travellokal.com / 09123456789 <br><br>
       4. Cancellations are not allowed. If payments are already sent. Absolutely no refunds will be given unless its companies fault.<br><br>
       5. Pets are not allowed at the Terminal.<br><br>
       6. You must confirm/pay first your booking before you can reserve again.

    </p>
    <strong><label>BUS TERMINAL TICKETS</label></strong>
    <p>
      1. Bus Terminal tickets are non-refundable except only in cases of force majeure or trip cancellations through the fault of the company, in which case the passenger has the option to claim a refund or to rebook the ticket, without any surcharge, within fifteen (15) calendar days from the trip date written on the ticket. However, the passenger may likewise rebook this ticket at any time before the departure date or within (15) calendar days from the trip date appearing on the ticket. Failure to rebook the ticket within the aforesaid period shall result in forfeiture of paid fare in favor of the company.<br><br>
      2. Bus Terminal assumes no liability for loss or damage of effects, luggage or other personal belongings carried by the passengers, unless these are declared and shown to, and a list thereof is given and freight charges are paid thereon to the shipping clerk or conductor, and the passenger complies with the instructions of the shipping clerk or conductor relative to their care and safekeeping.<br><br>
      4. Lost passenger tickets for any cause whatsoever shall not be returned or replaced by the company and the passenger will be required to pay his/her fare anew.<br><br>
      5. Any unauthorized erasure or alteration of the information stated in the ticket voucher send to you, shall render it null and void.
 <br><br>
    </p>
    </div>  
  </form>
</div>


<script>
$("#license").click(function(){
    if (this.checked) {
        $('#walkin').css('background-color', '#00aaff');
        $("#walkin").attr("disabled", !this.checked);
        $('#paypal').css('background-color', 'green');
        $("#paypal").attr("disabled", !this.checked);
    }
    else {
       $('#walkin').css('background-color', 'gray');
       $("#walkin").attr("disabled", "disabled");
       $('#paypal').css('background-color', 'gray');
       $("#paypal").attr("disabled", "disabled");
    }
}) 
function reserve_success()
{
	alert("Your reservation was successful. An email and text was sent to your email and phone for instructions. THANK YOU");
}

</script>


<body>
</html>