<?php

require('dbconnect.php');

$email = strip_tags($_POST['email']);
$email = $DBcon->real_escape_string($email);
$name = strip_tags($_POST['name']);
$name = $DBcon->real_escape_string($name);
$message_body = strip_tags($_POST['message_body']);
$message_body = $DBcon->real_escape_string($message_body);


$send_mes = "INSERT INTO contact_us(con_email,con_name,message_body) values('$email','$name','$message_body')";
    if ($DBcon->query($send_mes))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on sending message";
    }

?>