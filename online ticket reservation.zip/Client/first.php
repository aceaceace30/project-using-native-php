<?php

define('SITE_URL','http://travel-lokal-ph.com/Client/');

 require __DIR__  . '/PayPal-PHP-SDK/autoload.php';

 $apiContext = new \PayPal\Rest\ApiContext(
        new \PayPal\Auth\OAuthTokenCredential(
            'AZms6R5hlQHk89-xD_nTVfSsx8b5ho4F9s8WevZ_wX4ClcYzS0G8YM0Zgk2ne2xmdSTrfLtkG3qlgLBt',     // ClientID
            'ECfbrHNnm7YgZUSku4evvFdgVydqbp8FDPq5RBZYSHyC1844dyz6yEKkGrrwZ7mXC7uA7bxaGzfI9Vau'      // ClientSecret
        )
);

?>