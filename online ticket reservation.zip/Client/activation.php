<?php
session_start();
require('dbconnect.php');
if(!isset($_SESSION['activate']))
{
  header('location:../index.php');
}
require('select.php');
include ( "./src/NexmoMessage.php" );
//require('validation.php');

$error_message="";
$resend_message="";
$userid=$_SESSION['userid'];
$get_activation="SELECT * FROM activation_code WHERE userID='$userid'";

$result=$DBcon->query($get_activation);
        if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                $activation_code=$row['activation_code'];
              }
            }

if(isset($_POST['btn_activation']))
{
	$user_activation=$_POST['code'];

	if($user_activation==$activation_code)
	{
		$update_active="UPDATE users SET activated='yes' WHERE userID='$userid'";
		$DBcon->query($update_active);

    if(isset($_SESSION['routeid']))
    {
      header("location:seats.php?id=".$_SESSION['routeid']);
    }
    else
    {
		  header('location:../index.php');
    }
	}
	else
	{
		$error_message="WRONG ACTIVATION CODE";
	}
}

if(isset($_POST['send_activation']))
{
	$random_code=rand(10000000,99999999);
	$update_code="UPDATE activation_code SET activation_code='$random_code' WHERE userID='$userid'";
	$DBcon->query($update_code);
  $get_message = "SELECT * FROM sms_message WHERE id='1'";
        $result4=$DBcon->query($get_message);
        if ($result4->num_rows > 0) {
              while($row3 = $result4->fetch_assoc()) {
                $message=$row3["message"];
              }
            }
    $number=$_SESSION['phonenumber'];
    $nexmo_sms = new NexmoMessage('40562a26', 'fa58cd0cd011856f');
    // Step 2: Use sendText( $to, $from, $message ) method to send a message. 
    $info = $nexmo_sms->sendText( '+'.$number, 'MyApp', $message.$random_code);
    // Step 3: Display an overview of the message
}

?>
<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="../index.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/Travel-Lokal-839843849505011/" target="blank"><i class="fa fa-facebook"></i></a></li>
      </ul>
    </div>
</header>
</div>

<div class="wrapper row2">
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <div style="margin-left: 85%; display: inline-block">
       <?php
      if(isset($_SESSION["email"]))
      {
      ?>
       <li><a class="drop" href="#"><span style="text-transform: capitalize;">Hi,</span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
        <form id="customer_frm">
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </form>
        </ul>
     </li>
      <?php
      }
      else
      {
      ?>
      <li><a onclick="document.getElementById('id01').style.display='block'" href="#id01">LOGIN</a></li>
      <li style="margin-left: -30px;">/</li>
      <li style="margin-left: -30px;"><a onclick="document.getElementById('id02').style.display='block'" href="#id01">REGISTER</a></li>
      <?php
      }
      ?>
      </div>
    </ul>
  </nav>
</div>

<form action="activation.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: 423px; margin-top: 120px;">
    <div style="border: 1px solid gray; border-radius: 5px; height: auto; width: 420px; padding: 20px; margin-left: 33%;">
     <div class="col-lg-12">
        <center><h3>ENTER 6-DIGIT ACTIVATION CODE</h3></center>
      </div>
		<center><span style="color: red;"><?php echo $error_message; ?><span style="color: #00e600;"><?php echo $resend_message; ?></span></span><br><input style="text-align: center;" size="35" type="text" name="code"><br><br>
		<button type="submit" name="btn_activation" style="background-color:#00e600; border-radius: 5px; color:white; height: 40px; border-style: none; width: 200px;">SUBMIT</button><br>
		<br> OR <br><br>
		<button type="submit" name="send_activation" style="background-color:#00aaff; border-radius: 5px; color:white; height: 40px; border-style: none; width: 200px;">RESEND ACTIVATION CODE</button></center>
	</div>
 </div>
</div>
</form>

</body>
</html>