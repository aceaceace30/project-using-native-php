<?php
use PayPal\Api\Payer;
use PayPal\Api\Item;
use PayPal\Api\Details;
use PayPal\Api\Amount;
use PayPal\Api\ItemList;
use PayPal\Api\Transaction;
use PayPal\Api\RedirectUrls;
use PayPal\Api\Payment;

session_start();
require ('first.php');
require('dbconnect.php');

$myid=$_SESSION['userid'];
$mydate=$_SESSION['datepick'];
$_SESSION['allseats2']=$_SESSION['allseats'];

if(!isset($_POST['product'],$_POST['price']))
{
	die();
}


$seats_array=unserialize($_POST['seats_array']);
$_SESSION['myseats_arr']=$seats_array;
    
$product=$_POST['product'];
$price=$_POST['price'];
$shipping=0.00;

$total=$price+$shipping;

$payer = new Payer();
$payer->setPaymentMethod('paypal');

$item= new Item();
$item->setName($product)
	->setCurrency('PHP')
	->setQuantity('1')
	->setPrice($price);

$itemList= new ItemList();
$itemList-> setItems([$item]);

$details = new Details();
$details ->setShipping($shipping)
	->setSubtotal($price);

$amount = new Amount();
$amount ->setCurrency('PHP')
	->setTotal($total)
	->setDetails($details);

$transaction = new Transaction();
$transaction->setAmount($amount)
	->setItemList($itemList)
	->setDescription('Bus ticket Payment')
	->setInvoiceNumber(uniqid());

$redirectUrls = new RedirectUrls();
$redirectUrls->setReturnUrl(SITE_URL . 'thankyou.php?success=true')
	->setCancelUrl(SITE_URL . 'thankyou.php?success=false');

$payment= new Payment();
$payment->setIntent('sale')
	->setPayer($payer)
	->setRedirectUrls($redirectUrls)
	->setTransactions([$transaction]);

try{
	$payment->create($apiContext);
}catch(Exception $e)
{
	die($e);
}

$approvalUrl = $payment->getApprovalLink();


header("Location: {$approvalUrl}");


?>

<input type="hidden" name="mytotal" value="<?php echo $mytotal; ?>">
<input type="hidden" name="idroute" value="<?php echo $route_id;?>">
<input type="hidden" name="seats_array" value='<?php echo htmlentities(serialize($holder)); ?>'>  