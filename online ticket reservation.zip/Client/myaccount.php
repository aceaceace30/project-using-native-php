<?php
require('dbconnect.php');

$userid=$_POST['userid'];
$array_accountdetails=array();

$selectacc="SELECT * FROM users WHERE userid='$userid'";

          $result = $DBcon->query($selectacc);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            	echo $row["email"].",".$row["password"].",".$row["firstname"].",".$row["lastname"].",".$row["phonenumber"];                  	
            }
        }
        else
        {
        	echo "error on viewing";	
        }
?>