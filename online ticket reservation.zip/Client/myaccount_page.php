<?php
session_start();
require('sessioncheck.php');
require('check.php'); 
require('dbconnect.php');
$userid=$_SESSION['userid'];
?>

<!DOCTYPE html>
  <html>
  <head>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  </head>
  <body>
    
    <?php
      
          $selectaccount="SELECT * FROM users WHERE userid='$userid'";

          $result = $DBcon->query($selectaccount);
          if ($result->num_rows > 0) {
            echo "<table><tr><th>Email</th><th>First Name</th><th>Last Name</th><th>Phone Number</th></tr>";
            while($row = $result->fetch_assoc()) {
  
                echo "<tr><td>" . $row["email"]. "</td><td>" . $row["firstname"]. "</td><td>" . $row["lastname"]. "</td><td>" . $row["phonenumber"]. "</td>"?><td><button type="button" id='<?php echo $row["userid"];?>' class="btn_view_account btn-info btn-lg" data-toggle="modal" data-target="#myModal">Edit</button></td></tr>
    <?php
    }   
      echo "</table>";
    } else {
      echo "<br>No Account";  
    }
    $DBcon->close();
    ?>

    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title" style="color:green">Account Details</h4>
      </div>
      <div class="modal-body">
      <p id="myfname"></p>
      <p id="mylname"></p>
      <p id="myemail"></p>
      <input type="password" id="mypass">
      <input type="text" id="myphone">
      </div>
      <div class="modal-footer">
        <button type="button" id="confirm" class="btn btn-default" id="modal_routesave" data-dismiss="modal">Yes</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
      </div>
    </div>

  </div>
</div>

 <script>
    $(document).ready(function(){
      $('.btn_view_account').click(function(e) {
        e.preventDefault();
        
        userid=($(this).attr("id"));
        $.ajax({
        type:"POST",
        url:"myaccount.php",
        data:{'userid':userid},
        success:function(value){
          var data=value.split(",");
          $('#myemail').html(data[0]);
          $('#mypass').val(data[1]);
          $('#myfname').html(data[2]);
          $('#mylname').html(data[3]);
          $('#myphone').val(data[4]);
        }        
    });
  });

      $("#confirm").click(function(e){
        e.preventDefault();
        var mypass=$('#mypass').val();
        var myphone=$('#myphone').val();
        /*if(bus_name=="")
        {
            $('#error_busname').html("Bus name cannot be empty");
            return false;
        }*/
          $.ajax({
            type:"POST",
            url:"editmyaccount.php",
            data:{'userid':userid,
                  'mypass':mypass,
                  'myphone':myphone},
            success:function(data){
              if(data=='yes')
              {
                window.location.href = window.location;
              }
              else
              {
                alert(data);
              }
            }
          });
        }); 

});
 </script>


</body>
</html>