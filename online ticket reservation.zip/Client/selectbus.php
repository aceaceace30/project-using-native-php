<!--  Select All Buses   -->

<?php 
$sql = "SELECT b.BusName, b.Bus_Company, b.Type, rs.from_location, rs.destination, rs.time_sched, rs.fare FROM routes_schedules as rs INNER JOIN bus as b ON rs.BusId=b.BusID WHERE b.Bus_Company='Mega Bus'";

$result = $DBcon->query($sql);


?>