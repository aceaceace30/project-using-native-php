<!DOCTYPE HTML>
<html lang="en-US">
<head>
 <meta charset="UTF-8">
 <title></title>
  <style>
   input[type="checkbox"] {
  display: none;
}
label {
  cursor: pointer;
}
input[type="checkbox"] + label:before {
  border: 1px solid #7f83a2;
  content: "\00a0";
  display: inline-block;
  font: 16px/1em sans-serif;
  height: 16px;
  margin: 0 .25em 0 0;
  padding: 0;
  vertical-align: top;
  width: 16px;
}
input[type="checkbox"]:checked + label:before {
  background: yellow;
  content: "\2713";
  font-size: 20px;
}
input[type="checkbox"]:checked + label:after {
  font-weight: bold;
}


input[type="checkbox"]:disabled + label:before{
     border-color: #eee;
    color: #ccc;
}
 
  </style>
</head>
<body>

<div class="content">
  <div class="box">
    <p>
      <input type="checkbox" id="c1" name="cb">
      <label for="c1"> I have a bike</label>
    </p>
</div>
</div>
 
</body>
</html>﻿