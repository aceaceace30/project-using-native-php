<?php
session_start();
require('dbconnect.php');
require('check.php');
require('select.php');
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="../index.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/Travel-Lokal-839843849505011/" target="blank"><i class="fa fa-facebook"></i></a></li>
      </ul>
    </div>
</header>
</div>
<div class="se-pre-con">
 <center><img src="../GlobalImages/profile1.png" style="width: 250px; height: 250px"><br>
  <h1>Travel Lokal</h1></center><br>
</div>
<div class="wrapper row2">
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true" ></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-road icon" aria-hidden="true"></i>
      <li><a href="terminals_fares.php">Terminals & Fares</a></li>
      <i class="fa fa-phone icon" aria-hidden="true" style="color:#33bbff"></i>
      <li class="active"><a href="contact_us.php">Contact Us</a></li>
      <div style="margin-left: 550px; display: inline-block">
       <?php
      if(isset($_SESSION["email"]))
      {
      ?>
       <li><a class="drop" href="#"><span style="text-transform: capitalize;">Hi,</span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
        <form id="customer_frm">
          <li><a onclick="document.getElementById('editaccount').style.display = 'block'" id='<?php echo $_SESSION["userid"];?>' name="editacc"  href="#editaccount"><i class="fa fa-user" aria-hidden="true" style="color: lime;"></i> My Account</a></li>
          <li><a href="myreservation_page.php" id="myreservation_link"><i class="fa fa-book" aria-hidden="true" style="color: #00e6e6;"></i> My Reservation</a></li>
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </form>
        </ul>
     </li>
      <?php
      }
      else
      {
      ?>
      <?php
      }
      ?>
      </div>
    </ul>
  </nav>
</div>

<form action="contact_us.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto; margin-top: 20px; display: inline-block;">
    <div style="border: 1px solid gray; border-radius: 5px; height: auto; width: 600px; padding: 20px; margin-left: 2%;">
     <div class="col-lg-12">
        <h1 class="page-header" style="text-align: left; margin-left: 10px;">Send us a message</h1>
        <hr><br>
      </div>
        <center><span style="color: red;" id="message_con_email"></span></center>
        <label style="display: inline-block; margin-right: 35px;">Email:</label>
        <input type="text" size="40" id="contact_email" placeholder="Email"><br>
        <center><span style="color: red;" id="message_con_name"></span></center>
        <label style="display: inline-block; margin-right: 33px;">Name:</label>
        <input type="text" size="40"  id="contact_name" placeholder="Name"><br><br>
        <textarea style="display: inline-block; margin-left: 85px;" rows="10" cols="55" id="body_message" placeholder="Type your message here"></textarea></center>
        <center><span style="color: red;"id="message"></span><br>
        <span style="color: #4ce600;" id="message_thankyou"></span><br><br>
        <center><button id="send_message" value="Send" style="background-color:#00aaff; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SEND</button></center>
     </div>
    </div>

        <div style="margin: 20px 20px 20px 50px; color: #b30000;  width: auto; display: inline-block; position: absolute; border-color: black; height: 100px;">
          <h3 style="font-weight: bold;">Company Information</h3>
          <hr>
          <p>
            Travel Lokal<br>
            Pionner Bldg. 250 Sen. Gil Puyat Makati City<br>
            091234567890<br>
            info@travellokal.com<br>
          </p>
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3861.686264506665!2d121.0102049148398!3d14.559925189828382!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3397c96fea9faea7%3A0xbe2343d8e3c63a17!2sSTI-College+Makati!5e0!3m2!1sen!2sph!4v1504013487637" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
        </div>
    </div>
</form>

<script src="../GlobalJS/loginregister.js"></script>
<script>

$(document).ready(function(){
      $('#send_message').click(function(e) {
        e.preventDefault();
        $('#message_thankyou').html("");

        $("#contact_email").click(function(e){
          $('#message_con_email').html("");
          $('#message_thankyou').html(""); 
        });

        $("#contact_name").click(function(e){
          $('#message_con_name').html("");
          $('#message_thankyou').html(""); 
        });

        $("#body_message").click(function(e){
          $('#message').html("");
          $('#message_thankyou').html(""); 
        });

        var message_body=$('#body_message').val();
        var email=$('#contact_email').val();
        var name=$('#contact_name').val();
        if(email=="")
        {
        	$('#message_con_email').html("Enter your email");
        	return false;
        }
        if(name=="")
        {
        	$('#message_con_name').html("Enter your name");
        	return false;
        }
        if(message_body=="")
        {
        	$('#message').html("Message cannot be empty");
        	return false;
        }

        $.ajax({
        type:"POST",
        url:"send_contactmessage.php",
        data:{'email':email,
        	  'name':name,
        	  'message_body':message_body},
        success:function(value){
        	if(value=='yes')
        	{
        		$('#message_thankyou').html("Your message was sent, We will reach you as soon as posible. Thank you for helping us improve our performance!");
        		$('#message_con_email').html("");
        		$('#message_con_name').html("");
        		$('#message').html("");
            $('#contact_email').val("");
            $('#contact_name').val("");
            $('#body_message').val("");
        	}
          
        }        
    });
  });
});

$(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });
</script>
</body>
</html>