<?php
session_start();
require('dbconnect.php');
require('check.php');
require('sessioncheck.php');
require('select.php'); 
$userid=$_SESSION['userid'];
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="../index.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
    <div class="fl_right">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/Travel-Lokal-839843849505011/" target="blank"><i class="fa fa-facebook"></i></a></li>
      </ul>
    </div>
</header>
</div>

<div class="wrapper row2">
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-road icon" aria-hidden="true"></i>
      <li><a href="terminals_fares.php">Terminals & Fares</a></li>
      <i class="fa fa-phone icon" aria-hidden="true"></i>
      <li><a href="contact_us.php">Contact Us</a></li>
      <div style="margin-left: 550px; display: inline-block">
       <?php
      if(isset($_SESSION["email"]))
      {
      ?>
       <li class="active"><a class="drop" href="#"><span style="text-transform: capitalize;">Hi,</span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
        <form id="customer_frm">
          <li><a onclick="document.getElementById('editaccount').style.display = 'block'" id='<?php echo $_SESSION["userid"];?>' name="editacc"  href="#editaccount"><i class="fa fa-user" aria-hidden="true" style="color: lime;"></i> My Account</a></li>
          <li class="active"><a href="myreservation_page.php" id="myreservation_link"><i class="fa fa-book" aria-hidden="true" style="color: #00e6e6;"></i> My Reservation</a></li>
          <li><a href="user_history.php" id="myreservation_link"><i class="fa fa-book" aria-hidden="true" style="color: red;"></i> History</a></li>
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </form>
        </ul>
     </li>
      <?php
      }
      else
      {
      ?>
      <li><a onclick="document.getElementById('id01').style.display='block'" href="#id01">LOGIN</a></li>
      <li style="margin-left: -30px;">/</li>
      <li style="margin-left: -30px;"><a onclick="document.getElementById('id02').style.display='block'" href="#id01">REGISTER</a></li>
      <?php
      }
      ?>
      </div>
    </ul>
  </nav>
</div>

 <form action="myreservation_page.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: 540px;">
      <div class="col-lg-12">
        <h1 class="page-header">My Reservations</h1>
        <hr><br>
      </div> 
    
    <?php     
          $selectreserve="SELECT r.reserveID, rs.routeID, rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.payment_status FROM routes_schedules as rs INNER JOIN reservations as r ON rs.routeID=r.routeID WHERE r.status='reserve' AND r.userID='$userid' ORDER BY reserve_date";

          $result = $DBcon->query($selectreserve);
          if ($result->num_rows > 0) {
            echo "<table><tr><th>Company</th><th>Type</th><th>From</th><th>Destination</th><th>Seats</th><th>Date</th><th>Time</th><th>Total</th><th>Payment Type</th><th>Payment Status</th><th>Code</th><th>Action</th></tr>";
            while($row = $result->fetch_assoc()) {

              //getting the seats
              $r_id=$row["reserveID"];
              $getseats="SELECT * FROM reserve_seats where reserveID='$r_id'";
              $myresult=$DBcon->query($getseats);
              $seatarray=array();
              if($myresult->num_rows > 0) {
              while($row2 = $myresult->fetch_assoc()) {
                      $seatarray[]=$row2['seat_no'];
                  }
                }
              //getting the seats
                echo "<tr><td>" . $row["company"]. "</td><td>" . $row["type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>".$string=implode("," , $seatarray)."</td><td>" . $row["reserve_date"]. "</td><td>" . $row["time_sched"]. "</td><td>" . $row["fare_total"]. "</td><td>" . $row["payment_type"]. "</td><td>" . $row["payment_status"]. "</td><td>" . $row["code"]. "</td>";?>

                <td><button style="border-style: none; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;" onclick="document.getElementById('cancel').style.display = 'block'" type="button" class='btn_view' id='<?php echo $row["reserveID"];?>'>Cancel</button></td></tr>
                
    <?php
    }   
      echo "</table>";
    } else {
      echo "<br><center>No Reservation</center>";  
    }
    $DBcon->close();
    ?>

    </div>
  </div>
</form>

<div id="cancel" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('cancel').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center>Are you sure you want to cancel this reservation? It cannot be undone.</center>
    </div>
    <center><span style="color: red;" id="pass_err"></span><br>
    <input type="password" size="40" id="secpass"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button type="button" id="confirm_cancel" style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SUBMIT</button></center>
    </div>
  </form>
</div>

<div id="editaccount" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editaccount').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
   <center><h1>My Account</h1></center>
    <hr>
     <label style="margin: 15px 0 10px 20px;">First Name:</label><label style="margin: 15px 0 10px 57px; color: #595959;" id="myfname"></label><br>
     <label style="margin: 5px 0 10px 20px;">Last Name:</label><label style="margin: 5px 0 10px 60px; color: #595959;" id="mylname"></label><br>
     <label style="margin: 5px 0 10px 20px;">Email Name:</label><label style="margin: 5px 0 10px 50px; color: #595959;" id="myemail"></label><br>
      <label style="margin: 5px 65px 10px 20px;">Password: </label><input type="password" size="30" id="mypass"><br>
     <label style="margin: 5px 22px 10px 20px;">Phone Number: </label> <input type="text" size="30"  id="myphone">
    <hr>
    </div>
    <center><span style="color: red;" id="pass_err_user"></span><br>
    <input type="password" size="30" id="secpass_user" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color:#00aaff; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" id="confirm_edit">SAVE</button></center>  
    </div>
  </form>
</div>

</body>

 <script>
$(document).ready(function(){

      $('.btn_view').click(function(e) {
        e.preventDefault();
        reserveID=($(this).attr("id"));
      });

      $('#confirm_cancel').click(function(e){
      var securitypass=$('#secpass').val();

      if(securitypass=="")
      {
        $('#pass_err').html("Password cannot be empty");
        return;
      }
        
      $.ajax({
      type:"POST",
      url:"myreservation.php",
      data:{'securitypass':securitypass,
            'reserveid':reserveID},
      success:function(data){
        if(data=='yes')
        {
         alert("Reservation Cancelled");
         location.reload();
        }
        else if(data=='error')
        {
          $('#pass_err').html("Incorrect Password");
        }
        else
        { 
          alert(data);
        }
      }
    });
  });

      $('[name=editacc]').click(function(e) {
        e.preventDefault();
        
        userid=($(this).attr("id"));
        $.ajax({
        type:"POST",
        url:"myaccount.php",
        data:{'userid':userid},
        success:function(value){
          var data=value.split(",");
          $('#myemail').html(data[0]);
          $('#mypass').val(data[1]);
          $('#myfname').html(data[2]);
          $('#mylname').html(data[3]);
          $('#myphone').val(data[4]);
        }        
    });
  });

      $("#confirm_edit").click(function(e){
        e.preventDefault();
        var securitypass_user = $('#secpass_user').val();
        var mypass=$('#mypass').val();
        var myphone=$('#myphone').val();
        /*if(bus_name=="")
        {
            $('#error_busname').html("Bus name cannot be empty");
            return false;
        }*/
        if(securitypass_user=="")
        {
          $('#pass_err_user').html("Password cannot be empty");
          return;
        }
          $.ajax({
            type:"POST",
            url:"editmyaccount.php",
            data:{'userid':userid,
                  'mypass':mypass,
                  'myphone':myphone,
                  'securitypass':securitypass_user},
            success:function(data){
              if(data=='yes')
              {
                location.reload();
              }
              else if(data=='error')
              {
                $('#pass_err_user').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
            }
          });
        }); 
});


    </script>
</html>