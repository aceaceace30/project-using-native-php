<?php
session_start();
require('dbconnect.php');
require('sessioncheck.php');
date_default_timezone_set('Asia/Manila');
$t=time();
$time=date("h:i:sa");
$mydate1=date("m/d/Y",$t);


$reserveid=$_SESSION['reserveID'];
$total=$_SESSION['totalfare'];
$myseats=$_SESSION['allseats'];
$lname=$_SESSION['lastname'];
$fname=$_SESSION['firstname'];
$fullname=$fname . ' ' . $lname;
$combination=$_SESSION['combination'];


$getroute="SELECT r.reserveID, rs.routeID,  rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.payment_status, rs.fare FROM routes_schedules as rs INNER JOIN reservations as r ON rs.routeID=r.routeID WHERE r.status='reserve' AND r.reserveID='$reserveid'";

$result=$DBcon->query($getroute);

    if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {

        $buscompany=$row['company'];
        $bustype=$row['type'];
        $from=$row['from_location'];
        $destination=$row['destination'];
        $sched=$row['time_sched'];
        $fare=$row['fare'];
        $reservedate=$row['reserve_date'];

    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Travel Lokal-Thank You!</title>
    <link rel="icon" href="../GlobalImages/profile1.png">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<center><div style="text-align: center; border-radius: 5px; width: 400px;">
<i style="color: #1aff1a;" class="fa fa-2x fa-check-circle" aria-hidden="true"></i><h1 style="display: inline-block; margin-left: 10px; color: #404040;"><i>Payment Successful!</i></h1><br>

<a href="../index.php" style="color: #0099e6;">Return to home</a>
<h4 style="color: #404040;">If you didn't receive any text message or email...</h4>
<a href="contact_us.php" style="color: #0099e6; display: inline"><h4>Contact us</h4></a>
<button onclick="myFunction()" style="background-color: #33bbff; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px;">Print Voucher</button>
</div></center>
<br>
<center>
    <div id="specific_page" style="color: #666666; border: 1px solid gray; padding: 10px; border-radius: 5px; width: 500px;"">
        <center><img src="../GlobalImages/profile1.png" height="50"></center><center><h3 style="display: inline-block; margin-bottom: -10px;">Travel Lokal</h3><p>451, Ortigas Avenue, Pasig,<br> Metro Manila<br>
        +639123456789<br>
        infotravellokal@gmail.com</p><hr><br>
        <div style="text-align: left;">
        <center>
        <label style="margin-right: 38px;">DATE OF TRANSACTION:</label><?php echo $mydate1; ?><br><br>
        <label style="margin-right: 38px;">TIME OF TRANSACTION:</label><?php echo $time; ?><br><br>
        <label style="margin-right: 55px;">NAME OF PASSENGER:</label><?php echo $fullname; ?><br><br>
        <label style="margin-right: 105px;">BUS COMPANY:</label><?php echo $buscompany; ?><br><br>
        <label style="margin-right: 165px;">BUS TYPE:</label><?php echo $bustype; ?><br><br>
        <label style="margin-right: 205px;">FROM:</label><?php echo $from; ?><br><br>
        <label style="margin-right: 215px;">TO:</label><?php echo $destination; ?><br><br>
        <label style="margin-right: 115px;">BOOKED DATE:</label><?php echo $reservedate; ?><br><br>
        <label style="margin-right: 195px;">TIME:</label><?php echo $sched; ?><br><br>
        <label style="margin-right: 185px;">SEAT NO.:</label><?php echo $myseats;?><br><br>
        <label style="margin-right: 180px;">CODE:</label><?php echo $combination;?><br><br>
        <label style="margin-right: 215px;">FARE:</label><?php echo $fare; ?><br><br>
        <label style="margin-right: 205px;">TOTAL:</label><?php echo $total; ?><br><br></center>
        </div><br>
        <p>* Tickets must be claimed before the departure time otherwise the reservation will be forfeited.

To avoid forfeiture, please cancel your reservation an hour before the screening time:

ONLINE. Log on to Travel Lokal with your username and password. On the Transaction History page, you can view your current and past transactions. Each active reservation has a CANCEL button to cancel any particular reservation if the transaction has not already paid. Please cancel any reservation/s you do not intend to claim.

NOTE: We only accept deposit and mobile banking trasfer on paying through our BPI and BDO bank account.
</p><br><br>
<h4 style="color: #404040;"><i>Thank you for booking with Travel Lokal!</i></h4></center>
    </div>
</center>

<script>
function myFunction() {
var prtContent = document.getElementById("specific_page");
var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
WinPrint.document.write(prtContent.innerHTML);
WinPrint.document.close();
WinPrint.focus();
WinPrint.print();
WinPrint.close();
}
</script>
</body>


</html>