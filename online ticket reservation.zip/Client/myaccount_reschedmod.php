<?php
require('sessioncheck.php'); 
require('dbconnect.php');


if (isset($_GET['sendseats'])) 
{
   	$holder=array();
	$holder=$_GET['seats'];
	$reserveID=$_GET['reserveID'];

	$query2="DELETE FROM reserve_seats WHERE reserveID='$reserveID'";
	$DBcon->query($query2);
	for($b=0;$b<sizeof($holder);$b++)
    {
        $query3="INSERT INTO reserve_seats(reserveID,seat_no) values('$reserveID','$holder[$b]')";
        $DBcon->query($query3);
        header('location: myreservation_page.php');
    }
}

?>