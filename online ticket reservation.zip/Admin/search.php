<?php
require('dbconnect.php');
session_start();

?>
<html>
<head>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>

<body>
<?php
if (isset($_POST['search_btn'])) 
{

$from = strip_tags($_POST['from']);
$destination = strip_tags($_POST['destination']);
$datepicker = strip_tags($_POST['datepicker']);
 
$from = $DBcon->real_escape_string($from);
$destination = $DBcon->real_escape_string($destination);
$datepicker = $DBcon->real_escape_string($datepicker);

//query to get the route selected and display
$sql = "SELECT routeID, Bus_Company, Type, from_location, destination, time_sched, available_seats, fare FROM routes_schedules where from_location='$from' and destination='$destination'";

$result = $DBcon->query($sql);

$_SESSION["datepick"]=$datepicker;
echo "DATE: ".$datepicker;
if ($result->num_rows > 0) {
    echo "<table><tr><th>Bus Company</th><th>Type</th><th>From</th><th>Destination</th><th>Schedule</th><th>Available Seats</th><th>Fare</th></tr>";
    // output data of each row

    while($row = $result->fetch_assoc()) {
	
        echo "<tr><td>" . $row["Bus_Company"]. "</td><td>" . $row["Type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["time_sched"]. "</td><td>" . $row["available_seats"]. "</td><td>" . $row["fare"]. "</td>"?><td>
         <a href="seats.php?id=<?php echo $row["routeID"];?>">Select</a>
  		</td></tr>
        
  	<?php
    }		
    echo "</table>";
} else {
    echo "<br>NO SCHEDULE RESULT";	
}

}
	
$DBcon->close();
?>
</body>

</html>