<!--  Select   -->

<?php 
$sql = "SELECT * FROM home";

$result = $DBcon->query($sql);

   if ($result->num_rows > 0) {

    while($row = $result->fetch_assoc()) {
      $comp_name=$row['comp_name'];
      $comp_address=$row['comp_address'];
      $comp_number=$row['comp_number'];
      $comp_email=$row['comp_email'];
      $comp_map=$row['comp_map'];
      $first_slide=$row['first_slide'];
      $second_slide=$row['second_slide'];
      $third_slide=$row['third_slide'];
        }
    } 

?>
