<?php
require('dbconnect.php');
require('update.php');
require('select.php');
?>
     

<!DOCTYPE html>

<html>
<head>

<title>TRAVEL LOKAL</title>
<link rel="icon" href="images/profile.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layout.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css">


<linl href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css" rel="stylsheet">
<script src="//cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
    $('#myTable').DataTable();
});
      </script>
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear" style="margin-left: 20px;"> 
    <div id="logo">
      <h1><a href="index.html"><?php echo $comp_name; ?></a></h1>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav" style="margin-left: 20px;"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true" style="color:#33bbff"></i>
      <li class="active"><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Tables</a>
        <ul>
          <li><a href="table.php">Home</a></li>
          <li><a href="#" onclick="showUsers()">Users</a></li>
        </ul>
     </li>
      <li><a class="drop" href="#">Tables</a>
        <ul>
          <li><a href="#">Level 2</a></li>
          <li><a class="drop" href="#">Level 2 + Drop</a>
            <ul>
              <li><a href="#">Level 3</a></li>
              <li><a href="#">Level 3</a></li>
            </ul>
          </li>
        </ul>
      </li>
    </ul>
  </nav>
</div>




<form action="index.php" method="POST">

 <div id="dashboard">
    
  <div id="pnlHome" class="panels">
    
<div class="row">
      <div class="col-lg-12">
        <h1 class="page-header">Home</h1>
        <hr><br>
      </div>

        <div id="myTable">
      <?php 
      $sql = "SELECT * FROM home";
      $result = $DBcon->query($sql);

      if($result->num_rows > 0) {
      echo "<table><tr><th>ID</th><th>Company Name</th><th>Company Address</th><th>Company Number</th><th></th><th></th></tr>";
      }

       while($row = $result->fetch_assoc()) {
      
          echo "<tr><td>" .$row["home_id"]. "</td><td>" .$row["comp_name"]. "</td><td>" .$row["comp_address"]. "</td><td>" .$row["comp_number"]. "</td>"?>

          <td> <a id="btn_edit"><i style="color: #00aaff;" class="fa fa-pencil" title="Edit" aria-hidden="true"></i></a></td>
     
      <?php
      }   
      echo "</table>";
    
      ?> 

    </div>  
  </div><!--/.row-->    
  </div>

 <div id="pnlUsers" class="panels">
    
<div class="row">
      <div class="col-lg-12">
        <h1 class="page-header">Users</h1>
        <hr><br>
      </div>

        <div id="myTable">
      <?php 
      $sql1 = "SELECT userid, email, phonenumber, firstname, lastname FROM users";
      $result1 = $DBcon->query($sql1);

      if($result1->num_rows > 0) {
      echo "<table><tr><th>ID</th><th>Email</th><th>Phone Number</th><th>First Name</th><th>Last Name</th><th></th></tr>";
      }

       while($row = $result1->fetch_assoc()) {
      
          echo "<tr><td>" .$row["userid"]. "</td><td>" .$row["email"]. "</td><td>" .$row["phonenumber"]. "</td><td>" .$row["firstname"]. "</td><td>" .$row["lastname"]. "</td>"?>

          <td> <a id="btn_edit" ><i style="color: #00aaff;" class="fa fa-pencil" title="Edit" aria-hidden="true"></i></a></td>
     
      <?php
      }   
      echo "</table>";
        
      $DBcon->close();
      ?> 

    </div>  
  </div><!--/.row-->    
  </div>


 </div>  <!--/.main-->
 
</form>
<script>
function showUsers() {
   document.getElementById('pnlUsers').style.display = "block";
   document.getElementById('pnlHome').style.display = "none";
}
</script>

</body>
</html>