<?php
require('dbconnect.php');

$desID=$_POST['desID'];
$array_desdetails=array();

$selectdes="SELECT * FROM location_destination WHERE id='$desID'";

          $result = $DBcon->query($selectdes);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            	echo $row["location"].",".$row["destination"].",".$row["kilometers"];                  	
            }
        }
        else
        {
        	echo "error on viewing";	
        }


?>