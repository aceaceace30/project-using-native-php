<?php
require('dbconnect.php');

$route_busname=$_POST['route_busname'];
$route_location=$_POST['route_location'];
$route_destination=$_POST['route_destination'];
$route_fare = strip_tags($_POST['route_fare']);
$route_fare = $DBcon->real_escape_string($route_fare);
$route_sched=$_POST['route_sched'];
$route_sched=date('h:ia',strtotime($route_sched));

$getbusid="SELECT * FROM Bus WHERE BusName='$route_busname'";
$result = $DBcon->query($getbusid);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
    	$busid=$row['BusID'];
    }
}

$insertroute ="INSERT INTO routes_schedules(BusID,from_location,destination,available_seats,time_sched,fare) VALUES('$busid','$route_location','$route_destination','40','$route_sched','$route_fare')";
    if($DBcon->query($insertroute)) 
    {
    	$update_avail="UPDATE bus SET Availability='used' where BusID='$busid'";
    	$DBcon->query($update_avail);
        echo "yes";
    
    }
    else 
    {
        echo "error";
    }

?>