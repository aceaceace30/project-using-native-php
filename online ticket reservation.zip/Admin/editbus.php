<?php
session_start();
require('dbconnect.php');

$busname = strip_tags($_POST['bus_name']);
$busname = $DBcon->real_escape_string($busname);
$buscompany = strip_tags($_POST['buscompany']);
$buscompany = $DBcon->real_escape_string($buscompany);
$bustype = strip_tags($_POST['bustype']);
$bustype = $DBcon->real_escape_string($bustype);
$busid=$_POST['busid'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }
$updatebus = "UPDATE bus SET BusName='$busname', Bus_Company='$buscompany', Type='$bustype' WHERE busID='$busid'";
    if ($DBcon->query($updatebus))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on updating bus";
    }
?>