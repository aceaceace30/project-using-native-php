<?php
session_start();
require('dbconnect.php');

if(isset($_POST['bus_type']))
{
        $select_fk="SELECT * FROM ltfrb_rules WHERE id='1'";
        $result3=$DBcon->query($select_fk);

          if($result3->num_rows > 0) {
            while($row = $result3 -> fetch_assoc()) {
              $fk=$row['first_kilometers'];
            }
          }

        $select_pr="SELECT * FROM ltfrb_rules WHERE id='1'";
        $result4=$DBcon->query($select_pr);

          if($result4->num_rows > 0) {
            while($row = $result4 -> fetch_assoc()) {
              $price=$row['price'];
            }
          }

         $selected_type=$_POST['bus_type'];
         $destination=$_POST['destination'];
         $company_name=$_POST['company_name'];

        $select_km="SELECT * FROM location_destination WHERE destination='$destination'";
        $result1=$DBcon->query($select_km);

          if($result1->num_rows > 0) {
            while($row = $result1 -> fetch_assoc()) {
              $kilometers=$row['kilometers'];
            }
          }

          $select_comp_rate="SELECT * FROM companies as c INNER JOIN bustype_rate as br ON c.id=br.company_id WHERE c.company_name='$company_name' AND br.bustype='$selected_type'";
          $comp_rate=$DBcon->query($select_comp_rate);

          if($comp_rate->num_rows > 0) {
            while($row = $comp_rate -> fetch_assoc()) {
              $rate=$row['per_kilometer'];
            }
          }

          $newkilometers=$kilometers-$fk;
          echo round($rate * $newkilometers+$price);

}
?>