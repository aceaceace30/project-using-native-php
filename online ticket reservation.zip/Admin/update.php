<!--  Update   -->

<?php
      require('dbconnect.php');
      if (isset($_POST['editname'])) {
      $compname = $_POST['compname'];
      $sql = "UPDATE home SET comp_name='$compname' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }

      if (isset($_POST['editaddress'])) {
      $compaddress = $_POST['compaddress'];
      $sql = "UPDATE home SET comp_address='$compaddress' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }

      if (isset($_POST['editnumber'])) {
      $compnumber = $_POST['compnumber'];
      $sql = "UPDATE home SET comp_number='$compnumber' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }

      if (isset($_POST['editemail'])) {
      $compemail = $_POST['compemail'];
      $sql = "UPDATE home SET comp_email='$compemail' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }

      if (isset($_POST['editmap'])) {
      $compmap = $_POST['compmap'];
      $sql = "UPDATE home SET comp_map='$compmap' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }

      if (isset($_POST['slideshow'])) {
      $imageName = mysql_real_escape_string($_FILES["firstslide"]["name"]);
      $imageData = mysql_real_escape_string(file_get_contents($_FILES["firstslide"]["tmp_name"]));
      $imageName2 = mysql_real_escape_string($_FILES["secondslide"]["name"]);
      $imageData2 = mysql_real_escape_string(file_get_contents($_FILES["secondslide"]["tmp_name"]));
      $imageName3 = mysql_real_escape_string($_FILES["thirdslide"]["name"]);
      $imageData3 = mysql_real_escape_string(file_get_contents($_FILES["thirdslide"]["tmp_name"]));

      $sql = "UPDATE home SET first_slide='$imageData', second_slide='$imageData2', third_slide='$imageData3' WHERE home_id=1";
      $result = $DBcon->query($sql);
      header( 'Location: home.php' ) ;
      }
?>

