<!DOCTYPE html>
  <html>
  <head>
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/css/materialize.min.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  </head>

  <body>
    <script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.98.0/js/materialize.min.js"></script>
   
   <!-- MODAL ADD BUS -->
    <a class="waves-effect waves-light btn" href="#modal1">Add bus</a>

    <div id="modal1" class="modal">
      <div class="modal-content">

      <input type="text" placeholder="Bus name" name="busname" id="busname" required>
      <span id="error_busname"></span><br><br>

      <a class='dropdown-button btn' href='#' data-activates='dropdown1'>Bus Company:</a>
      <span id="error_buscompany"></span><br><br>

     <ul id='dropdown1' class='dropdown-content'> 
      <li><input type="button" class="buscompany" value="JACKLINER"></li>
      <li><input type="button" class="buscompany" value="GENESIS"></li>
      <li><input type="button" class="buscompany" value="JAMLINER"></li>
      </ul>

      <p id="showcompany"></p>

      <a class='dropdown-button btn' href='#' data-activates='dropdown2'>Bus Type:</a>
      <span id="error_bustype"></span><br><br>

     <ul id='dropdown2' class='dropdown-content'>
      <li><input type="button" class="bustype" value="AIRCON"></li>
      <li><input type="button" class="bustype" value="DELUXE"></li>
      </ul>

      <p id="showtype"></p>

      <!--<input type="number" value="40" name="seatsnumber" min=1 max=40>-->

      </div>
      <div class="modal-footer">
        <input type="button" class="modal-action waves-effect waves-green btn-flat" id="addbus_btn" value="Add bus">
        <!--<a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">OKAY</a>--> 
       </div>
    </div>
    <!-- MODAL ADD BUS -->


    <!-- MODAL SET ROUTES -->
    <a class="waves-effect waves-light btn" href="#modal2">Set Routes</a>

    <div id="modal2" class="modal">
      <div class="modal-content">

          <a class='dropdown-button btn' href='#' data-activates='dropdown3'>Select Bus:</a>
          <span id="error_selectbus"></span><br><br>

          <ul id='dropdown3' class='dropdown-content'> 
            <?php
            require('dbconnect.php');
            $busnames=array();

            $get_busnames="SELECT BusName FROM bus WHERE Availability='unused'";

            $result=$DBcon->query($get_busnames);

            if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                  $busnames[]=$row["BusName"];
              }
            }
            for($k=0;$k<sizeof($busnames);$k++)
            {
              echo "<li><input type='button' class='busnames' value='$busnames[$k]'></li>";
            }
            ?>
          </ul>

          <p id="showbusname"></p>

          <?php
            $store_value=array();
            $store_value2=array();
            $get_value ="SELECT DISTINCT location FROM location_destination";
            $result = $DBcon->query($get_value);
            if ($result->num_rows > 0) {
              while($row_result = $result->fetch_assoc()) {
                $store_value[]=$row_result["location"];
              }
            }
             $get_value2 ="SELECT DISTINCT destination FROM location_destination";
            $result2 = $DBcon->query($get_value2);
            if ($result2->num_rows > 0) {
              while($row_result2 = $result2->fetch_assoc()) {
                $store_value2[]=$row_result2["destination"];
              }
            }
            ?> 

          <a class='dropdown-button btn' href='#' data-activates='dropdown4'>From:</a>
          <span id="error_showloc"></span><br><br>

          <ul id='dropdown4' class='dropdown-content'>
            <?php for($n=0;$n<sizeOf($store_value);$n++){ 
            echo "<li><input type='button' class='from_loc' value='$store_value[$n]'></li>";
          }
          ?>
            
          </ul>

          <p id="showlocation"></p>

          <a class='dropdown-button btn' href='#' data-activates='dropdown5'>Destination:</a>
          <span id="error_showdes"></span><br><br>

          <ul id='dropdown5' class='dropdown-content'> 
            <?php for($x=0;$x<sizeOf($store_value2);$x++){ 
            echo "<li><input type='button' class='destination' value='$store_value2[$x]'></li>";
          }
          ?>
          </ul>

          <p id="showdestination"></p>

          <input type="text" placeholder="Fare" name="fare" id="fare" required>
          <span id="error_showfare"></span><br><br>

          Select a time:
          <input type="time" name="time" id="time">
          <span id="error_showtime"></span><br><br>

      </div>
      <div class="modal-footer">
        <input type="button" class="modal-action waves-effect waves-green btn-flat" id="addroute_btn" value="Add route">
        <!--<a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat">OKAY</a>-->   
       </div>
    </div>
    <!-- MODAL SET ROUTES -->

    <!-- EDIT BUS -->
    <form action="editbuspage.php" method="GET">
    <input type="submit" name="editbus" value="Edit Bus">
    </form>
    <!-- EDIT BUS -->

    <!-- EDIT ROUTE -->
    <form action="editroutepage.php" method="GET">
    <input type="submit" name="editroute" value="Edit Route">
    </form>
    <!-- EDIT ROUTE -->

    <!-- MANAGE RESERVATION -->
    <form action="manage_reservation.php" method="GET">
    <input type="submit" name="manage_res" value="Manage Reservation">
    </form>
    <!-- MANAGE RESERVATION -->
  

    <script src="busquery.js"></script>

    </body>
  </html>﻿