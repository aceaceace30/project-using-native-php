<?php
require('dbconnect.php');

$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($DBcon, $_POST["query"]);
 $query = "
  SELECT * FROM bus 
  WHERE Bus_Company LIKE '%".$search."%'
  OR BusName LIKE '%".$search."%'  
  OR Type LIKE '%".$search."%'
 ";
}
else
{
 $query = "SELECT * FROM bus";
}
$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
	echo "<div class='table-responsive:'>
					<table class='table table bordered'>
						<tr>
							<th>Body No.</th>
							<th>Bus Company</th>
							<th>Type</th>
							<th>No. of Seats</th>
							<th>Action</th>
							<th>Action</th>
						</tr>";
	while ($row = mysqli_fetch_array($result)) {
			echo "<tr>
					<td>".$row["BusName"]."</td>
					<td>".$row["Bus_Company"]."</td>
					<td>".$row["Type"]."</td>
					<td>".$row["No_of_seats"]."</td>"?>

                  <td><button onclick="document.getElementById('edit').style.display = 'block'" type="button" class="btn_view" id='<?php echo $row["BusID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ffb84d; font-size: 15px; height: 25px;">Edit</button></td>
                  <td><button onclick="document.getElementById('delete').style.display = 'block'" type="button" class="btn_view" id='<?php echo $row["BusID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Delete</button></td>

              	<?php

	}
		echo "</table>";
}
else
{
	echo '<center style="color: red;">Data Not Found</center>';
}

?>
<script >
$(document).ready(function(){
      $('.btn_view').click(function(e) {
        e.preventDefault();
        busID=($(this).attr("id"));

        $.ajax({
        type:"POST",
        url:"busphp.php",
        data:{'busID':busID},
        success:function(value){
          var data=value.split(",");
          $('#busname').val(data[0]);
          $('#buscompany').val(data[1]);
          $('#bustype').val(data[2]);
        }        
    });
  });
  $('#deletebus').click(function(e) {
        securitypass=$('#secpass_del').val();
        e.preventDefault();
        if(securitypass=="")
        {
          $('#pass_err_del').html("Password cannot be empty");
          return;
        }       
        $.ajax({
        type:"POST",
        url:"deletebus.php",
        data:{'busID':busID,
              'securitypass':securitypass},
        success:function(data){
              if(data=='yes')
              {
               window.location.href = window.location;
              }
              else if(data=='error')
              {
                $('#pass_err_del').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
        }        
    });
  });
  $("#modal_savebtn").click(function(e){
        securitypass=$('#secpass').val();
        e.preventDefault();
        var bus_name=$('#busname').val();
        var bus_company=$('#buscompany').val();
        var bus_type=$('#bustype').val();
        if(bus_name=="")
        {
          $('#error_busname').html("Bus name cannot be empty");
            return false;
        }
        if(securitypass=="")
        {
          $('#pass_err').html("Password cannot be empty");
          return;
        }
          $.ajax({
            type:"POST",
            url:"editbus.php",
            data:{'securitypass':securitypass,
                  'busid':busID,
                  'bus_name':bus_name,  
                  'buscompany':bus_company,
                  'bustype':bus_type},
            success:function(data){
              if(data=='yes')
              {
               //alert("Update Successful");
               window.location.href = window.location;
              }
              else if(data=='error')
              {
                $('#pass_err').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
            }
          });
        });

  $("#modal_addbus").click(function(e){
    e.preventDefault();
    var bus_name=$('#busname_add').val();
    var bus_company=$('#buscompany_add').val();
    var bus_type=$('#bustype_add').val(); 
    if(bus_name=="")
    {
      $('#error_busname2').html("Body number cannot be empty");
      return false;
    }
    $.ajax({
      type:"POST",
      url:"addbus.php",
      data:{'bus_name':bus_name,  
            'buscompany':bus_company,
            'bustype':bus_type},
      success:function(data){
        if(data=='yes')
        {
         //Materialize.toast("Successfully added "+bus_name, 4000);
         location.reload();
        }
      }
    });
  });  
});

  </script>