<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}   
?>
<!DOCTYPE html>
<html>
<head>	
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
   <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
      <li class="active"><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a class="active" href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Messages</h1>
        <hr><br>
      </div>   
<center>
<button onclick="myFunction()" style="background-color: #33bbff; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px;">PRINT PAGE</button>
</center><br>
<div id="print">
<?php
          $selectmessage="SELECT con_email, con_name, message_body FROM contact_us";

            $result = $DBcon->query($selectmessage);
            if ($result->num_rows > 0) {
            echo "<table><tr><th>Email</th><th>Name</th><th>Message</th></tr>";
            while($row = $result->fetch_assoc()) {
  
                echo "<tr><td>" . $row["con_email"]. "</td><td>" . $row["con_name"]. "</td><td>" . $row["message_body"]. "</td>";?></tr>
    <?php
    }   
      echo "</table>";
    } else {
      echo "<br>No Reservation";  
    }
    $DBcon->close();

    ?>

    </div>
  </div>

</div>
</div>

<script>
function myFunction() {
    var prtContent = document.getElementById("print");
    var WinPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
}
</script>

</body>
</html>