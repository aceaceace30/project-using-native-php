<?php
require('dbconnect.php');

$routeID=$_POST['routeID'];
$array_routedetails=array();

$selectroute="SELECT * FROM routes_schedules WHERE routeID='$routeID'";

          $result = $DBcon->query($selectroute);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            	echo $row["company"].",".$row["type"].",".$row["from_location"].",".$row["destination"].",".$row["time_sched"].",".$row["fare"];                  	
            }
        }
        else
        {
        	echo "error on viewing";	
        }
?>