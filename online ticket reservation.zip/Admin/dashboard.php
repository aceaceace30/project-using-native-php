<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}    

date_default_timezone_set('Asia/Manila');
$t=time();
$mydate=date("m/d/Y",$t);

$usercount = "SELECT * FROM users WHERE usertype='member'";
$usercount1 = $DBcon->query($usercount);
$usercount=0;
if($usercount1->num_rows > 0) {
while ($row = $usercount1->fetch_assoc()) {
   $usercount++;
  }
}

$reservequer = "SELECT * FROM reservations WHERE status ='reserve'";
$reservecount1 = $DBcon->query($reservequer);
$reservecount=0;
if($reservecount1->num_rows > 0) {
while ($row = $reservecount1->fetch_assoc()) {
   $reservecount++;
  }
}

$upcoming = "SELECT * FROM reservations WHERE status ='reserve' AND reserve_date='$mydate'";
$upcoming1 = $DBcon->query($upcoming);
$upcomingcount=0;
if($upcoming1->num_rows > 0) {
while ($row = $upcoming1->fetch_assoc()) {
   $upcomingcount++;
  }
}

$contact = "SELECT * FROM contact_us";
$contact1 = $DBcon->query($contact);
$contactcount=0;
if($contact1->num_rows > 0) {
while ($row = $contact1->fetch_assoc()) {
   $contactcount++;
  }
}

?>
     
<!DOCTYPE html>
<html>
<head>

<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true" style="color:#33bbff"></i>
      <li class="active"><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    <li style="margin-left: 320px;"><a class="drop" href="#"><span style="text-transform: capitalize;">Admin: </span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
    </ul>

  </nav>
</div>

<form action="home.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: 540px;">
  <div class="se-pre-con1"></div>
      <div class="col-lg-12">
        <h1 class="page-header">Dashboard</h1>
        <hr><br>
      </div>
 
      <div class="borders">
    <div class="inborders red">
      <i class="fa fa-bell-o fa-5x" aria-hidden="true"></i>
    </div>
        <div class="right">
          <div class="large"><?php echo $upcomingcount; ?></div>
              <div class="text-muted">Arrivals</div>
      </div>

    </div>   
    <div class="borders">
    <div class="inborders brown">
      <i class="fa fa-list-alt fa-5x" aria-hidden="true"></i>
    </div>
        <div class="right">
          <div class="large"><?php echo $reservecount; ?></div>
              <div class="text-muted">Books</div>
        </div>
    </div>

    <div class="borders">
    <div class="inborders blue">
      <i class="fa fa-user-o fa-5x" aria-hidden="true"></i>
    </div>
        <div class="right">
          <div class="large"><?php echo $usercount; ?></div>
              <div class="text-muted">Users</div>
        </div>
    </div>

     <div class="borders">
    <div class="inborders green">
      <i class="fa fa-commenting-o fa-5x" aria-hidden="true"></i>
    </div>
        <div class="right">
          <div class="large"><?php echo $contactcount; ?></div>
              <div class="text-muted">Feedbacks</div>
        </div>
    </div>
</div>


 <div id="pnlUsers" class="panels" style="display: none;">
    <div class="col-lg-12">
      <h1 class="page-header">Users</h1>
    </div>
<hr>
    <input type="text" name="" placeholder="search" style="float: right; margin-right: 20px; border-radius: 5px;">
    <div id="myTable">
      <?php 
      $sql1 = "SELECT userid, email, phonenumber, firstname, lastname FROM users limit 0,10";
      $result1 = $DBcon->query($sql1);

      if($result1->num_rows > 0) {
      echo "<table><tr><thead><th>ID</th><th>Email</th><th>Phone Number</th><th>First Name</th><th>Last Name</th><th></th></tr>";
      

       while($row = $result1->fetch_assoc()) {
      
          echo "<tbody><tr><td>" .$row["userid"]. "</td><td>" .$row["email"]. "</td><td>" .$row["phonenumber"]. "</td><td>" .$row["firstname"]. "</td><td>" .$row["lastname"]. "</td>"?>

          <td> <a id="btn_edit" ><i style="color: red;" class="fa fa-trash-o" title="Delete" aria-hidden="true"></i></a></td>
      <?php
      }    
      echo "</table>";

      } 

      $DBcon->close();
      ?> 
      </div>    
    </div>    
 </div>  <!--/.main-->
 
</form>
<script>

$(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con1").fadeOut("slow");;
  });

</script>

</body>
</html>