<?php 
require('dbconnect.php');
if(isset($_POST['selected_type']))
{
	$selected_type=$_POST['selected_type'];
	$destination=$_POST['destination'];

	$select_km="SELECT * FROM location_destination WHERE destination='$destination'";
	 	$result1=$DBcon->query($select_km);

	 		if($result1->num_rows > 0) {
	 			while($row = $result1 -> fetch_assoc()) {
	 				$kilometers=$row['kilometers'];
	 			}
	 		}

	 $select_perkm="SELECT * FROM bustype_rate WHERE bustype='$selected_type'";
	 	$result=$DBcon->query($select_perkm);

	 		if($result->num_rows > 0) {
	 			while($row = $result -> fetch_assoc()) {
	 				$rate=$row['per_kilometer'];
	 			}
	 		}
	 	echo round($rate * $kilometers+120);
}

?>