<?php
session_start();
require('dbconnect.php');

$route_type=$_POST['type'];
$route_location=$_POST['location'];
$route_destination=$_POST['destination'];
$route_fare = strip_tags($_POST['fare']);
$route_fare = $DBcon->real_escape_string($route_fare);
$route_sched=$_POST['sched'];
$route_sched=date('h:ia',strtotime($route_sched));
$routeID=$_POST['routeID'];

$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$updateroute = "UPDATE routes_schedules SET type='$route_type', from_location='$route_location', destination='$route_destination', time_sched='$route_sched', fare='$route_fare' WHERE routeID='$routeID'";
    if ($DBcon->query($updateroute))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on updating route and schedule";
    }

?>