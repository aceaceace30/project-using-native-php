<?php
session_start();
require('dbconnect.php');
require('select.php');
//if(!isset($_SESSION["checkadmin"])){
 //   header("location:adminlogin.php");
//}  
?>
<!DOCTYPE html>
<html>
<head>	
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
  $(document).ready(function(){
    $("#txtFromDate").datepicker({
        onSelect: function(selected) {
          $("#txtToDate").datepicker("option","minDate", selected)
        }
    });
    $("#txtToDate").datepicker({ 
        onSelect: function(selected) {
           $("#txtFromDate").datepicker("option","maxDate", selected)
        }
    });  
});
</script>
<style>
  @media print {
    .wrapper, .row2, #mainav, #fixednav, .page-header {
      display: none;
    }
}
</style>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
   <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
      <li class="active"><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a class="active" href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

<form action="cancelled_transactions.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Cancelled Transactions</h1>
        <hr>
      </div>   
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 63px;">
        <div style="float: right;">
          
        </div>
      <div>
      <?php
      
          $store_value=array();  

           $get_value ="SELECT DISTINCT location FROM location_destination";
            $result = $DBcon->query($get_value);
            if ($result->num_rows > 0) {
              while($row_result = $result->fetch_assoc()) {
                $store_value[]=$row_result["location"];
              }
            }
      ?>
      <select style="display: inline-block; width: 200px; height: 45px;" name="company" id="comp">
            <option value="All">All</option>
            <?php for($n=0;$n<sizeOf($store_value);$n++){ 
                echo "<option value='$store_value[$n]'>$store_value[$n]</option>";
          }

          $comp=$_POST['company'];
          $from=$_POST['txtFrom'];
          $to=$_POST['txtTo'];
          ?>
            </select>
            <input type="text" placeholder="From" name="txtFrom" id="txtFromDate" size="10" style="cursor: pointer;" required>
            <i class="fa fa-arrow-right" aria-hidden="true"></i>
          <input type="text" placeholder="To" name="txtTo" id="txtToDate" size="10" style="cursor: pointer;" required>
          <button name="submit" id="submit" style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 40px;">Search</button>
          <div style="float: right; margin: 10px 10px 0 0;">
            <button style="border-style: none; color: white; border-radius: 3px; background: #00aaff; font-size: 15px; height: 40px;" onclick="window.print()">Print</button></div>
        </div>
      </div><br> 
<?php

      if (isset($_POST['submit'])) {
          
          $selectreserve="SELECT r.userID,r.reserveID, rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.status FROM routes_schedules as rs INNER JOIN reservations as r ON rs.routeID=r.routeID WHERE rs.from_location='$comp' AND r.status='cancelled' AND r.reserve_date BETWEEN '$from' AND '$to' ORDER BY r.reserve_date DESC";

            $result = $DBcon->query($selectreserve);
            if ($result->num_rows > 0) {
            echo "<table><tr><th>Name</th><th>Bus Company</th><th>Type</th><th>From</th><th>Destination</th><th>Reserve Date</th><th>Schedule</th><th>Total</th><th>Payment Type</th><th>Status</th><th>Code</th></tr>";
            while($row = $result->fetch_assoc()) {
                $fare=$row["fare_total"];
                $fare=number_format($fare,2);
                //getting the name
                $userid=$row["userID"];
                $getname="SELECT * FROM users where userID='$userid'";
                $myresult2=$DBcon->query($getname);
                if($myresult2->num_rows > 0) {
                while($row3 = $myresult2->fetch_assoc()) {
                        $fname=$row3['firstname'];
                        $lname=$row3['lastname'];
                    }
                  }
                //getting the name
                echo "<tr><td>".$fname." ".$lname."</td><td>" . $row["company"]. "</td><td>" . $row["type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["reserve_date"]. "</td><td>" . $row["time_sched"]. "</td><td>" ."PHP ".$fare. "</td><td>" . $row["payment_type"]. "</td><td>" . $row["status"]. "</td><td>" . $row["code"]. "</td></tr>";
   
    }   
      echo "</table>";
    } 

    else if ($comp == 'All' && $from!="") {
       $query="SELECT r.userID,r.reserveID, rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.status FROM routes_schedules as rs INNER JOIN reservations as r ON rs.routeID=r.routeID WHERE r.status='cancelled' AND r.reserve_date BETWEEN '$from' AND '$to' ORDER BY r.reserve_date DESC";
           

      $result = mysqli_query($DBcon, $query);
      if (mysqli_num_rows($result) > 0) 
      {
        echo "<div class='table-responsive:'>
                <table class='table table bordered'>
                  <tr>
                    <th>Name</th>
                    <th>Bus Company</th>
                    <th>Type</th>
                    <th>From</th>
                    <th>Destination</th>
                    <th>Reserve Date</th>
                    <th>Schedule</th>
                    <th>Total</th>
                    <th>Payment Type</th>
                    <th>Status</th>
                    <th>Code</th>
                  </tr>";
        while ($row = mysqli_fetch_array($result)) {
            
            $fare=$row["fare_total"];
            $fare=number_format($fare,2);
            
          $userid=$row["userID"];
                      $getname="SELECT * FROM users where userID='$userid'";
                      $myresult2=$DBcon->query($getname);
                      if($myresult2->num_rows > 0) {
                      while($row3 = $myresult2->fetch_assoc()) {
                              $fname=$row3['firstname'];
                              $lname=$row3['lastname'];
                          }
                        }
            echo "<tr>
                <td>".$fname." ".$lname."</td>
                <td>".$row["company"]."</td>
                <td>".$row["type"]."</td>
                <td>".$row["from_location"]."</td>
                <td>".$row["destination"]."</td>
                <td>".$row["reserve_date"]."</td>
                <td>".$row["time_sched"]."</td>
                <td>" ."PHP ".$fare. "</td>
                <td>".$row["payment_type"]."</td>
                <td>".$row["status"]."</td>
                <td>".$row["code"]."</td>"?>

                      <?php

        }
          echo "</table>";
      }
          }
        }
    $DBcon->close();
    ?>
    </div>
  </div>
</form>
<script type="text/javascript">



</script>
</body>
</html>