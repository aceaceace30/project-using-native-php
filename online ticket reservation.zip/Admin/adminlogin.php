<?php
require('dbconnect.php');
require('select.php');
require('alogin.php');
if(isset($_SESSION["checkadmin"])){
    header("location:dashboard.php");
}
if(isset($_SESSION["checkemployee"])){
    header("location:../Employee_walkin/home_walkin.php");
}   
?>

<!DOCTYPE html>
<html lang="en">
<head>

<title>TRAVEL LOKAL</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <div class="wrapper row1">
        <header id="header" class="clear"> 
          <div id="logo">
            <h1><a href="../index.php"><img src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
          </div>
        </header>
    </div>

      <div style="border-style: solid; border-color: white; height: auto; background: white;">
   <div class="col-lg-12">
        <h1 class="page-header">Log-in</h1>
        <hr><br>
      </div>

 		<form class="modal-content" action="adminlogin.php" method="POST" style="margin-top: -15px;">
	        <div class="imgcontainer">  
	      <img src="../../GlobalImages/lock.png" class="avatar">
	    </div>
	    <div class="logcontainer">
	      <hr>
        <?php if($error_username_pass!=""){ echo "<span>$error_username_pass</span>";}?>
	      <input type="text" placeholder="Username" name="email" id="email" size="37" style="padding-left: 30px;" required autofocus>
	      <i class="fa fa-envelope errspan" aria-hidden="true"></i>
	      <input type="password" placeholder="Password" name="password" id="password" size="37" style="padding-left: 30px;" required>
	      <i class="fa fa-key errspan" aria-hidden="true"></i>
	      <input style="background-color:#00aaff; height: 43px; width:100%; border-style: none; color:white; border-radius: 5px; margin: 30px 0 10px 0" type="submit" name="admin_btn" id="admin_btn"></input>
	    </div>

      </div>
     </form>
  </body>

</html>