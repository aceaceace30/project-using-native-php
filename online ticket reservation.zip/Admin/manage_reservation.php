<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}  
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li> 
          </form>
        </ul>
     </li>
        <li><a class="drop" href="#">User Tables</a>    
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

 <form action="manage_reservation.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Manage Bookings</h1>
        <hr>
      </div>
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;"></div><br>
      <?php
 require('dbconnect.php');
 $query = "SELECT r.userID, r.reserveID, rs.routeID, rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.payment_status FROM reservations as r INNER JOIN routes_schedules as rs ON rs.routeID=r.routeID WHERE r.status='reserve' ORDER BY r.reserve_date DESC";

$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
  echo "<div class='table-responsive:'>
          <table class='table table bordered'>
            <tr>
              <th>Name</th>
              <th>Type</th>
              <th>From</th>
              <th>Destination</th>
              <th>Seats</th>
              <th>Date</th>
              <th>Time</th>
              <th>Fare</th>
              <th>Code</th>
              <th>Action</th>

            </tr>";
  while ($row = mysqli_fetch_array($result)) {
      
    $fare_total=$row["fare_total"];
    $fare_total=number_format($fare_total,2);
    $payment_status=$row["payment_status"];
    
    //getting the seats
    $r_id=$row["reserveID"];
    $getseats="SELECT * FROM reserve_seats where reserveID='$r_id'";
    $myresult=$DBcon->query($getseats);
    $seatarray=array();
    if($myresult->num_rows > 0) {
    while($row2 = $myresult->fetch_assoc()) {
            $seatarray[]=$row2['seat_no'];
        }
      }
   //getting the seats
	$getuserid=$row["userID"];
			if($getuserid=="GUEST")
      {
        $hold=$row["userID"];
      }
      else
      {
        $userid=$row["userID"];
        $getname="SELECT * FROM users where userID='$userid'";
        $myresult2=$DBcon->query($getname);
        if($myresult2->num_rows > 0) {
        while($row3 = $myresult2->fetch_assoc()) {
        $fname=$row3['firstname'];
        $lname=$row3['lastname'];
            }
       }
        $hold=$fname . ' ' . $lname;
      }
      echo "<tr>
          <td>".$hold."</td>
          <td>".$row["type"]."</td>
          <td>".$row["from_location"]."</td>
          <td>".$row["destination"]."</td>
          <td>".$string=implode("," , $seatarray)."</td>
          <td>".$row["reserve_date"]."</td>
          <td>".$row["time_sched"]."</td>
          <td>"."PHP ".$fare_total."</td>
          <td>".$row["code"]."</td>"?>

                  <?php echo "<td><a href='reschedule.php?id=".$row["routeID"]."&resid=".$row["reserveID"]."&btype=".$row["type"]."&rdate=".$row["reserve_date"]."'> Reschedule</a>";
                  
                  if($payment_status=="UNPAID")
                  {?>
                  
                  <button onclick="document.getElementById('mark').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 25px;">Mark as Paid</button>
                  
                  <?php }else if($payment_status="PAID")
                  {?>
                  
                  <button onclick="document.getElementById('mark').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 25px;">Mark as Unpaid</button> <?php } ?>
                  
                  <button onclick="document.getElementById('confirm').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 25px;">Confirm</button>
                  <button onclick="document.getElementById('cancel').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Cancel</button></td>

                <?php
  }
    echo "</table>";
}
else
{
  echo '<center style="color: red;">Data Not Found</center>';
}

?>

    </div>
  </div>
</form>


<div id="confirm" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('confirm').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to confirm this reservation?</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_confirm"></span><br>
    <input type="password" size="40" id="secpass_confirm" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="confirm_btn" class="btn btn-default">CONFIRM</button></center>
    </div>
  </form>
</div>

<div id="cancel" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('cancel').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to cancel this reservation?</h2></center>
    </div>
    <center style="color: red;"><span id="pass_err"></span><br>
    <input type="password" size="40" id="secpass" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="yes_btn" class="btn btn-default">SUBMIT</button></center>
    </div>
  </form>
</div>

<div id="mark" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('mark').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to change payment status of this reservation?</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_mark"></span><br>
    <input type="password" size="40" id="secpass_mark" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="mark_btn" class="btn btn-default">CONFIRM</button></center>
    </div>
  </form>
</div>


</body>
<script>
$(document).ready(function(){
      $('.view_cancel').click(function(e) {
        e.preventDefault();
        reserveID=($(this).attr("id"));
      });

      $('#confirm_btn').click(function(e){
      e.preventDefault();
      var securitypass_confirm=$('#secpass_confirm').val();
      if(securitypass_confirm=="")
      {
        $('#pass_err_confirm').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"confirm_reservation.php",
      data:{'reserveid':reserveID,
            'securitypass':securitypass_confirm},
      success:function(data){
        if(data=='yes')
        {
         // window.open('http://travel-lokal-ph.com/Employee_walkin/mypdf.php', '_blank');
          window.location.reload();
        }
        else if(data=='error')
        {
          $('#pass_err_confirm').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });
      $('#yes_btn').click(function(e){ 
      e.preventDefault();
      var securitypass=$('#secpass').val();
      if(securitypass=="")
      {
        $('#pass_err').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"cancel_reservation.php",
      data:{'reserveid':reserveID,
            'securitypass':securitypass},
      success:function(data){
        if(data=='yes')
        {
          alert("Reservation Cancelled");
          window.location.href = window.location;
        }
        else if(data=='error')
        {
          $('#pass_err').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });
  
  $('#mark_btn').click(function(e){ 
      e.preventDefault();
      var securitypass=$('#secpass_mark').val();
      if(securitypass=="")
      {
        $('#pass_err_mark').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"mark.php",
      data:{'reserveid':reserveID,
            'securitypass':securitypass},
      success:function(data){
        if(data=='yes')
        {
          window.location.href = window.location;
        }
        else if(data=='error')
        {
          $('#pass_err_mark').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });

});
</script>
</html>