<?php
require('dbconnect.php');

$route_comp=$_POST['route_company'];
$route_busname=$_POST['route_type'];
$route_location=$_POST['route_location'];
$route_destination=$_POST['route_destination'];
$route_fare = strip_tags($_POST['route_fare']);
$route_fare = $DBcon->real_escape_string($route_fare);
$route_sched=$_POST['route_sched'];
$route_sched=date('h:ia',strtotime($route_sched));
$date_set=date("m/d/Y",strtotime($_POST['date_set']));
//date_set
//'$date_set'

$insertroute ="INSERT INTO routes_schedules(company,type,from_location,destination,date_set,available_seats,time_sched,fare) VALUES('$route_comp','$route_busname','$route_location','$route_destination','$date_set','44','$route_sched','$route_fare')";
    if($DBcon->query($insertroute)) 
    {
        echo "yes";  
    }
    else 
    {
        echo "error";
    }

?>