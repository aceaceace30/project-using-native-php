<?php
session_start();
require('dbconnect.php');
require('select.php');
//require('sessioncheck.php');  

$route_id=$_GET["id"];
$reserve_id=$_GET["resid"];
$rdate=$_GET["rdate"];

$i=0;

$get_routeID = "SELECT * FROM routes_schedules WHERE routeID='$route_id'";

$result_routeID = $DBcon->query($get_routeID); 

if ($result_routeID->num_rows > 0) {

    while($row_result = $result_routeID->fetch_assoc()) {

    	$available_seats=$row_result["available_seats"];
   		//$bus_id=$row_result["BusID"];
   		$fare=$row_result["fare"];
      $buscomp=$row_result["company"];

?>


<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
  $( function() {
   $('#datepicker').datepicker({ minDate: 1, maxDate: 14 });
  } );
</script> 
</head>
<body onload="myFunction();">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Transaction</a></li>
          <li><a href="#">Audit Trail</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>
  <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Pick Seats</h1>
        <hr>
      </div>
  </div>
<div id="pickseats" style="margin: -30px 0 0 30%;">
<br>


  <div id="pickinstruc">
    <i class="fa fa-square gray" aria-hidden="true"></i><span>Available</span><br>
    <i class="fa fa-square blue" aria-hidden="true"></i><span>Selected</span><br>
    <i class="fa fa-square red" aria-hidden="true"></i><span>Reserved</span>
    <br><br>
    <span style="color:red" id="noseat"></span>
  </div>
    <div id="seats">
    <span style="margin: 0 30px 0 10px; color: gray">Driver</span><span style="color: gray;">Conductor</span><br><br>
      <?php

    $seat_count=0;

    $getseatcount="SELECT * FROM seats";
    $res = $DBcon->query($getseatcount);

      if ($res->num_rows > 0) {

        while($row = $res->fetch_assoc()) {
            $seat_count++;
        }
      }

    for($i=1;$i<=$seat_count;$i++)
    {
      $get_seatID="SELECT * FROM seats where seatID='$i'";
      $result_seatID = $DBcon->query($get_seatID);

      if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {

          $seat_no=$row["seat_no"];
        }
    }
      ?>

<form id="tosearch" action="reschedmod.php" method="GET">
<div style="display: inline-block;">
    <input type="checkbox" height="50" id="<?php echo $seat_no; ?>" name="seats[]" class="myseats" value="<?php echo $seat_no; ?>" onclick="ChangeCheckboxLabel(this)">
   <label id="<?php echo $seat_no; ?>" for="<?php echo $seat_no; ?>" title="Seat #<?php echo $seat_no; ?>"></label>
    <span id="<?php echo $seat_no; ?>-checked" style="display:none;"></span>
    <span id="<?php echo $seat_no; ?>-unchecked"></span>
</div>
     <?php
    }
    if ($result_seatID->num_rows > 0) {

        while($row = $result_seatID->fetch_assoc()) {
          $avail=$row['available_seats'];
            }
    }
    ?>
    </div>

        <input type="hidden" name="reserve_id" value="<?php echo $reserve_id;?>">
        <input type="hidden" name="id" value="<?php echo $route_id;?>">
        <input type="hidden" name="rdate" value="<?php echo $rdate; ?>">
        <center><button type="submit" name="sendseats" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px; margin: 30px 0 0 0px;">SUBMIT</button></center> 

</div>
</form>

<?php
    }
}

//$thedate=$_SESSION['datepick'];

$get_seatno = "SELECT reserve_seats.seat_no FROM reserve_seats INNER JOIN reservations ON reservations.reserveID=reserve_seats.reserveID WHERE reserve_date='$rdate' AND routeID='$route_id'";
$result=$DBcon->query($get_seatno);

$store = array();
$store2= array();
$c=0;
while($row = $result->fetch_row()) {
    $store = array($row[0]);
    $store2[$c]=$store[0];
    $c++;
}
?>

<script type="text/javascript">
function myFunction() {  
<?php
for($k=0;$k<sizeof($store2);$k++)
{
?>
	document.getElementById('<?php echo $store2[$k]; ?>').disabled = true;
   
<?php 
}
?>

}
 	var counter=0;
 	var busfare=<?php echo $fare;?>;
 	var total=0;
 	var baggage=0;

function ChangeCheckboxLabel(ckbx)
{

   $('input[type=checkbox]').on('change', function (e) {
         var max=<?php echo sizeOf($store2);?>;
        if ($('input[type=checkbox]:checked').length > max) {
            $(this).prop('checked', false);
            alert("Maximum of "+max+" seats");

          }
        });
   var d = ckbx.id;

   if( ckbx.checked )
   {
      document.getElementById(d+"-checked").style.display = "inline";
      document.getElementById(d+"-unchecked").style.display = "none";
      counter+=1;
      document.getElementById("numberofseats").innerHTML= counter;
   }
   else
   {
      document.getElementById(d+"-checked").style.display = "none";
      document.getElementById(d+"-unchecked").style.display = "inline";
      counter-=1;
      document.getElementById("numberofseats").innerHTML= counter;
   }
   	baggage=counter*2;
    total=counter*busfare;
   	document.getElementById("total").innerHTML= total;
    document.getElementById("mytotal").value= total;
}

var counter=0;
var busfare=<?php echo $fare;?>;
var total=0;

$(document).ready(function(){
    $checks = $(":checkbox");
    $checks.on('change', function() {
        var string = $checks.filter(":checked").map(function(i,v){
            return this.value;
        }).get().join(" ");
        $('.field_results').val(string);
    });
});

$(document).ready(function () {
    var $form = $('#tosearch');
    var $checkbox = $('.myseats');
    
    $form.on('submit', function(e) {
        if(!$checkbox.is(':checked')) {
            $('#noseat').text('No seat/s selected');
            e.preventDefault();
        }
    });
}); 
</script>

</body>
</html>