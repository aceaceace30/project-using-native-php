<?php
session_start();
include ( "./src/NexmoMessage.php" );
require('dbconnect.php');

 $email = strip_tags($_POST['email']);
 $password = strip_tags($_POST['password']);
 $confirmpassword = strip_tags($_POST['confirmpass']);
 $firstname = strip_tags($_POST['fname']);
 $lastname = strip_tags($_POST['lname']);
 $phonenumber= strip_tags($_POST['phonenumber']);
 $usertype=$_POST['usertype'];
 
 $email = $DBcon->real_escape_string($email);
 $password = $DBcon->real_escape_string($password);
 $confirmpassword = $DBcon->real_escape_string($confirmpassword);
 $firstname = $DBcon->real_escape_string($firstname);
 $lastname = $DBcon->real_escape_string($lastname);
 $phonenumber = $DBcon->real_escape_string($phonenumber);
 //$hashed_password = password_hash($upass, PASSWORD_DEFAULT); // this function works only in PHP 5.5 or latest version
 
 $check_email = $DBcon->query("SELECT email FROM users WHERE email='$email'");
 $count=$check_email->num_rows;
 
if($password==$confirmpassword)
{
 if($count==0)
 {  
  $query = "INSERT INTO users(email,password,phonenumber,firstname,lastname,usertype,activated) VALUES('$email','$password','$phonenumber','$firstname','$lastname','$usertype','yes')";

    if ($DBcon->query($query)) 
    {
        echo "yes";
    }
    else 
    {
        echo "errorreg";
    }
  }
 else 
 { 
  echo "emailtaken";
 }
}
else
{
 echo "notequalpass";
}
  
 $DBcon->close();
?>