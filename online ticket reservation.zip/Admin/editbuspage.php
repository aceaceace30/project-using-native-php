<?php
require('dbconnect.php');
require('select.php');
if(isset($_SESSION["email"])){
    header("location:dashboard.php");
    exit();
}  
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 

</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="index.html"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li class="active"><a href="editbuspage.php" id="bus_link">Manage Bus</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
       <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Transaction</a></li>
          <li><a href="#">Audit Trail</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>   
     
 <form action="editbuspage.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">

      <div class="col-lg-12">
        <h1 class="page-header">Manage Bus</h1>
        <hr>
      </div>
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
       <button onclick="document.getElementById('add').style.display = 'block'" type="button" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px; margin: 10px 0 0 20px;">ADD NEW BUS</button>
       <div style="float: right; margin: 3px 20px 0 0;">
    <i class="fa fa-search fa-2x" aria-hidden="true" style="position: absolute; margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" name="search_text" id="search_text"  style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="Search"> 
        </div>
      </div> <br><br>

      <div id="result">
        
      </div> 
      
    </div>
   </div>
  </div>
</form>

<div id="edit" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('edit').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Edit Bus</h1></center><hr>
    <label>Body Number:</label><input style="margin-left: 55px;" size="35" type="text" id="busname"><span id="error_busname"></span><br>
    <label>Bus Company:</label><select id="buscompany" style="width: 380px; display: inline-block;">
         <?php
            require('dbconnect.php');
            $compnames=array();

            $get_compnames="SELECT company_name FROM companies";

            $result_name=$DBcon->query($get_compnames);

            if ($result_name->num_rows > 0) {
              while($row = $result_name->fetch_assoc()) {
                  $compnames[]=$row["company_name"];
              }
            }
            for($m=0;$m<sizeof($compnames);$m++)
            {
              echo "<option value='$compnames[$m]'>$compnames[$m]</option>";
            }
            ?>  
            </select><br>
    <label>Bus Type:</label><select id="bustype" style="width: 380px; margin-left: 65px; display: inline-block;">
        <option value="Ordinary">Ordinary</option>
        <option value="Aircon">Aircon</option>
      </select><br><br><hr>
      <center><span style="color: red;" id="pass_err"></span><br> 
      <input type="password" size="40" id="secpass" placeholder="Enter password here"></center>
    </div>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button id="modal_savebtn" value="Yes" style="background-color: #ff9900; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SAVE</button></center>
    </div>
  </form>
</div>

<div id="delete" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('delete').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to delete this bus? It cannot be undone.</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_del"></span><br>
    <input type="password" size="40" id="secpass_del" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <center><button id="deletebus" value="SUBMIT" style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">DELETE</button></center> 
    </div>
  </form>
</div>

<div id="add" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('add').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Add New Bus</h1></center>
    <hr>
    <label>Bus Body No.:</label><span style="margin-left: 27px;" id="error_busname2"></span>
    <input type="text" size="35" id="busname_add"><br>
    <label>Bus Company:</label><select style="width: 340px; display: inline-block;" id="buscompany_add">
       <?php
            require('dbconnect.php');
            $compnames=array();

            $get_compnames="SELECT company_name FROM companies";

            $result_name=$DBcon->query($get_compnames);

            if ($result_name->num_rows > 0) {
              while($row = $result_name->fetch_assoc()) {
                  $compnames[]=$row["company_name"];
              }
            }
            for($m=0;$m<sizeof($compnames);$m++)
            {
              echo "<option value='$compnames[$m]'>$compnames[$m]</option>";
            }
            ?>  
            </select><br>
    <label>Bus Type:</label><select style="width: 340px; margin-left: 65px; display: inline-block;" id="bustype_add">
      <option value="Ordinary">Ordinary</option>
      <option value="Aircon">Aircon</option>
    </select><br><br>
    </div>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button id="modal_addbus" value="SUBMIT" style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SUBMIT</button></center> 
    </div>
  </form>
</div>

</body>

<script>

$(document).ready(function() {
  load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetchbus.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
  });
});

</script>
</html>