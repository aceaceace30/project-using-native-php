<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}  
?>
<!DOCTYPE html>
<html>
<head>	
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
  $(document).ready(function(){
    $('#txtFromDate').datepicker({ minDate: 0});

});
</script>
<style>
  @media print {
    .wrapper, .row2, #mainav, #fixednav, .page-header {
      display: none;
    }
}
</style>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
   <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
      <li class="active"><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a class="active" href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

<form action="daily_schedules.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Daily Bus Schedule</h1>
        <hr>
      </div>   
      <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 63px;">
        <div style="float: right;">
          
        </div>
      <div>
      <?php
          $store_value=array();

           $get_value ="SELECT DISTINCT location FROM location_destination";
            $result = $DBcon->query($get_value);
            if ($result->num_rows > 0) {
              while($row_result = $result->fetch_assoc()) {
                $store_value[]=$row_result["location"];
              }
            }
      ?>
      <select style="display: inline-block; width: 200px; height: 45px;" name="from_location" id="comp">
      <option value="All">All</option>
            <?php for($n=0;$n<sizeOf($store_value);$n++){ 
                echo "<option value='$store_value[$n]'>$store_value[$n]</option>";
          }

          $comp=$_POST['from_location'];
          $date_select=$_POST['date_select'];
          $buscount=0;
          ?>
            </select>
            <input type="text" placeholder="Select Date" name="date_select" id="txtFromDate" size="10" style="cursor: pointer;" required>
            <i class="fa fa-arrow-right" aria-hidden="true"></i>
          <button name="submit" id="submit" style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 40px;">Search</button>
          <div style="float: right; margin: 10px 10px 0 0;">
            <button style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 40px;" onclick="window.print()">Print</button></div>
        </div>
      </div><br> 
<?php
      if (isset($_POST['submit']) && !isset($_POST['All'])) {
          
          $selectreserve="SELECT * FROM routes_schedules WHERE from_location='$comp' AND date_set='$date_select'";

            $result = $DBcon->query($selectreserve);
            if ($result->num_rows > 0) {
            echo "<table><tr><th>Bus Company</th><th>Type</th><th>From</th><th>Destination</th><th>Date</th><th>Departure Time</th><th>Fare</th></tr>";
            while($row = $result->fetch_assoc()) {
                  $fare=$row["fare"];
                  $fare=number_format($fare,2);
                  $buscount++;
                echo "<tr><td>" . $row["company"]. "</td><td>" . $row["type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["date_set"]. "</td><td>" . $row["time_sched"]. "</td><td>" ."PHP ". $fare. "</td>" ?></tr>
    <?php
    }   
      echo "</table>";
    } 

    else if ($_POST['from_location'] == 'All') {
       $query="SELECT * from routes_schedules WHERE date_set='$date_select' ORDER BY company ASC";

      $result = mysqli_query($DBcon, $query);
      if (mysqli_num_rows($result) > 0) 
      {
        echo "<div class='table-responsive:'>
                <table class='table table bordered'>
                  <tr>
                    <th>Bus Company</th>
                    <th>Type</th>
                    <th>From</th>
                    <th>Destination</th>
                    <th>Date</th>
                    <th>Departure Time</th>
                    <th>Fare</th>
                  </tr>";
        while ($row = mysqli_fetch_array($result)) {

                  $fare=$row["fare"];
                  $fare=number_format($fare,2);
                  $buscount++;
          
            echo "<tr>
                <td>".$row["company"]."</td>
                <td>".$row["type"]."</td>
                <td>".$row["from_location"]."</td>
                <td>".$row["destination"]."</td>
                <td>".$row["date_set"]."</td>
                <td>".$row["time_sched"]."</td>
                <td>" ."PHP ". $fare. "</td>" ?>
                      <?php

        }
          echo "</table>";
      }
          }
        }
    $DBcon->close();

    ?>
    </div><br>
    <center>
      <label>Total Number of Bus: <strong><?php if(isset($buscount)){echo $buscount;} ?></strong></label><center>
      <center><br>
      <?php
       ?>
  </div>
</form>
<script type="text/javascript">

 function submit()
    {
        document.getElementById("submit").click(); // Simulates button click
        document.submitForm.submit(); // Submits the form without the button
    }

</script>
</body>
</html>