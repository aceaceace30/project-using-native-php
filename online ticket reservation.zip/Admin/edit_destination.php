<?php
session_start();
require('dbconnect.php');

$location=$_POST['location'];
$destination=$_POST['destination'];
$kms=$_POST['kms'];
$desID=$_POST['desID'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$updatelocdes = "UPDATE location_destination SET location='$location', destination='$destination', kilometers='$kms' WHERE id='$desID'";
    if ($DBcon->query($updatelocdes))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on updating location and destination";
    }

?>