<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}   
?>
     
<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li class="active"><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="#" onclick="showUsers()">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>


<form action="users.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
  <div class="se-pre-con1"></div>
      <div class="col-lg-12">
        <h1 class="page-header">Users</h1>
        <hr>
      </div>
    <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
       <button onclick="document.getElementById('add').style.display = 'block'" type="button" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px; margin: 10px 0 0 20px;">ADD NEW USER</button>
       <div style="float: right; margin: 3px 20px 0 0;">
    <i class="fa fa-search fa-2x" aria-hidden="true" style="position: absolute; margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" name="search_text" id="search_text"  style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="Search"> 
        </div>
      </div> <br><br>

    <div id="result">
      
    </div>

 </div>
</form>

<div id="add" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('add').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Add New User</h1></center>
    <hr>

     <center><span id="erroremail"></span></center>
      <label style="margin-left: 85px;">Email:</label>
      <input type="text" placeholder="Enter Email" id="email_reg" size="40" required><br>
      <center><span id="errorpassword"></span></center>
      <label style="margin-left: 60px;">Password:</label>
      <input type="password" placeholder="Enter Password" id="password_reg" size="40" required><br>
      <center><span id="errorconfirmpass"></span></center>
      <label>Confirm Password:</label>
      <input type="password" placeholder="Confirm Password" id="confirmpass" size="40" required><br>
      <center><span id="errorfname"></span></center>
      <label style="margin-left: 50px;">First Name:</label>
      <input type="text" placeholder="Enter First Name" id="fname" size="40" required><br>
      <center><span id="errorlname"></span></center>
      <label style="margin-left: 50px;">Last Name:</label>
      <input type="text" placeholder="Enter Last Name" id="lname" size="40" required><br>
      <center><span id="errorphonenumber"></span></center>
      <label style="margin-left: 20px;">Phone Number:</label>
      <input type="text" placeholder="Ex. 639123456789" id="phonenumber" size="40" maxlength="14" onkeypress='return event.charCode >= 48 && event.charCode <= 57' required><br>
      <label style="margin-left: 30px;">Usertype:</label>
      <select id="usertype3" style="width: 150px; height: 40px; display: inline-block;">
      <option value="admin" selected>admin</option>
      <option value="member">member</option>
      <option value="teller">teller</option>
    </select>
    </div>
      <p id="success"></p>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <button style="background-color:#00aaff; border-radius: 5px; margin-left: 27%; color:white; height: 50px; border-style: none; width: 280px;" type="button" id="reg_btn" title="Create Account">SUBMIT</button>
    </div>
  </form>
</div>


<div id="delete" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('delete').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to delete this user? It cannot be undone.</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_del"></span><br>
    <input type="password" size="40" id="secpass_del" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <center><button id="delete_user" style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">DELETE</button></center> 
    </div>
  </form>
</div>


<div id="edit" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('edit').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center><h1>Edit User</h1></center><hr>
    <label style="margin: 15px 0 10px 50px;">First Name:</label><label  style="margin: 15px 0 10px 10px; color: #595959;" id="firstname"></label><br>
    <label style="margin: 5px 0 10px 50px;">Last Name:</label><label style="margin: 5px 0 10px 10px; color: #595959;" id="lastname" ></label> <br>
    <label style="margin: 5px 0 10px 30px;">User Type:</label>
    <select id="myusertype" style="width: 200px; display: inline-block; height: 40px;">
      <option value="admin">admin</option>
      <option value="member">member</option>
    </select><br>
    <label style="margin: 5px 10px 10px 85px;">Email:</label><input type="text" size="40" id="email"><br>
    <label style="margin: 5px 10px 10px 20px;">Phone Number:</label><input type="text" size="40" id="phonenumber_edit"><br>
    <label style="margin: 5px 15px 10px 55px;">Password:</label><input type="password" size="40" id="password"><br>
     <br><hr>
      <center><p style="color: red;" id="pass_err"></p>
      <input type="password" size="40" id="secpass" placeholder="Enter password here"></center>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <center><button id="edit_btn" style="background-color: #ffb84d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SAVE</button></center> 
    </div>
  </form>
</div>

</body>
<script>

$(document).ready(function() {
  load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetchusers.php",
   method:"POST",
   data:{query:query},
   success:function(data)
   {
    $('#result').html(data);
   }
  });
 }
 $('#search_text').keyup(function(){
  var search = $(this).val();
  if(search != '')
  {
   load_data(search);
  }
  else
  {
   load_data();
  }
  });
});


$(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con1").fadeOut("slow");;
  });
</script>
</html>