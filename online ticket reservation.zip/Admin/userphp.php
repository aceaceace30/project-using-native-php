<?php
require('dbconnect.php');

$userID=$_POST['userID'];
$array_userdetails=array();

$selectbus="SELECT * from users where userid='$userID'";

          $result = $DBcon->query($selectbus);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            	echo $row["firstname"].",".$row["lastname"].",".$row["usertype"].",".$row["email"].",".$row["phonenumber"].",".$row["password"];                  	
            }
        }
        else
        {
        	echo "error getting user info";	
        }
?>