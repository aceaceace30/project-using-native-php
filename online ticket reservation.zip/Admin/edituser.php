<?php
session_start();
require('dbconnect.php');

$email=$_POST['email'];
$phone_number=$_POST['phonenumber'];
$password=$_POST['password'];
$userid1=$_POST['userid'];
$usertype=$_POST['usertype'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$updateuser = "UPDATE users SET email='$email', usertype='$usertype', phonenumber='$phone_number', password='$password' WHERE userid='$userid1'";
    if ($DBcon->query($updateuser))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on updating user";
    }

?>