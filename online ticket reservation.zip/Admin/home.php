<?php
session_start();
require('dbconnect.php');
require('select.php');
require('update.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}  

?>
     
<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL ADMIN</title>
<link rel="icon" href="../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
</head>
<body id="top">
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
    <a onclick="document.getElementById('editname').style.display='block'" href="#editname"><i title="Edit Name" class="fa fa-pencil edit" aria-hidden="true"></i></a>
    <div class="fl_right">
      <ul class="faico clear">
        <li><a class="faicon-facebook" href="https://www.facebook.com/Travel-Lokal-839843849505011/" target="blank"><i class="fa fa-facebook"></i></a></li>
      </ul>
    </div>
</header>
</div>
<div class="se-pre-con">
  <center><img src="../GlobalImages/profile1.png" style="width: 250px; height: 250px"><br>
  <h1>Travel Lokal</h1></center><br>
</div>
<div class="wrapper row2">  
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true" style="color:#33bbff"></i>
      <li class="active"><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
     
      <li style="margin-left: 320px;"><a class="drop" href="#"><span style="text-transform: capitalize;">Admin: </span> <?php echo $_SESSION['firstname']; ?>!</a>
        <ul style="background: #262626">
          <li><a href="logout.php" id="logout_link"><i class="fa fa-times" aria-hidden="true" style="color: #ff3333"></i> Logout</a></li>
        </ul>

    </ul>
  </nav>
</div>

<div id="editname" class="modal">
  <form class="modal-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editname').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer"><br>  
    <center><h2>Company Name</h2></center>
    <input type="text" value="<?php echo $comp_name; ?>" name="compname" size="37" required>
     <hr>
      <button class="editbutton" type="submit" name="editname">Save</button>
    </div>  
  </form>
</div>

<div id="editaddress" class="modal">
  <form class="modal-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editaddress').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer"><br>
    <center><h2>Address</h2></center>
    <textarea rows="4" cols="44" name="compaddress"><?php echo $comp_address; ?></textarea>
     <br><hr>
      <button class="editbutton" type="submit" name="editaddress">Save</button>
    </div>  
  </form>
</div>

<div id="editnumber" class="modal">
  <form class="modal-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editnumber').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer"><br>  
    <center><h2>Company Number</h2></center>
    <input type="text" value="<?php echo $comp_number; ?>" name="compnumber" size="37" required>
     <hr>
      <button class="editbutton" type="submit" name="editnumber">Save</button>
    </div>  
  </form>
</div>

<div id="editemail" class="modal">
  <form class="modal-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editemail').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer"><br>  
    <center><h2>Email Address</h2></center>
    <input type="text" value="<?php echo $comp_email; ?>" name="compemail" size="37" required>
     <hr>
      <button class="editbutton" type="submit" name="editemail">Save</button>
    </div>  
  </form>
</div>

<div id="howmap" class="instrucmodal">
  <form class="instrucmap-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('howmap').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="instrucontainer"><br>  
    <center><h2>Instructions</h2></center>
     <hr>
     <div class="instruction">
        <h5>Step 1</h5>
       Go to "Google Maps" <a style="color: #9900e6;" href="https://www.google.com.ph/maps" target="blank">click here</a>
     </div>
     <br>
   <i class="fa fa-long-arrow-down" aria-hidden="true"></i>
     <div class="instruction">
       <h5>Step 2</h5>
       Search the desired destination and click "Share"
       <img style="border-style: solid; width: 400px;" src="../GlobalImages/clickshare.png" style="padding: 10px;">
     </div>

    <i class="fa fa-long-arrow-down" aria-hidden="true"></i>
     <div class="instruction">
      <h5>Step 3</h5>
       Click the "Embed map" and copy the URL
       <img style="border-style: solid; width: 400px;"" src="../GlobalImages/clickembed.png" style="padding: 10px;">
     </div>

     <i class="fa fa-long-arrow-down" aria-hidden="true"></i>
      <div class="instruction">
      <h5>Step 4</h5>
       Paste to "Company Map URL" and click "Change"
       <img style="border-style: solid; width: 400px;"" src="../GlobalImages/pasteurl.png" style="padding: 10px;">
     </div><br>
     <button type="submit">Got it!</button>
    </div>  
  </form>
</div>

<div id="editmap" class="modal">
  <form class="modal-content animate" method="post" action="home.php">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editmap').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer"><br>  
    <center><h2>Company Map URL</h2></center>
    <textarea rows="4" cols="44" name="compmap" placeholder="Paste the URL here"></textarea>
     <br><hr>
     <a onclick="document.getElementById('howmap').style.display='block', document.getElementById('editmap').style.display='none'" href="#howmap" name="howmap" title="How to change Map Location" style="float: right; margin-top: 15px;"><i class="fa fa-2x fa-question-circle-o edit" aria-hidden="true"></i></a>
      <button class="editbutton" type="submit" name="editmap">Save</button>
    </div>  
  </form>
</div>

<div id="editslide" class="instrucmodal">
  <form class="instruc-content animate" method="post" action="home.php" enctype="multipart/form-data">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('editslide').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="instrucontainer"><br>  
    <center><h2>Slide Show Images</h2></center>
     <hr>
     <div class="instruction">
        <h5>First Slide</h5>
        <img class="imgstyle" src="data:image/jpeg;base64,<?php echo base64_encode($first_slide);?>">
        <hr>
        <input type="file" name="firstslide" required>
     </div>   
      <div class="instruction">
        <h5>Second Slide</h5>
        <img class="imgstyle" src="data:image/jpeg;base64,<?php echo base64_encode($second_slide);?>">
        <hr>
        <input type="file" name="secondslide" required>
     </div>
     <div class="instruction">
        <h5>Third Slide</h5>
        <img class="imgstyle" src="data:image/jpeg;base64,<?php echo base64_encode($third_slide);?>">
        <hr>
        <input type="file" name="thirdslide" required>
     </div>   
     <hr><br>
     <button type="submit" name="slideshow">Save</button>
    </div>  
  </form>
</div>

<div id="sitemap" class="mapmodal">
  <form class="mapmodal-content animate" method="post" action="home.php">
   <div class="imgcontainer">  
      <span onclick="document.getElementById('sitemap').style.display='none'" class="close" title="Close">&times;</span>
      <br>
      <h1>Travel Lokal Map</h1>
      <hr>
    </div>
    <div class="logcontainer">
    <div>
      <?php echo $comp_map; ?>
    </div>
  
    </div>
  </form>
</div>
 

<form action="home.php" method="POST">
<div class="wrapper row3">
  <section class="container nospace clear"> 
    <div class="intro">
      <div class="container">
      <a onclick="document.getElementById('editslide').style.display='block'" name="editslide" href="#editslide"><i title="Edit Slideshow" class="fa fa-pencil edit" style="position: absolute; margin: -60px 0 0 120px;" aria-hidden="true"></i></a>
      <div id="leftpanel">
        <div class="slide">
          <img class="mySlides fade" style="height: 500px; width: 750px;" src="data:image/jpeg;base64,<?php echo base64_encode($first_slide);?>"/>
          <img class="mySlides fade" style="height: 500px; width: 750px;" src="data:image/jpeg;base64,<?php echo base64_encode($second_slide);?>"/>
          <img class="mySlides fade" style="height: 500px; width: 750px;" src="data:image/jpeg;base64,<?php echo base64_encode($third_slide);?>"/>
        </div>
      </div>
      <div id="rightpanel">
           <label style="font-size: 40px">Search Bus Trips</label><br>
           <i class="fa fa-compass fa-2x searchinput" aria-hidden="true"></i> 
           <input type="text" placeholder="From" name="from" size="40" style="padding-left: 45px;" disabled><br>
           <i class="fa fa-map-marker fa-2x searchinput" aria-hidden="true"></i>
           &nbsp&nbsp<input type="text" placeholder="To" name="destination" size="40" style="padding-left: 45px;" disabled><br>
           <i class="fa fa-calendar fa-2x searchinput" aria-hidden="true"></i>
           <input type="text" placeholder="Choose Date" id="datepicker" disabled size="40" style="padding-left: 45px;"  ><br><br>
           <div class="searchicon"><i class="fa fa-search fa-2x searchicon" aria-hidden="true" style="position: absolute; margin-top: -3px;"></i></div>
           <button style="background-color:#1a8cff; font-size: 20px; border-radius: 5px; border-style: none; margin-left: 5%; color:white; height: 45px; width: 400px;" type="submit" disabled name="search_btn">Search</button>
       </div>
      </div>
    </div>
  </section>
</div>
</form>

<div class="wrapper row4">
  <footer id="footer" class="clear"> 

    <div class="one_quarter">
      <h6 class="title">Company Information</h6>
      <?php echo $comp_name; ?><br>
      <a onclick="document.getElementById('editaddress').style.display='block'" name="editaddress" href="#editaddress"><i title="Edit Address" class="fa fa-pencil edit" style="position: absolute; margin-left: 270px;" aria-hidden="true"></i></a>
      <?php echo $comp_address; ?>
    </div>
    <div class="one_quarter">
    <a onclick="document.getElementById('editnumber').style.display='block'" name="editnumber" href="#editnumber"><i title="Edit Number" class="fa fa-pencil edit" style="position: absolute; margin: 0 0 0 170px;" aria-hidden="true"></i></a>
   <li class="btmspace-10"><i class="fa fa-phone"></i> <?php echo $comp_number; ?></li>


    <a onclick="document.getElementById('editemail').style.display='block'" name="editemail" href="#editemail"><i title="Edit Email" class="fa fa-pencil edit" style="position: absolute; margin: 0 0 0 175px;" aria-hidden="true"></i></a>
        <li><i class="fa fa-envelope-o"></i> <?php echo $comp_email; ?></li>
    </div>
    <div class="one_quarter">
    <a onclick="document.getElementById('editmap').style.display='block'" name="editmap" href="#editmap"><i title="Edit Map" class="fa fa-pencil edit" style="position: absolute; margin: 0 0 0 80px;" aria-hidden="true"></i></a>
    <li><i style="margin-right: 5px; color: orange;" class="fa fa-map-marker"></i><a onclick="document.getElementById('sitemap').style.display='block'" href="#sitemap" id="site-map">Site Map</a></li>
    </div>
  </footer>
</div>
</div>

<script src="../GlobalJS/carousel.js"></script>
<script>
  $(window).load(function() {
    // Animate loader off screen
    $(".se-pre-con").fadeOut("slow");;
  });

</script>
</body>
</html>