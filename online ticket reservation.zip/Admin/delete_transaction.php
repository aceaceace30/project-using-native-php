<?php
session_start();
require('dbconnect.php');

$reserveID=$_POST['reserveid'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }
$delete_transaction = "DELETE FROM reservations WHERE reserveID='$reserveID'";
    if ($DBcon->query($delete_transaction))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on deleting transaction";
    }
?>