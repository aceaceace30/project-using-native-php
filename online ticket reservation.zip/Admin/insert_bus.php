<?php
require('dbconnect.php');

$busname = strip_tags($_POST['bus_name']);
$busname = $DBcon->real_escape_string($busname);
$buscompany = strip_tags($_POST['buscompany']);
$buscompany = $DBcon->real_escape_string($buscompany);
$bustype = strip_tags($_POST['bustype']);
$bustype = $DBcon->real_escape_string($bustype);

$check_busname = $DBcon->query("SELECT BusName FROM bus WHERE BusName='$busname'");
$count=$check_busname->num_rows;
if($count==0)
{
$insertbus = "INSERT INTO bus(BusName,Bus_Company,Type,No_of_seats,Availability) VALUES('$busname','$buscompany','$bustype','40','unused')";
    if ($DBcon->query($insertbus)) 
    {
        echo "yes";
    }
    else 
    {
        echo "Error on adding bus name!";
    }
}

else
{
    echo "no";
}

?>