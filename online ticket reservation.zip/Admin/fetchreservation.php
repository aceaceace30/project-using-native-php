<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>
<body>
<div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto; margin-top: 10px;">
<?php
require('dbconnect.php');

if (isset($_POST["submit"])) {
$strKey=$_POST['txtSearch'];

 $query = "SELECT r.userID, r.reserveID, rs.routeID, rs.company, rs.type, rs.from_location, rs.destination, rs.time_sched, r.reserve_date, r.fare_total, r.payment_type, r.code, r.payment_status FROM reservations as r INNER JOIN routes_schedules as rs ON rs.routeID=r.routeID WHERE r.code LIKE '%".$strKey."%'";

$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
  echo "<div class='table-responsive:'>
          <table class='table table bordered'>
            <tr>
              <th>Name</th>
              <th>Bus Company</th>
              <th>Type</th>
              <th>From</th>
              <th>Destination</th>
              <th>Seats</th>
              <th>Date</th>
              <th>Time</th>
              <th>Fare</th>
              <th>Code</th>  
              <th>Action</th>
              <th>Action</th>
              <th>Action</th>
            </tr>";
  while ($row = mysqli_fetch_array($result)) {
      
      $fare_total=$row["fare_total"];
      $fare_total=number_format($fare_total,2);
    //getting the seats
    $r_id=$row["reserveID"];
    $getseats="SELECT * FROM reserve_seats where reserveID='$r_id'";
    $myresult=$DBcon->query($getseats);
    $seatarray=array();
    if($myresult->num_rows > 0) {
    while($row2 = $myresult->fetch_assoc()) {
            $seatarray[]=$row2['seat_no'];
        }
      }
    //getting the seats
    //getting the seats
  $getuserid=$row["userID"];
      if($getuserid=="GUEST")
      {
        $hold=$row["userID"];
      }
      else
      {
        $userid=$row["userID"];
        $getname="SELECT * FROM users where userID='$userid'";
        $myresult2=$DBcon->query($getname);
        if($myresult2->num_rows > 0) {
        while($row3 = $myresult2->fetch_assoc()) {
        $fname=$row3['firstname'];
        $lname=$row3['lastname'];
            }
       }
        $hold=$fname . ' ' . $lname;
      }
      echo "<tr>
          <td>".$hold."</td>
          <td>".$row["company"]."</td>
          <td>".$row["type"]."</td>
          <td>".$row["from_location"]."</td>
          <td>".$row["destination"]."</td>
          <td>".$string=implode("," , $seatarray)."</td>
          <td>".$row["reserve_date"]."</td>
          <td>".$row["time_sched"]."</td>
          <td>"."PHP ".$fare_total."</td>
          <td>".$row["code"]."</td>"?>

                  
                 <?php echo "<td><a href='reschedule.php?id=".$row["routeID"]."&resid=".$row["reserveID"]."&btype=".$row["type"]."&rdate=".$row["reserve_date"]."'><i class='fa fa-bus' aria-hidden='true'></i> Reschedule</a></td>";?>

                  <td><button onclick="document.getElementById('confirm').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #00e600; font-size: 15px; height: 25px;">Confirm</button></td>
                  <td><button onclick="document.getElementById('cancel').style.display = 'block'" type="button" class="view_cancel" id='<?php echo $row["reserveID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Cancel</button></td>

                <?php

  }
    echo "</table>";
}
else
{
  echo '<center style="color: red;">Data Not Found</center>';
}
}

?>
</div>
</div>

<div id="confirm" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('confirm').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to confirm this reservation?</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_confirm"></span><br>
    <input type="password" size="40" id="secpass_confirm" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="confirm_btn" class="btn btn-default">CONFIRM</button></center>
    </div>
  </form>
</div>

<div id="cancel" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('cancel').style.display='none'" class="close" title="Close">&times;</span>
    </div><br><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to cancel this reservation?</h2></center>
    </div>
    <center style="color: red;"><span id="pass_err"></span><br>
    <input type="password" size="40" id="secpass" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;" type="button" id="yes_btn" class="btn btn-default">SUBMIT</button></center>
    </div>
  </form>
</div>
</body>
</html>
<script>
$(document).ready(function(){
      $('.view_cancel').click(function(e) {
        e.preventDefault();
        reserveID=($(this).attr("id"));
      });

      $('#confirm_btn').click(function(e){
      e.preventDefault();
      var securitypass_confirm=$('#secpass_confirm').val();
      if(securitypass_confirm=="")
      {
        $('#pass_err_confirm').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"confirm_reservation.php",
      data:{'reserveid':reserveID,
            'securitypass':securitypass_confirm},
      success:function(data){
        if(data=='yes')
        {
          window.open('http://travel-lokal-ph.com/Employee_walkin/mypdf.php', '_blank');
          window.location.reload();
        }
        else if(data=='error')
        {
          $('#pass_err_confirm').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });
      $('#yes_btn').click(function(e){ 
      e.preventDefault();
      var securitypass=$('#secpass').val();
      if(securitypass=="")
      {
        $('#pass_err').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"cancel_reservation.php",
      data:{'reserveid':reserveID,
            'securitypass':securitypass},
      success:function(data){
        if(data=='yes')
        {
          alert("Reservation Cancelled");
          window.location.href = window.location;
        }
        else if(data=='error')
        {
          $('#pass_err').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });

});
</script>