<?php
session_start();
require('dbconnect.php');

$routeID=$_POST['routeID'];
$busid=0;
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$result = $DBcon->query($checkpassword);

if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$deleteroute = "DELETE FROM routes_schedules WHERE routeID='$routeID'";
    if ($DBcon->query($deleteroute))
    {
        echo "yes";
    }
    else 
    {
        echo "Error on deleting route";
    }
?>