<?php
require('dbconnect.php');

$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($DBcon, $_POST["query"]);
 $query = "
  SELECT * FROM users 
  WHERE email LIKE '%".$search."%'
  OR firstname LIKE '%".$search."%'  
  OR lastname LIKE '%".$search."%'
  OR phonenumber LIKE '%".$search."%'  
  OR usertype LIKE '%".$search."%'
 ";
}
else
{
 $query = "SELECT * FROM users";
}
$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
	echo "<div class='table-responsive:'>
			<table class='table table bordered'>
				<tr>
					<th>Email</th>
					<th>Phone Number</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>User Type</th>
					<th>Action</th>
					<th>Action</th>
				</tr>";
	while ($row = mysqli_fetch_array($result)) {
			echo "<tr>
					<td>".$row["email"]."</td>
					<td>".$row["phonenumber"]."</td>
					<td>".$row["firstname"]."</td>
					<td>".$row["lastname"]."</td>
					<td>".$row["usertype"]."</td>"?>

                  <td><button onclick="document.getElementById('edit').style.display = 'block'" class="view_user" type="button" id='<?php echo $row["userid"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ffb84d; font-size: 15px; height: 25px;">Edit</button></td>
                  <td><button onclick="document.getElementById('delete').style.display = 'block'" type="button" class="view_user" id='<?php echo $row["userid"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Delete</button></td>
                  
              	<?php

	}
		echo "</table>";
}
else
{
	echo '<center style="color: red;">Data Not Found</center>';
}

?>

<script>
$(document).ready(function(){
	 $('.view_user').click(function(e) {
        e.preventDefault();

        userID=($(this).attr("id"));

        $.ajax({
        type:"POST",
        url:"userphp.php",
        data:{'userID':userID},
        success:function(value){
          var data=value.split(",");
          $('#firstname').html(data[0]);
          $('#lastname').html(data[1]);
          $('#myusertype').val(data[2]);
          $('#email').val(data[3]);
          $('#phonenumber_edit').val(data[4]);
          $('#password').val(data[5]);
        }        
    });
  });

    $('#delete_user').click(function(e){ 
      e.preventDefault();
      var securitypass=$('#secpass_del').val();
      if(securitypass=="")
      {
        $('#pass_err_del').html("Password cannot be empty");
        return;
      }
      $.ajax({
      type:"POST",
      url:"delete_user.php",
      data:{'userid':userID,
            'securitypass':securitypass},
      success:function(data){
        if(data=='yes')
        {
          location.reload();
        }
        else if(data=='error')
        {
          $('#pass_err_del').html("Incorrect Password");
        }
        else
        {
          alert(data);
        }
      }
    });
  });

    $("#edit_btn").click(function(e){
        e.preventDefault();
        var securitypass=$('#secpass').val();
        var email=$('#email').val();
        var phonenumber=$('#phonenumber_edit').val();
        var password=$('#password').val();
        var usertype=$('#myusertype').val();
  
        if(securitypass=="")
        {
          $('#pass_err').html("Password cannot be empty");
          return false;
        }
  
          $.ajax({
            type:"POST",
            url:"edituser.php",
            data:{'securitypass':securitypass,
                  'userid':userID,
                  'email':email,
                  'phonenumber':phonenumber,
                  'usertype':usertype,  
                  'password':password},
            success:function(data){
              if(data=='yes')
              {
                location.reload();
              }
              else if(data=='error')
              {
                $('#pass_err').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
            }
          });
        });

    $("#email_reg").click(function(e){
      $('#erroremail').text(""); 
    });

    $("#password_reg").click(function(e){
      $('#errorpassword').text(""); 
    });

    $("#confirmpass").click(function(e){
      $('#errorconfirmpass').text(""); 
    });

    $("#fname").click(function(e){
      $('#errorfname').text(""); 
    });

    $("#lname").click(function(e){
      $('#errorlname').text(""); 
    });

    $("#phonenumber").click(function(e){
      $('#errorphonenumber').text(""); 
    });

    $("#reg_btn").click(function(e){
    e.preventDefault();

    var email=$('#email_reg').val();
    var password=$('#password_reg').val();
    var confirmpass=$('#confirmpass').val();
    var fname=$('#fname').val();
    var lname=$('#lname').val();
    var phonenumber=$('#phonenumber').val();
    var usertype=$('#usertype3').val();

    if(email=="")
    {
      $('#erroremail').text("Email can not be empty");      
    }
    if(password=="")
    {
      $('#errorpassword').text("Password can not be empty");    
    }
    if(confirmpass=="")
    {
      $('#errorconfirmpass').text("Confirm password can not be empty");   
    }
    if(fname=="")
    {
      $('#errorfname').text("Firstname can not be empty"); 
    }
    if(lname=="")
    {
      $('#errorlname').text("Lastname can not be empty");     
    }
    if(phonenumber=="")
    {
      $('#errorphonenumber').text("Phone number can not be empty");
      return;
    }

    $.ajax({
      type:"POST",
      url:"admin_register.php",
      data:{'email':email,  
            'password':password,
            'confirmpass':confirmpass,
            'fname':fname,
            'lname':lname,
            'phonenumber':phonenumber,
            'usertype':usertype},     
      success:function(data){
        if(data=="emailtaken")
        {
          $('#erroremail').text("Email already taken");
        }
        else if(data=="notequalpass")
        {
          $('#errorpassword').text("Password should be the same");
          $('#errorconfirmpass').text("Password should be the same");

        }
        else
        {
          alert("Register Successful");
          location.reload();
        }
      }
    });
  });
  });

</script>