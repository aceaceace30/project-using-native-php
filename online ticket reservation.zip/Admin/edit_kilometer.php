<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}  


/*$get_deskm="SELECT * FROM location_destination";
$myres=$DBcon->query($get_deskm);
$deskm_array=array();
if($myres->num_rows>0){
  while($row2=$myres->fetch_assoc()){
    $deskm_array[]=$row2['destination'];
  }
}

$query = "SELECT rs.routeID, b.BusName, b.Bus_Company, b.Type, rs.from_location, rs.destination, rs.time_sched, rs.fare FROM routes_schedules as rs INNER JOIN bus as b ON rs.BusId=b.BusID";
$storebustype_array=array();
$storedestination_array=array();
$theresult=$DBcon->query($query);
if($theresult->num_rows>0){
  while($row4=$theresult->fetch_assoc())
  {
    $storebustype_array[]=$row4['Type'];
    $storedestination_array[]=$row4['destination'];
  }
}
for($g=0;$g<sizeOf($storebustype_array);$g++)
{
  if($storebustype_array[$g]=="Ordinary")
  {//check all bus if it is ordinary in routes_schedules
    for($l=0;$l<sizeOf($deskm_array);$l++)
    {//get all the number of destination in location_destination
      for($j=0;$j<sizeOf($storedestination_array);$j++)
      {//get the all the kilometers of the of the routes and schedule depending on its destination
        $get_des2="SELECT * FROM location_destination WHERE destination='$storedestination_array[$j]'";
        $myres2=$DBcon->query($get_des2);
        $deskm_array2=array();
        if($myres2->num_rows>0){
          while($row6=$myres2->fetch_assoc()){
            $deskm_array2[]=$row6['kilometers'];
          }
        }
        echo $rate_array[0]*$deskm_array2[0]." ";
      }

    }
  }
  else if($storebustype_array[$g]=="Aircon")
  {
    echo "no";
  }
}
//echo $rate_array[0]*$deskm_array[0];

*/
if(isset($_POST['submit_message_bobis']))
{ 
  $ordinary_rate_bobis=$_POST['ordinary_rate_bobis'];
  $aircon_rate_bobis=$_POST['aircon_rate_bobis'];
  $my_rate_array=array($ordinary_rate_bobis,$aircon_rate_bobis);
  for($i=0;$i<2;$i++)
  {
    $p=$i+3;
    $update_rate="UPDATE bustype_rate SET per_kilometer='$my_rate_array[$i]' WHERE company_id='2' AND id='$p'";
    $DBcon->query($update_rate);
  }
}
if(isset($_POST['submit_message_mega']))
{ 
  $ordinary_rate_mega=$_POST['ordinary_rate_mega'];
  $aircon_rate_mega=$_POST['aircon_rate_mega'];
  $my_rate_array=array($ordinary_rate_mega,$aircon_rate_mega);
  for($i=0;$i<2;$i++)
  {
    $p=$i+1;
    $update_rate="UPDATE bustype_rate SET per_kilometer='$my_rate_array[$i]' WHERE company_id='1' AND id='$p'";
    $DBcon->query($update_rate);
  }
}

if(isset($_POST['submit_message_anton']))
{ 
  $ordinary_rate_anton=$_POST['ordinary_rate_anton'];
  $aircon_rate_anton=$_POST['aircon_rate_anton'];
  $my_rate_array=array($ordinary_rate_anton,$aircon_rate_anton);
  for($i=0;$i<2;$i++)
  {
    $p=$i+5;
    $update_rate="UPDATE bustype_rate SET per_kilometer='$my_rate_array[$i]' WHERE company_id='3' AND id='$p'";
    $DBcon->query($update_rate);
    $p++;
  }
}
if(isset($_POST['submit_message_ela']))
{ 
  $ordinary_rate_ela=$_POST['ordinary_rate_ela'];
  $aircon_rate_ela=$_POST['aircon_rate_ela'];
  $my_rate_array=array($ordinary_rate_ela,$aircon_rate_ela);
  for($i=0;$i<2;$i++)
  {
    $p=$i+7;
    $update_rate="UPDATE bustype_rate SET per_kilometer='$my_rate_array[$i]' WHERE company_id='4' AND id='$p'";
    $DBcon->query($update_rate);
    $p++;
  }
}

if(isset($_POST['submit_message2']))
{
  $fkm=$_POST['first_kilometers'];
  $price=$_POST['price'];

  $update_km="UPDATE ltfrb_rules SET first_kilometers='$fkm'WHERE id='1'";
  $DBcon->query($update_km);
  $update_price="UPDATE ltfrb_rules SET price='$price' WHERE id='1'";
  $DBcon->query($update_price);
}

$get_rate="SELECT * FROM bustype_rate";
$result = $DBcon->query($get_rate);
$rate_array=array();
if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
            $rate_array[]=$row['per_kilometer'];
        }
      }

$select_fk="SELECT * FROM ltfrb_rules WHERE id='1'";
$result3=$DBcon->query($select_fk);

if($result3->num_rows > 0) {
    while($row = $result3 -> fetch_assoc()) {
        $fk=$row['first_kilometers'];
            }
          }

$select_pr="SELECT * FROM ltfrb_rules WHERE id='1'";
$result4=$DBcon->query($select_pr);

if($result4->num_rows > 0) {
      while($row = $result4 -> fetch_assoc()) {
          $price=$row['price'];
            }
          }
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<style>

</style> 
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li class="active"><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>


 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Manage Per Kilometer Rate</h1>
        <hr><br>
      </div>  
        <div id="pickseats" style="height: 380px;">
            <center><h4>Bus Type Rates</h4></center>
            <hr>

            <!-- MEGA BUS -->
            <div id="megabus">
            <center><h5>Mega Bus</h5>
            <form action="edit_kilometer.php" method="POST">
            <label style="display: inline-block;">Ordinary:</label> 
            <input type="text" size="2" name="ordinary_rate_mega" value="<?php echo $rate_array[0]; ?>"><br>
            <p>Ordinary Rate: <?php echo $rate_array[0];?> php per kilometer/s</p>
            <label style="display: inline-block;">Aircon:</label> 
            <input type="text" size="2" name="aircon_rate_mega" value="<?php echo $rate_array[1]; ?>"><br>
            <p>Aircon Rate: <?php echo $rate_array[1]; ?> php per kilometer/s</p><br>
            <center><button type="submit" name="submit_message_mega" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 200px;">SAVE</button></center>
            </form></center>
          </div>
          </div>
          
            <div id="rightseats" style="height: 350px;">
            <center><h4>LTFRB RATE</h4></center>
            <hr>
            <center>
            <form action="edit_kilometer.php" method="POST">
            Kilometers:
            <input type="text" size="2" name="first_kilometers" value="<?php echo $fk; ?>"><br>
            <p>first <?php echo $fk; ?> kilometers</p>
            Price:
            <input type="text" size="2" name="price" value="<?php echo $price; ?>"><br>
            <p><?php echo $price; ?> php per kilometer/s</p><br>
            <center><button type="submit" name="submit_message2" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 200px;">SAVE</button></center>
            </form></center>
          </div>

<script>
function myFunction() {
    var x = document.getElementById('megabus');
    var y = document.getElementById('bobisliner');
    if (x.style.display === 'none') {
        x.style.display = 'block';
    } else if {
        x.style.display = 'none';
    }
    else if (y.style.display === 'none') {
        y.style.display = 'block';
    } else {
        y.style.display = 'none';
    }
}
</script>
</body>
</html>