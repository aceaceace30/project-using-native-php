<?php 
require('dbconnect.php');


if (isset($_GET['sendseats'])) 
{
   	$holder=array();
	$holder=$_GET['seats'];
	$reserveID=$_GET['reserve_id'];
	$routeID=$_GET['id'];
	$rdate=$_GET['rdate'];

	$query2="DELETE FROM reserve_seats WHERE reserveID='$reserveID'";
	$DBcon->query($query2);
	$query="UPDATE reservations SET routeID='$routeID', reserve_date='$rdate' WHERE reserveID='$reserveID'";
	$DBcon->query($query);
	for($b=0;$b<sizeof($holder);$b++)
    {
        $query3="INSERT INTO reserve_seats(reserveID,seat_no) values('$reserveID','$holder[$b]')";
        $DBcon->query($query3);

        header('location:manage_reservation.php');
    }
}

?>