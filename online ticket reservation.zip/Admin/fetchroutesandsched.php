<?php
require('dbconnect.php');

$output = '';
if(isset($_POST["query"]))
{
 $search = mysqli_real_escape_string($DBcon, $_POST["query"]);
 $query = "SELECT * FROM routes_schedules LIKE '%".$search."%'
  OR company LIKE '%".$search."%'
  OR type LIKE '%".$search."%'
  OR from_location LIKE '%".$search."%'
  OR destination LIKE '%".$search."%'
  OR time_sched LIKE '%".$search."%'
  OR fare LIKE '%".$search."%'
 ";
}
else
{
 $query = "SELECT * FROM routes_schedules";
}
$result = mysqli_query($DBcon, $query);
if (mysqli_num_rows($result) > 0) 
{
	echo "<div class='table-responsive:'>
					<table class='table table bordered'>
						<tr>
							<th>Bus Company</th>
							<th>Type</th>
							<th>From</th>
              <th>Destination</th>
              <th>Schedule</th>
							<th>Fare</th>
              <th>Schedule Date</th>
							<th>Action</th>
              <th>Action</th>
						</tr>";
	while ($row = mysqli_fetch_array($result)) {
			echo "<tr>
					<td>".$row["company"]."</td>
					<td>".$row["type"]."</td>
          <td>".$row["from_location"]."</td>
          <td>".$row["destination"]."</td>
          <td>".$row["time_sched"]."</td>
					<td>".$row["fare"]."</td>
          <td>".$row["date_set"]."</td>
"?>

                  <td><button onclick="document.getElementById('edit').style.display = 'block'" type="button" class="btn_view_route" id='<?php echo $row["routeID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ffb84d; font-size: 15px; height: 25px;">Edit</button></td>
                  <td><button onclick="document.getElementById('delete').style.display = 'block'" type="button" class="btn_view_route" id='<?php echo $row["routeID"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Delete</button></td>

              	<?php

	}
		echo "</table>";
}
else
{
	echo '<center style="color: red;">Data Not Found</center>';
}

?>
<script >
$(document).ready(function(){
      $('.btn_view_route').click(function(e) {
        e.preventDefault();
        
        routeID=($(this).attr("id"));
        $.ajax({
        type:"POST",
        url:"routephp.php",
        data:{'routeID':routeID},
        success:function(value){
          var data=value.split(",");
          $('#buscompany').html(data[0]);
          $('#mytype2').val(data[1]);
          $('#location').val(data[2]);
          $('#destination2').val(data[3]);
          $('#sched').val(data[4]);
          $('#showfare2').val(data[5]);
          $('#showfare2').html(data[5]);
        }        
    });
  });      
        $("#modal_routesave").click(function(e){
        var securitypass=$('#secpass').val();
        if(securitypass=="")
        {
          $('#pass_err').html("Password cannot be empty");
          return;
        }
        e.preventDefault();
        var location=$('#location').val();
        var type=$('#mytype2').val();
        var destination=$('#destination2').val();
        var schedule=$('#sched').val();
        var fare=$('#showfare2').val();

          $.ajax({
            type:"POST",
            url:"editroute.php",
            data:{'securitypass':securitypass,
                  'routeID':routeID,
                  'type':type,
                  'location':location,
                  'destination':destination,  
                  'sched':schedule,
                  'fare':fare},
            success:function(data){
              if(data=='yes')
              {
                alert("Edit successful");
                window.location.href = window.location;
              }
              else if(data=='error')
              {
                $('#pass_err').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
            }
          });
        });

        $('#deleteroute').click(function(e) {
        var securitypass=$('#secpass_del').val();
        if(securitypass=="")
        {
          $('#pass_err_del').html("Password cannot be empty");
          return;
        }
        e.preventDefault();
        $.ajax({
        type:"POST",  
        url:"deleteroute.php",
        data:{'securitypass':securitypass,
              'routeID':routeID},
        success:function(data){
          if(data=='yes')
          {
            alert("Delete successful");
            window.location.href = window.location;
          }
          else if(data=='error')
          {
            $('#pass_err_del').html("Incorrect Password");
          }
          else
          {
            alert(data);
          }
        }        
    });
  });

    $("#addroute_btn").click(function(e){
    e.preventDefault();
    
    if($('#showfare').val()==""||$('#mycomp').val()=="selected")
    {
      $('#showfare_error').html("Please select a company");
      return false;
    }

    var showcompany=$('#mycomp').val();
    var showtype=$('#mytype').val();
    var showloc=$('#myloc').val();
    var showdes=$('#mydes').val();
    var fare=$('#showfare').val();
    var sched=$('#time').val();
    var date_set=$('#date_set').val();

    $.ajax({
      type:"POST",
      url:"addroute.php",
      data:{'route_company':showcompany,
            'route_type':showtype,  
            'route_location':showloc,
            'route_destination':showdes,
            'route_fare':fare,
            'route_sched':sched,
            'date_set':date_set},
      success:function(data){
        if(data=='yes')
        {
         alert("Successfully added ");
         location.reload();
        }
        else
        {
          
        }
      }
    });
  });

    $('#mytype2').change(function(){
      var bus_type=$(this).val();
      var destination=$('#destination2').val();
      $.ajax({
        type:"POST",
        url:"comp_selectbus.php",
        data:{'bus_type':bus_type,
              'destination':destination,
              'company_name':company_name},
        success:function(data){
          $('#showfare2').val(data);
          $('#showfare2').html(data);
        }
      });
    });

    $('#destination2').change(function(){
      var bus_type=$('#mytype2').val();
      var destination=$(this).val();
      var company_name=$('#mycomp').val();
      $.ajax({
        type:"POST",
        url:"comp_selectbus.php",
        data:{'bus_type':bus_type,
              'destination':destination,
              'company_name':company_name},
        success:function(data){
          $('#showfare2').val(data);
          $('#showfare2').html(data);
        }
      });
    });

    $('#mycomp').change(function(){
      var bus_type=$('#mytype').val();
      var destination=$('#mydes').val();
      var company_name=$(this).val();
      $.ajax({
        type:"POST",
        url:"comp_selectbus.php",
        data:{'bus_type':bus_type,
              'destination':destination,
              'company_name':company_name},
        success:function(data){
          $('#showfare').val(data);
          $('#showfare').html(data);
        }
      });
    });

    $('#mytype').change(function(){
      var bus_type=$(this).val();
      var destination=$('#mydes').val();
      var company_name=$('#mycomp').val();
      $.ajax({
        type:"POST",
        url:"comp_selectbus.php",
        data:{'bus_type':bus_type,
              'destination':destination,
              'company_name':company_name},
        success:function(data){
          $('#showfare').val(data);
          $('#showfare').html(data);
        }
      });
    });

    $('#mydes').change(function(){
      var bus_type=$('#mytype').val();
      var destination=$(this).val();
      var company_name=$('#mycomp').val();
      $.ajax({
        type:"POST",
        url:"comp_selectbus.php",
        data:{'bus_type':bus_type,
              'destination':destination,
              'company_name':company_name},
        success:function(data){
          $('#showfare').val(data);
          $('#showfare').html(data);
        }
      });
    });
});

  </script>