<?php
require('dbconnect.php');

$destination = strip_tags($_POST['destination']);
$destination = $DBcon->real_escape_string($destination);
$km = strip_tags($_POST['km']);
$km = $DBcon->real_escape_string($km);
$location=$_POST['location'];

$check_destination = $DBcon->query("SELECT * FROM location_destination WHERE destination='$destination'");
$count=$check_destination->num_rows;
if($count==0)
{
$insertdestination = "INSERT INTO location_destination(location,destination,kilometers) VALUES('$location','$destination','$km')";
    if ($DBcon->query($insertdestination)) 
    {
        echo "yes";
    }
    else 
    {
        echo "Error on adding destination!";
    }
}

else
{
    echo "no";
}

?>