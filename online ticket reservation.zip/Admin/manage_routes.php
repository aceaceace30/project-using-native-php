<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}  
?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> 
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li class="active"><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

<form action="editroutepage.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Manage Location and Destination</h1>
<hr>
         <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
        <button onclick="document.getElementById('add').style.display = 'block'" type="button" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px; margin: 10px 0 0 20px;">ADD NEW DESTINATION</button>
        </div><br><br>
        <?php
        $select_query="SELECT * FROM location_destination";
        $result=$DBcon->query($select_query);

        if($result->num_rows>0)
        {
          echo "<table><tr><th>Location</th><th>Destination</th><th>Kilometers</th><th>Action</th><th>Action</th></tr>";
          while($row=$result->fetch_assoc())
          {
            echo "<tr><td>" . $row["location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["kilometers"]. "</td>";?>
            <td><button onclick="document.getElementById('edit').style.display = 'block'" type="button" class="btn_view" id='<?php echo $row["id"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ffb84d; font-size: 15px; height: 25px;">Edit</button></td>
            <td><button onclick="document.getElementById('delete').style.display = 'block'" type="button" class="btn_view" id='<?php echo $row["id"];?>' style="border-style: none; color: white; border-radius: 3px; background: #ff4d4d; font-size: 15px; height: 25px;">Delete</button></td>

       <?php
        }
        echo "</table>";
        }
        else {
          echo "<br><center>No Location and Destination</center>";  
        }
        ?>
      </div>  
    </div>
  </form>
</div>

<div id="add" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('add').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>New Destination</h1></center>
    <hr><br>
    <label style="margin-right: 40px;">Location:</label><input type="text" size="40" id="from" placeholder="Location"><span id="error_loc"></span><br>
    <label style="margin-right: 12px;">Destination:</label> <input type="text" size="40" id="destination" placeholder="Destination">
    <span id="error_des"></span><br>
    <label style="margin-right: 15px;">Kilometer/s:</label><input type="text" size="10" id="kilometers" placeholder="kilometer/s">
    <span id="error_km"></span>

    </div>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button id="modal_addbus" value="SUBMIT" style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SUBMIT</button></center> 
    </div>
  </form>
</div>

<div id="delete" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('delete').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to delete this destination? It cannot be undone.</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_del"></span><br>
    <input type="password" size="40" id="secpass_del" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <center><button id="deletedestination" value="SUBMIT" style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">DELETE</button></center> 
    </div>
  </form>
</div>

<div id="edit" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('edit').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Edit Location and Destination</h1></center><hr>
    <?php
            $store_value=array();
            $store_value2=array();

            $get_value ="SELECT DISTINCT location FROM location_destination";
            $result = $DBcon->query($get_value);
            if ($result->num_rows > 0) {
              while($row_result = $result->fetch_assoc()) {
                $store_value[]=$row_result["location"];
              }
            }
            $get_value2 ="SELECT DISTINCT destination FROM location_destination";
            $result2 = $DBcon->query($get_value2);
            if ($result2->num_rows > 0) {
              while($row_result2 = $result2->fetch_assoc()) {
                $store_value2[]=$row_result2["destination"];
              }
            }

            ?>

    <label>From:</label><select style="width: 380px; margin-left: 65px; display: inline-block;" id="loc">
            <?php for($n=0;$n<sizeOf($store_value);$n++){ 
                echo "<option value='$store_value[$n]'>$store_value[$n]</option>";
          }
          ?>
            </select><br>
    <label>Destination:</label><select style="width: 380px; margin-left: 23px; display: inline-block;" id="des">
            <?php for($n=0;$n<sizeOf($store_value2);$n++){ 
                echo "<option value='$store_value2[$n]'>$store_value2[$n]</option>";
          }
          ?>
            </select><br>
    <label>Kilometers:</label><input style="width: 380px; margin-left: 27px; display: inline-block;" type="text" id="km" value=""><br><center><span id="kmerr"></span></center>
    <hr>
    </div>
    <center><span style="color: red;" id="pass_err_edit"></span><br>
    <input type="password" size="40" id="secpass_edit" placeholder="Enter your password"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button type="button" id="edit_destination" style="background-color: #ff9900; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SAVE</button></center>
    </div>
  </form>
</div>


<script>
$(document).ready(function(){
  $('.btn_view').click(function(e) {
        e.preventDefault();
        desID=($(this).attr("id"));

        $.ajax({
        type:"POST",
        url:"getloc_des.php",
        data:{'desID':desID},
        success:function(value){
          var data=value.split(",");
          $('#loc').val(data[0]);
          $('#des').val(data[1]);
          $('#km').val(data[2]);
        }        
    });
  });

  $('#edit_destination').click(function(e) {
    e.preventDefault();
    securitypass=$('#secpass_edit').val();
    var location=$('#loc').val();
    var destination=$('#des').val();
    var kms=$('#km').val();

    if(kms=="")
    {
      $('#kmerr').html("Please input kilometer");
    }

    if(securitypass=="")
    {
      $('#pass_err_edit').html("Password cannot be empty");
          return;
    }
    $.ajax({
        type:"POST",
        url:"edit_destination.php",
        data:{'desID':desID,
              'securitypass':securitypass,
              'location':location,
              'kms':kms,
              'destination':destination},
        success:function(data){
              if(data=='yes')
              {
                 alert("Edit successful");
                 window.location.href = window.location;
              }
              else if(data=='error')
              {
                 $('#pass_err_edit').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
        }  
      });
  });
  $('#deletedestination').click(function(e) {
        securitypass=$('#secpass_del').val();
        e.preventDefault();
        if(securitypass=="")
        {
          $('#pass_err_del').html("Password cannot be empty");
          return;
        }       

        $.ajax({
        type:"POST",
        url:"delete_destination.php",
        data:{'desID':desID,
              'securitypass':securitypass},
        success:function(data){
              if(data=='yes')
              {
                 alert("Delete successful");
                 window.location.href = window.location;
              }
              else if(data=='error')
              {
                 $('#pass_err_del').html("Incorrect Password");
              }
              else
              {
                alert(data);
              }
        }        
    });
  });
  $("#modal_addbus").click(function(e){
    e.preventDefault();
    var destination=$('#destination').val();
    var km=$('#kilometers').val();
    var location=$('#from').val();
    if(location=="")
    {
      $('#error_loc').html("location cannot be empty");
      return false;
    }
    if(destination=="")
    {
      $('#error_des').html("destination cannot be empty");
      return false;
    }
    if(km=="")
    {
      $('#error_km').html("kilometers cannot be empty");
      return false;
    }
    $.ajax({
      type:"POST",
      url:"add_destination.php",
      data:{'destination':destination,
            'km':km,
            'location':location},
      success:function(data){
        if(data=='yes')
        {
          window.location.href = window.location;
        }
        else if(data=='no');
        {
          $('#error_des').html("already have this destination");
          $('#error_km').html("");
        }
      }
    });
  });  
});
</script>

</body>
</html>