<?php
session_start();
require('dbconnect.php');

$reserveID=$_POST['reserveid'];
$secpass=$_POST['securitypass'];
$userid=$_SESSION['userid'];

$checkpassword="SELECT * FROM users WHERE userid='$userid'";
$res = $DBcon->query($checkpassword);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $userpass=$row['password'];
        }
      }
    if($userpass!=$secpass)
    {
        echo "error";
        return;
    }

$select_stat="SELECT * FROM reservations as r INNER JOIN users as u ON r.userID=u.userid WHERE reserveID='$reserveID'";
$res = $DBcon->query($select_stat);

if($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
            $payment_status=$row['payment_status'];
            $fare_total=$row['fare_total'];
            $email=$row['email'];
            $firstname=$row['firstname'];
        }
      }

if($payment_status=="UNPAID")
{
    $update_reservation = "UPDATE reservations SET payment_status='PAID' WHERE reserveID='$reserveID'";
        if ($DBcon->query($update_reservation))
        {
    
            $to      = $email;
            $subject = 'Travel Lokal Reservation';
            $message_send = 'Good Day Sir/Mam '.$firstname.'! We have received your payment of PHP '.$fare_total.'. Thank you for booking with us. Have a safe trip.';
            $headers = 'From:thesis.travel.lokal@gmail.com' . "\r\n" .
                'Reply-To:thesis.travel.lokal@gmail.com' . "\r\n" .
                'X-Mailer: PHP/' . phpversion();
            
            mail($to, $subject, $message_send, $headers);
            echo "yes";
        }
        else 
        {
            echo "Error on changing payment_status";
        }
}
else if($payment_status=="PAID")
{
     $update_reservation = "UPDATE reservations SET payment_status='UNPAID' WHERE reserveID='$reserveID'";
        if ($DBcon->query($update_reservation))
        {
            echo "yes";
        }
        else 
        {
            echo "Error on changing payment_status";
        }
}
?>