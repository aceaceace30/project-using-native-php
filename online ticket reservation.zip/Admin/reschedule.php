<?php

require('dbconnect.php');
require('select.php');
if(isset($_SESSION["email"])){
    header("location:dashboard.php");
    exit();
}  

          $myrouteid=$_GET['id'];
          $myreserveid=$_GET['resid'];
          $bustype=$_GET['btype'];
          $rdate=$_GET['rdate'];

?>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
<script>
  $( function() {
   $('#datepicker').datepicker({ minDate: 1, maxDate: 14 });
  } );
</script> 

</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2">  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li class="active"><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
      <li><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Transaction</a></li>
          <li><a href="#">Audit Trail</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Pick Schedule and Date</h1>
        <form action="reschedule.php" method="get">
        <center><input type="text" placeholder="Choose Date" name="rdate" id="datepicker" size="40" style="padding-left: 45px; cursor: pointer;" required>
        <input type="hidden" name="id" value="<?php echo $myrouteid; ?>">
        <input type="hidden" name="resid" value="<?php echo $myreserveid; ?>">
        <input type="hidden" name="btype" value="<?php echo $bustype; ?>">
        <input type="submit" name="getnew" value="Search">
        <input type="text" value="<?php echo $rdate;?>" disabled></center>
        </form>
        <hr>
      </div>
  </div>
  <div style="margin-top: -60px;">
        <form action="resched_seats.php" method="get">
        <input type="hidden" name="id" value="<?php echo $myrouteid; ?>">
        <input type="hidden" name="resid" value="<?php echo $myreserveid; ?>">
        <input type="hidden" name="rdate" value="<?php echo $rdate; ?>">

          <?php
          
          $get_loc_des="SELECT * FROM routes_schedules WHERE routeID='$myrouteid'";
          $result = $DBcon->query($get_loc_des);

          if($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
              $from=$row['from_location'];
              $destination=$row['destination'];
            }
          }
          $new_rdate=urldecode($rdate);
          $sql = "SELECT * FROM routes_schedules where from_location='$from' and destination='$destination' and Type='$bustype' and date_set='$new_rdate'";

          $result = $DBcon->query($sql);

          if ($result->num_rows > 0) {
            echo "<table><tr><th>Bus Company</th><th>Type</th><th>From</th><th>Destination</th><th>Schedule</th><th>Fare</th><th>Action</th></tr>";

              while($row = $result->fetch_assoc()) {
            
                  echo "<tr><td>" . $row["company"]. "</td><td>" . $row["type"]. "</td><td>" . $row["from_location"]. "</td><td>" . $row["destination"]. "</td><td>" . $row["time_sched"]. "</td><td>" . $row["fare"]. "</td>"?>
                <?php echo "<td><input type='submit' name='pass_resched' value='Select'></td>";
                ?>
                                 
              <?php
              }   
              echo "</table>";
          } else {
              echo "<br>NO SCHEDULE RESULT";  
          }
          ?>
          </form>
          </div>
        </div>
      </div>
      </div>
  </body>
</html>