<?php
session_start();
require('dbconnect.php');

 $email = strip_tags($_POST['email']);
 $password = strip_tags($_POST['password']);
 $confirmpassword = strip_tags($_POST['confirmpass']);
 $firstname = strip_tags($_POST['fname']);
 $lastname = strip_tags($_POST['lname']);
 $phonenumber= strip_tags($_POST['phonenumber']);
 
 $email = $DBcon->real_escape_string($email);
 $password = $DBcon->real_escape_string($password);
 $confirmpassword = $DBcon->real_escape_string($confirmpassword);
 $firstname = $DBcon->real_escape_string($firstname);
 $lastname = $DBcon->real_escape_string($lastname);
 $phonenumber = $DBcon->real_escape_string($phonenumber);
 //$hashed_password = password_hash($upass, PASSWORD_DEFAULT); // this function works only in PHP 5.5 or latest version
 
 $check_email = $DBcon->query("SELECT email FROM users WHERE email='$email'");
 $count=$check_email->num_rows;
 
if($password==$confirmpassword)
{
 if($count==0)
 {  
  $query = "INSERT INTO users(email,password,phonenumber,firstname,lastname,usertype,activated) VALUES('$email','$password','$phonenumber','$firstname','$lastname','member','no')";

    if ($DBcon->query($query)) 
    {
      $rand_activation=rand(100000,999999);
      $latest_userid="SELECT MAX(userid) as latest FROM users";

      $result=$DBcon->query($latest_userid);
        if ($result->num_rows > 0) {
              while($row = $result->fetch_assoc()) {
                $latest=$row["latest"];
              }
            }
     $insert_activation = "INSERT INTO activation_code(userID,activation_code) VALUES('$latest','$rand_activation')";
     $DBcon->query($insert_activation);

        
        echo "yes";
    }
    else 
    {
        echo "errorreg";
    }
  }
 else 
 { 
  echo "emailtaken";
 }
}
else
{
 echo "notequalpass";
}
  
 $DBcon->close();
?>
