<?php
require('dbconnect.php');
require('select.php');
if(isset($_SESSION["email"])){
    header("location:dashboard.php");
    exit();
}    

$usercount = "SELECT * FROM users";
$usercount1 = $DBcon->query($usercount);
$usercount=0;
if($usercount1->num_rows > 0) {
while ($row = $usercount1->fetch_assoc()) {
   $usercount++;
  }
}

$per_page = 8;

if (isset($_GET["page"])) {
$page = $_GET["page"];
}
else {
$page = 1;
}

// Page will start from 0 and Multiple by Per Page
$start_from = ($page-1) * $per_page;

    //Now select all from table
$query = "select * from users";
$result = mysqli_query($DBcon, $query); 

    // Count the total records
$total_records = mysqli_num_rows($result);

      //Using ceil function to divide the total records on per page
$total_pages = ceil($total_records / $per_page);
?>
     
<!DOCTYPE html>
<html>
<head>

<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/styles.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="../index.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav" class="clear"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="../index.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editbuspage.php" id="bus_link">Manage Bus</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          </form>
        </ul>
     </li>
      <li class="active"><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li class="active"><a href="#" onclick="showUsers()">Users</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>


<form action="users.php" method="POST">
 <div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: auto;">
      <div class="col-lg-12">
        <h1 class="page-header">Users</h1>
        <hr><br>
      </div>
  <div id="fixednav" style="background: linear-gradient( rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)); width: 100%; height: 60px;">
       <button onclick="document.getElementById('add').style.display = 'block'" type="button" style="background-color: #00e600; border-radius: 5px; color:white; height: 40px;  border-style: none; width: 120px; margin: 10px 0 0 20px;">ADD NEW USER</button>
       <div style="float: right; margin: 3px 20px 0 0;">
    <i class="fa fa-search fa-2x" aria-hidden="true" style="position: absolute; margin: 13px 0 0 5px; color: #595959;"></i>
        <input type="text" name="search_text" id="search_text"  style="padding-left: 40px; border-radius: 5px; height: 40px;" placeholder="Search"> 
        </div>
      </div> <br><br>
    <div id="myTable">
      <?php 
      $sql1 = "SELECT email, phonenumber, firstname, lastname, usertype FROM users LIMIT $start_from, $per_page";
      $result1 = $DBcon->query($sql1);

      if($result1->num_rows > 0) {
      echo "<table><tr><th>Email</th><th>Phone Number</th><th>First Name</th><th>Last Name</th><th>User Type</th><th>Action</th><th>Action</th></tr>";
      

       while($row = $result1->fetch_assoc()) {
      
          echo "<tr><td>" .$row["email"]. "</td><td>" .$row["phonenumber"]. "</td><td>" .$row["firstname"]. "</td><td>" .$row["lastname"]. "</td><td>" . $row["usertype"]. "</td>"?>

          <td><button onclick="document.getElementById('edit').style.display = 'block'" type="button" style="border-style: none; border-radius: 3px; background: #ff9900; color: white; font-size: 15px; height: 25px;">Edit</button></td>
          <td><button onclick="document.getElementById('delete').style.display = 'block'" type="button" style="border-style: none; border-radius: 3px; background: #ff4d4d; color: white; font-size: 15px; height: 25px;">Delete</button></td></tr>
      <?php
      }    
      echo "</table>";
      } 

      ?> 
      </div>  

      <?php

    $DBcon->close();
    ?> 
      <center><div class="pagination">
      <?php 
      for ($x=1; $x <= $total_pages ; $x++): ?>
        <a href="?page=<?php echo $x; ?>"><?php echo $x; ?></a>

      <?php endfor;

      ?>
    </div></center> 
    </div>
  
 </div>  <!--/.main-->
</form>

<div id="add" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('add').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Add New User</h1></center>
    <hr>
   
    </div>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button id="modal_addbus" value="SUBMIT" style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SUBMIT</button></center> 
    </div>
  </form>
</div>

<div id="edit" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('edit').style.display='none'" class="close" title="Close">&times;</span>
    </div>
    <div class="logcontainer">
    <center><h1>Edit User</h1></center>
    <center><h2>Are you sure you want to edit this User? If yes is pressed, it cannot be undone.</h2></center>

    <center><span style="color: red;" id="pass_err_del"></span><br>
    <input type="password" size="40" id="secpass_del" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
    <center><button id="modal_addbus" value="SUBMIT" style="background-color: #00e600; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">SAVE</button></center> 
    </div>
  </form>
</div>

<div id="delete" class="regmodal">
  <form class="regmodal-content animate">
    <div class="imgcontainer">  
      <span onclick="document.getElementById('delete').style.display='none'" class="close" title="Close">&times;</span>
    </div><br>
    <div class="logcontainer">
    <center><h2>Are you sure you want to delete this bus? It cannot be undone.</h2></center>
    </div>
    <center><span style="color: red;" id="pass_err_del"></span><br>
    <input type="password" size="40" id="secpass_del" placeholder="Enter password here"></center><br>
    <div class="logcontainer" style="background-color:#f1f1f1">
      <center><button id="deletebus" value="SUBMIT" style="background-color: #ff4d4d; border-radius: 5px; color:white; height: 50px; border-style: none; width: 200px;">DELETE</button></center> 
    </div>
  </form>
</div>


</body>
</html>