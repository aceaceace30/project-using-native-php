<?php
  $DBhost = "mysql.hostinger.ph";
  $DBuser = "u459143154_dbtl";
  $DBpass = "travellokal";
  $DBname = "u459143154_dbtl";
  
  $DBcon = new MySQLi($DBhost,$DBuser,$DBpass,$DBname);
    
     if ($DBcon->connect_errno) {
         die("ERROR : -> ".$DBcon->connect_error);
     }
?>