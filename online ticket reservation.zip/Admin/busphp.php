<?php
require('dbconnect.php');

$busid=$_POST['busID'];
$array_busdetails=array();

$selectbus="SELECT * from bus where BusID='$busid'";

          $result = $DBcon->query($selectbus);
          if ($result->num_rows > 0) {
            while($row = $result->fetch_assoc()) {
            	echo $row["BusName"].",".$row["Bus_Company"].",".$row["Type"];                  	
            }
        }
        else
        {
        	echo "hello";	
        }
?>