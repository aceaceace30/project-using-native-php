<?php
session_start();
require('dbconnect.php');
require('select.php');
if(!isset($_SESSION["checkadmin"])){
    header("location:adminlogin.php");
}   

if(isset($_POST['submit_message']))
{
$regmess=$_POST['reg_message'];
$reservemess=$_POST['reserve_message'];
$my_message_array=array($regmess,$reservemess);
for($i=0;$i<sizeOf($my_message_array);$i++)
{
	$p=$i+1;
$update_message="UPDATE sms_message SET message='$my_message_array[$i]' WHERE id='$p'";
$DBcon->query($update_message);
}
}

$get_message_reg="SELECT * FROM sms_message";
$result = $DBcon->query($get_message_reg);
$message_array=array();
if($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
            $message_array[]=$row['message'];
        }
      }

?>

<html>
<head>
</head>
<body>

<!DOCTYPE html>
<html>
<head>
<title>TRAVEL LOKAL</title>
<link rel="icon" href="../../GlobalImages/profile1.png">
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link href="../../GlobalCSS/layoutx.css" rel="stylesheet" type="text/css" media="all">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.2/modernizr.js"></script>
</head>
<body>
<div class="wrapper row1">
  <header id="header" class="clear"> 
    <div id="logo" class="fl_left">
      <h1><a href="home.php"><img style="position: absolute; margin-left: -40px;" src="../../GlobalImages/profile1.png" height="35"> <?php echo $comp_name; ?></a></h1>
      <i style="font-family: Times Verdana; font-size: 15px;">A fast.. easy & convenient bus booking site!</i>
    </div>
</header>
</div>

<div class="wrapper row2" >  
  <nav id="mainav"> 
    <ul class="clear">
      <i class="fa fa-home icon" aria-hidden="true"></i>
      <li><a href="home.php">Home</a></li>
      <i class="fa fa-tachometer" aria-hidden="true"></i>
      <li><a href="dashboard.php">Dashboard</a></li>
      <li><a class="drop" href="#">Bus Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="manage_reservation.php" id="manage_res_link">Manage Reservations</a></li>
          <li><a href="editroutepage.php" id="route_link">Manage Routes and Schedules</a></li>
          <li><a href="manage_routes.php" id="man_r_link">Add Destination</a></li>
          <li><a href="edit_kilometer.php" id="edit_kilo_link">Manage Per Kilometer rate</a></li>
          </form>
        </ul>
     </li>
       <li class="active"><a class="drop" href="#">User Tables</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="users.php">Users</a></li>
          <li class="active"><a href="editmessage_sms.php">Edit SMS message</a></li>
          </form>
        </ul>
     </li>
     <li><a class="drop" href="#">History</a>
        <ul>
          <form id="dashboard_frm">
          <li><a href="transaction_history.php">Sales Report</a></li>
          <li><a href="cancelled_transactions.php">Cancelled Transactions</a></li>
          <li><a href="daily_schedules.php">Daily Schedule Report</a></li>
          <li><a href="message_view.php">Message View</a></li>
          </form>
        </ul>
     </li>
    </ul>
  </nav>
</div>

<div id="dashboard">
  <div id="pnlDashboard" class="panels" style="height: 700px;">

      <div class="col-lg-12">
        <h1 class="page-header">Edit SMS Message</h1>
        <hr>
      </div><br>

      <div style="border: 1px solid gray; border-radius: 5px; width: 500px; padding: 20px; margin-left: 30%;">
          <form action="editmessage_sms.php" method="POST">
          <h4 style="font-weight: bold;">Registration SMS</h4>
          Current Text:
          <label style="color: #595959; font-weight: bold;"><?php echo $message_array[0]; ?> 4-digit Code</label><br>
      
          <label>Edit Text:</label> 
          <textarea rows="4" cols="50" name="reg_message"><?php echo $message_array[0]; ?></textarea><br>
      

          <hr><br>
          <h4 style="font-weight: bold;">Reservation SMS</h4>
          <label>Current Text:</label>
          <label style="color: #595959; font-weight: bold;"><?php echo $message_array[1]; ?> 8-digit Code</label><br> 
          Edit Text:
          <textarea rows="4" cols="50" name="reserve_message"><?php echo $message_array[1]; ?></textarea><br><br>
       
          <center><button type="submit" name="submit_message" style="background-color: #00e600; border-radius: 5px; color:white; height: 50px;  border-style: none; width: 200px;">SAVE</button></center>
          </form>
      </div>
      
        </div>
      </div> <br><br> 
    </div>   


</body>
</html>